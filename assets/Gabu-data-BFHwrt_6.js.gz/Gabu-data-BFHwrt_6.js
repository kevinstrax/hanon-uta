const e="【歌枠/カラオケJOYSOUND for STREAMER】初めての歌枠♡アイドル縛り【#鎖乙女がぶ /パレプロ研究生】",t="鎖乙女がぶ / Saotome Gabu 【パレプロ研究生】",o="nMmWVciVOgk",n="2024-12-27",i=`🐺💜セットリスト🐺💜
0:00:00 OP
0:02:05 開始、ミュート芸
0:03:15 01.星間飛行～Freyja Ver.～／ワルキューレ
0:12:05 02.だいしきゅーだいしゅき / femme fatale
0:17:25 03.サインはB / B小町 
0:23:55 04.わたしの一番かわいいところ / FRUITS ZIPPER
0:30:23 05.Starlight Prologue / Liella!
0:34:42 06.きっかけ / 乃木坂46 
0:41:13 07.サイレントマジョリティー / 欅坂46
0:49:37 08.ハート型ウイルス / AKB48
0:55:20 09.夢をかなえてドラえもん / Mao
1:00:43 みそラーメン
1:04:33 10.ぎゅっと / Sexy Zone
1:11:17 11.moreきゅん奴隷 / 戦慄かなの
1:20:13 12.恋のロケットランチャー / 佐々木喫茶
1:25:42 13.ポニーテールとシュシュ / AKB48
1:35:09 14. fashion check! / わか・ふうり・すなお・れみ・もえ from STAR☆ANIS
1:43:15 15.SOS / 黛　冬優子(幸村恵理) 
1:51:56 16.トライアングラー / 坂本真綾
2:02:40 17.Snow halation / μ's
2:11:18 18.放課後オーバーフロウ / ランカ・リー＝中島愛
2:19:00 ED


おつがぶでした！
歌声綺麗でとても良きでしたね〜！
しっかりセトリも練ってきてて流石でした！`,me={video_title:e,video_artist:t,video_id:o,video_publish_date_str:n,song_timeline:i},Ne=Object.freeze(Object.defineProperty({__proto__:null,default:me,song_timeline:i,video_artist:t,video_id:o,video_publish_date_str:n,video_title:e},Symbol.toStringTag,{value:"Module"})),_="【歌枠/カラオケJOYSOUND for STREAMER】新年1発目はオールジャンル歌枠っ！♡【#鎖乙女がぶ /パレプロ研究生】",s="鎖乙女がぶ / Saotome Gabu 【パレプロ研究生】",d="_DNXs9CJh3w",l="2025-01-06",a=`歌枠配信、おつがぶ～

[セトリ]
0:02:06 01. ムーンライト伝説 / DALI
0:10:01 02. 君の知らない物語 / supercell
0:19:38 03. 少女レイ / みきとP
0:28:48 04. 気まぐれロマンティック / いきものがかり
0:37:28 05. MIRACLE NEW STORY / Liella!
0:45:50 06. Shocking Party / A-RISE
0:55:54 07. 硝子ドール / もえ,すなお from STAR☆ANIS
1:07:51 08. サウダージ / ポルノグラフィティ
1:14:09 09. StaRt / Mrs. GREEN APPLE
1:23:05 10. 花に亡霊 / ヨルシカ
1:32:45 11. プラチナ / 坂本真綾
1:41:36 12. アイのシナリオ / CHiCO with HoneyWorks
1:49:01 13. きみわずらい / まねきケチャ
1:59:56 14. コネクト / ClariS`,Oe={video_title:_,video_artist:s,video_id:d,video_publish_date_str:l,song_timeline:a},je=Object.freeze(Object.defineProperty({__proto__:null,default:Oe,song_timeline:a,video_artist:s,video_id:d,video_publish_date_str:l,video_title:_},Symbol.toStringTag,{value:"Module"})),r="【ボカロ歌枠/カラオケJOYSOUND for STREAMER】懐かしのボカロ多め歌枠行くぞ～！！【#鎖乙女がぶ /パレプロ研究生】",v="鎖乙女がぶ / Saotome Gabu 【パレプロ研究生】",c="6TsXn5PJzFo",u="2025-01-12",S=`🐺💜セットリスト🐺💜
0:00:00 OP 
0:02:17 01.ワールドイズマイン / supercell
0:12:28 02.おじゃま虫 / DECO*27
0:23:10 03.ピエロ / 伊東歌詞太郎
0:32:10 04.地球最後の告白を / kemu
0:39:28 05.ニア / 夏代孝明
0:44:01 06.ラヴィ / すりぃ
0:50:32 07.アスノヨゾラ哨戒班 / Orangestar
0:55:30 08.ロミオとシンデレラ / doriko


おつがぶでした〜

初手ワールドイズマインで横転してしまいましたね…
地球最後の告白をとかアスノヨゾラ哨戒班、ロミオとシンデレラもすごく好きな曲なので聴けてよかったです！

ニアは初めて聴いたのですが、すごくきれいな曲で原曲も聴きたくなっちゃいました！`,ge={video_title:r,video_artist:v,video_id:c,video_publish_date_str:u,song_timeline:S},Ie=Object.freeze(Object.defineProperty({__proto__:null,default:ge,song_timeline:S,video_artist:v,video_id:c,video_publish_date_str:u,video_title:r},Symbol.toStringTag,{value:"Module"})),b="【カラオケJOYSOUND for STREAMER】高評価150行くまで終われまてんアニソン歌枠！！【#鎖乙女がぶ /パレプロ研究生】",m="鎖乙女がぶ / Saotome Gabu 【パレプロ研究生】",O="v8qbOm3yfRo",g="2025-01-25",p=`🐺💜セットリスト🐺💜
0:00:00 OP
0:03:08 開始
0:11:21 01.ユメセカイ / 戸松遥 
0:19:57 02.乙女のポリシー / 石田よう子
0:26:56 03.花になって / 緑黄色社会
0:34:13 04.破滅の純情 / ワルキューレ
0:42:57 05.ワルキューレは裏切らない / ワルキューレ
0:47:50 06.ルンがピカッと光ったら / ワルキューレ
0:55:09 07.トライアングラー / 坂本真綾
1:02:32 08.ニンジーン Loves you yeah! / ランカ・リー=中島愛
1:07:45 09.グランドエスケープ / RADWIMPS
1:15:11 10.サインはB / B小町
1:27:16 11.POP IN 2 / B小町
1:36:19 12.Overfly / 春奈るな
1:43:37 13.Ubiquitous dB / ユナ(CV:神田沙也加)
1:55:10 14.Second Sparkle / Liella!
2:00:59 15.貴方の側に。 / りりあ。


おつがぶでした～
お昼からがぶちゃんのお歌いっぱい聴けて楽しかったです！
最後の3曲はどれも初めて聴いたのですが、どれも良い曲でしたね…！`,pe={video_title:b,video_artist:m,video_id:O,video_publish_date_str:g,song_timeline:p},Ce=Object.freeze(Object.defineProperty({__proto__:null,default:pe,song_timeline:p,video_artist:m,video_id:O,video_publish_date_str:g,video_title:b},Symbol.toStringTag,{value:"Module"})),f="【歌枠/カラオケJOYSOUND for STREAMER】平成のJ-POP縛り歌枠‼懐かしさで震えて眠れ【#鎖乙女がぶ /パレプロ研究生】",$="鎖乙女がぶ / Saotome Gabu 【パレプロ研究生】",A="x6c4IX-Z-YQ",E="2025-02-09",R=`0:00:00 OP
0:02:26 01. GLAMOROUS SKY / NANA starring MIKA NAKASHIMA
0:16:00 02.八月の夜 / Silent Siren
0:23:33 03.気まぐれロマンティック / いきものがかり
0:31:08 04.サウダージ / ポルノグラフィティ
0:35:17 05.シャボン玉 / モーニング娘。
0:44:13 06.小さな恋のうた / MONGOL800
0:48:30 07.ヒカリヘ / miwa
0:53:33 08.三日月 / 絢香
0:58:40 09.ハナミズキ / 一青窈
1:07:57 10.ただ君に晴れ / ヨルシカ
1:15:52 11.瞳 / 大原櫻子
1:25:21 12.高嶺の花子さん / back number
1:30:21 13.イチブトゼンブ / B'z
1:38:55 14.おどるポンポコリン / E-Girls
1:46:51 15.Catch You Catch Me / グミ
1:55:30 16.乙女のポリシー / 石田よう子
2:01:38 17.ロマンスの神様 / 広瀬 香美
2:16:01 18.ヘビーローテーション / AKB48
2:21:09 19.青春アミーゴ / 修二と彰`,fe={video_title:f,video_artist:$,video_id:A,video_publish_date_str:E,song_timeline:R},Ge=Object.freeze(Object.defineProperty({__proto__:null,default:fe,song_timeline:R,video_artist:$,video_id:A,video_publish_date_str:E,video_title:f},Symbol.toStringTag,{value:"Module"})),P="【歌枠/カラオケJOYSOUND for STREAMER】バレンタインのあま～い恋愛ソング召し上がれ♡【#鎖乙女がぶ /パレプロ研究生】",h="鎖乙女がぶ / Saotome Gabu 【パレプロ研究生】",T="ZSoc5mLy9v0",M="2025-02-14",y=`🐺💜🎶セットリスト🐺💜🎶
0:00:00 OP
0:02:26 01.Love so sweet / 嵐
0:14:13 02.あたしを彼女にしたいなら / コレサワ
0:18:25 03.SOS / 黛冬優子 (CV.幸村恵理)
0:29:45 04.Bittersweet / 嵐
0:34:47 05.バレンタイン・キッス / 国生 さゆり
0:47:13 06.だいしきゅーだいしゅき / femme fatale
0:54:59 07.しゅきぴ / =LOVE
1:03:03 08.おじゃま虫 / DECO*27
1:12:09 09.わたしの一番かわいいところ / FRUITS ZIPPER
1:18:24 10.金曜日のおはよう / Gero
1:24:25 11.ワールドイズマイン / supercell
1:29:45 12.キャットラビング / 香椎モイミ
1:33:58 13.ハート型ウイルス / AKB48
1:41:15 14.初恋サイダー/Buono!
1:53:13 15.恋愛サーキュレーション / 千石撫子(花澤香菜) 


おつがぶでした～
遅れ馳せながらセトリをば
とっても甘々なセトリでたすかりすぎちゃいましたね…！`,$e={video_title:P,video_artist:h,video_id:T,video_publish_date_str:M,song_timeline:y},Be=Object.freeze(Object.defineProperty({__proto__:null,default:$e,song_timeline:y,video_artist:h,video_id:T,video_publish_date_str:M,video_title:P},Symbol.toStringTag,{value:"Module"})),N="【 #Vアイドルが歌う2次元アイドル歌枠リレー 】7番手！作品被り無しで盛り上がるぞっ！【#鎖乙女がぶ /パレプロ研究生】",j="鎖乙女がぶ / Saotome Gabu 【パレプロ研究生】",I="ZOYzqWUvWMQ",C="2025-03-01",G=`0:01:31 01.星間飛行 / ランカ・リー=中島愛 / マクロスF
0:08:43 02. STAR☆T☆RAIN / B小町 ルビー(CV:伊駒ゆりえ) 有馬かな(CV:潘めぐみ) MEMちょ(CV:大久保瑠美) / 推しの子
0:14:14 03.硝子ドール / もえ from STAR ANIS / アイカツ！
0:20:45 04.Cutie Panther / BiBi ～絢瀬絵里(南條愛乃)、西木野真姫(Pile)、矢澤にこ(徳井青空) from μ's～ / ラブライブ！
0:27:13 05.Starlight Prologue / Liella! / ラブライブ！スーパースター!!`,Ae={video_title:N,video_artist:j,video_id:I,video_publish_date_str:C,song_timeline:G},Le=Object.freeze(Object.defineProperty({__proto__:null,default:Ae,song_timeline:G,video_artist:j,video_id:I,video_publish_date_str:C,video_title:N},Symbol.toStringTag,{value:"Module"})),B="【歌枠/カラオケJOYSOUND for STREAMER】歌ったり喋ったり、寝たり。【#鎖乙女がぶ /パレプロ研究生】",L="鎖乙女がぶ / Saotome Gabu 【パレプロ研究生】",U="Avby-tqdntY",K="2025-03-07",D=`0:00:00 OP
0:01:13 開始
0:11:46 01.夜もすがら君想ふ / TOKOTOKO(西沢さんP)
0:27:15 02.僕らの戦場～Freyja Solo Edition～ / ワルキューレ
0:58:05 03.ANIMA / ReoNa
1:08:00 04.未来予報ハレルヤ！ / Liella!
1:49:57 05.シルエット / KANA-BOON
2:00:43 06.ワルキューレは裏切らない / ワルキューレ`,Ee={video_title:B,video_artist:L,video_id:U,video_publish_date_str:K,song_timeline:D},Ue=Object.freeze(Object.defineProperty({__proto__:null,default:Ee,song_timeline:D,video_artist:L,video_id:U,video_publish_date_str:K,video_title:B},Symbol.toStringTag,{value:"Module"})),z="【歌枠/カラオケJOYSOUND for STREAMER】プロセカ収録ボカロ縛り歌枠！【#鎖乙女がぶ /パレプロ研究生】",Y="鎖乙女がぶ / Saotome Gabu 【パレプロ研究生】",k="VFnobl-_9MI",F="2025.04.06",J=`歌枠配信、おつがぶ～

[セトリ]
0:02:12 01.少女レイ / みきとP
0:21:35 02.白い雪のプリンセスは / のぼる↑
0:30:40 03.ハイドアンド・シーク / 19's Sound Factory
0:40:12 04.ハッピーシンセサイザ / EasyPop
0:45:33 05.夜もすがら君想ふ / TOKOTOKO(西沢さんP)
0:59:58 06.キャットラビング / 香椎モイミ
1:03:20 07.ワールドイズマイン / supercell
1:14:09 08.ロミオとシンデレラ / doriko
1:21:31 09.ヴァンパイア / DECO*27
1:37:42 10.エイリアンエイリアン / ナユタン星人
1:46:21 11.嗚呼、素晴らしきニャン生 / Nem
1:53:15 12.地球最後の告白を / kemu
1:58:18 13.ニア / 夏代孝明`,Re={video_title:z,video_artist:Y,video_id:k,video_publish_date_str:F,song_timeline:J},Ke=Object.freeze(Object.defineProperty({__proto__:null,default:Re,song_timeline:J,video_artist:Y,video_id:k,video_publish_date_str:F,video_title:z},Symbol.toStringTag,{value:"Module"})),V="【歌枠/カラオケJOYSOUND for STREAMER】高評価150行くまで終われない歌枠！！【#鎖乙女がぶ /パレプロ研究生】",w="鎖乙女がぶ / Saotome Gabu 【パレプロ研究生】",W="QnjsujoZ-P8",Z="2025-04-12",H=`🐺💜🎶セットリスト🐺💜🎶
0:00:00 OP
0:02:16 開始
0:10:13 01.君の知らない物語 / supercell
0:21:44 02.放課後オーバーフロウ / ランカ・リー=中島愛
0:29:06 03.ライオン / ワルキューレ
0:38:09 04.時の迷宮 / ランカ・リー=中島愛、シェリル・ノーム starring May'n
0:48:42 05.ユニバーサル・バニー / シェリル・ノーム starring May'n
1:01:28 06.GIRAFFE BLUES / ワルキューレ
1:09:43 07.美少女無罪♡パイレーツ / 宝鐘マリン
1:17:32 08.花になって - Be a flower / 緑黄色社会
1:24:29 09.Special Color / Liella!
1:32:50 10.ダイヤモンドハッピー / わか・ふうり・すなお from STAR☆ANIS
1:42:04 11.恋するフォーチュンクッキー / AKB48
1:52:32 12.ハート型ウイルス / AKB48
2:00:29 13.残酷な天使のテーゼ / 高橋洋子
2:16:16 14.サウダージ / ポルノグラフィティ
2:27:35 15.だいしきゅーだいしゅき / emme fatale
2:34:58 16.おじゃま虫 / DECO*27
2:38:46 雑談・告知タイム


おつがぶでした〜

Special Color初めて聴いたのですがとても良かったですね…
ダイヤモンドハッピーやハート型ウイルス、おじゃま虫とかかわいすぎました！

汗のお話助かりました🙏
メンシも開始したらぜひ入りたいですし、どんなスタンプ使えるようになるのかも楽しみです！`,Pe={video_title:V,video_artist:w,video_id:W,video_publish_date_str:Z,song_timeline:H},De=Object.freeze(Object.defineProperty({__proto__:null,default:Pe,song_timeline:H,video_artist:w,video_id:W,video_publish_date_str:Z,video_title:V},Symbol.toStringTag,{value:"Module"})),Q="【 アイカツ！縛り歌枠 】アイカツ！のかっこいい＆キレイ系の歌を沢山歌う！！【#がぶかなめ #鎖乙女がぶ /#常磐カナメ】",q="鎖乙女がぶ / Saotome Gabu 【パレプロ研究生】",x="dQeEFcMcQoU",X="2025-04-27",ee=`0:00:00 OP
0:03:01 開始
0:04:22 01.Move on now! / わか・ふうり・すなお・りすこ from STAR☆ANIS
0:11:50 02.オトナモード / りすこ・もな from STAR☆ANIS
0:21:08 03.タルト・タタン / もな from AIKATSU☆STARS!
0:28:10 04. Wake up my music / りさ・えいみ
0:36:32 05. MUSIC of DREAM!!! / せな from AIKATSU☆STARS!
0:46:34 06.Take Me Higher / りすこ・もえ・ゆな from STAR☆ANIS
0:57:38 07.硝子ドール  / もえ from STAR☆ANIS`,he={video_title:Q,video_artist:q,video_id:x,video_publish_date_str:X,song_timeline:ee},ze=Object.freeze(Object.defineProperty({__proto__:null,default:he,song_timeline:ee,video_artist:q,video_id:x,video_publish_date_str:X,video_title:Q},Symbol.toStringTag,{value:"Module"})),te="【誕生日配信/カラオケJOYSOUND for STREAMER】最後に重大発表あり！！お誕生日当日！！私が主役だ！！【#鎖乙女がぶ /#パレプロ研究生 】",oe="鎖乙女がぶ / Saotome Gabu 【パレプロ研究生】",ne="dQx_7qmiQ8w",ie="2025-05-01",_e=`1:38:38 1.SOS / 黛冬優子 (CV.幸村恵理)
1:50:21 2.ハム太郎とっとこうた / ハムちゃんず
1:53:16 3.夜もすがら君想ふ / TOKOTOKO(西沢さんP)`,Te={video_title:te,video_artist:oe,video_id:ne,video_publish_date_str:ie,song_timeline:_e},Ye=Object.freeze(Object.defineProperty({__proto__:null,default:Te,song_timeline:_e,video_artist:oe,video_id:ne,video_publish_date_str:ie,video_title:te},Symbol.toStringTag,{value:"Module"})),se="【歌枠/ #パレ研24時間リレー 】私たちの歌を聞けぇぇええええ！！【＃がぶるか/ #鎖乙女がぶ /#彩音るか】",de="鎖乙女がぶ / Saotome Gabu 【パレプロ研究生】",le="ab91wpuk7Ow",ae="2025-05-05",re=`0:02:36 1.ロボキッス / W(ダブルユー)
0:06:19 2.てもでもの涙 / AKB48
0:10:12 3.ハート型ウイルス / AKB48
0:20:07 4.secret base 〜君がくれたもの〜 / ZONE
0:27:44 5.点描の唄 / Mrs. GREEN APPLE(feat. 井上苑子)
0:39:21 6.コネクト / ClariS
0:47:03 7.StaRt / Mrs. GREEN APPLE
0:51:55 8.SOS / 黛冬優子 (CV.幸村恵理)
1:00:20 9.花になって / 緑黄色社会
1:04:55 10.ロキ / みきとP feat. 鏡音リン、鏡音レン
1:15:25 11.チューリングラブ feat.Sou / ナナヲアカリ
1:24:17 12.だいしきゅーだいしゅき / femme fatale
1:37:29 13.ライラック / Mrs. GREEN APPLE
1:54:43 14.トキメキ禁断症状 / RouteHeart`,Me={video_title:se,video_artist:de,video_id:le,video_publish_date_str:ae,song_timeline:re},ke=Object.freeze(Object.defineProperty({__proto__:null,default:Me,song_timeline:re,video_artist:de,video_id:le,video_publish_date_str:ae,video_title:se},Symbol.toStringTag,{value:"Module"})),ve="【歌枠】初見さん大歓迎！リクエスト歌枠！そして今日はメイドの日・・・【#鎖乙女がぶ /パレプロ研究生】",ce="鎖乙女がぶ / Saotome Gabu 【パレプロ研究生】",ue="id4tAzHCPvI",Se="2025-05-10",be=`🐺💜🎶セットリスト🐺💜🎶
0:00:00 OP
0:04:21 開始
0:15:31 01.プラチナ / 坂本真綾
0:23:54 02.カレンダーガール / わか・ふうり・すなお from STAR☆ANIS
0:35:26 03.トキメキ禁断症状 / RouteHeart
0:47:33 04.サイレントマジョリティー / 欅坂46
0:57:37 05.白い雪のプリンセスは / のぼる↑
1:10:55 06.恋愛サーキュレーション / 千石撫子(花澤香菜)
1:22:51 07.MIRACLE NEW STORY / Liella!
1:30:52 08.ハム太郎 とっとこうた / ハムちゃんず
1:34:03 09.おどるポンポコリン / E-Girls
1:38:55 10.星間飛行 / ランカ・リー=中島愛
1:42:57 11.放課後オーバーフロウ / ランカ・リー=中島愛
1:50:07 12.ワルキューレは裏切らない / ワルキューレ
1:55:08 13.ルンがピカッと光ったら / ワルキューレ
2:02:43 14.GIRAFFE BLUES / ワルキューレ
2:10:57 15.アスノヨゾラ哨戒班 / Orangestar
2:14:27 16.君の知らない物語 / supercell
2:20:16 17.サウダージ / ポルノグラフィティ
2:31:17 18.気まぐれロマンティック / いきものがかり
2:38:15 19.ラヴィ/ すりぃ
2:46:06 20.花に亡霊 / ヨルシカ


おつがぶでした〜

カレンダーガール、ほんと好きな曲なので聴けてよかった〜！
トキメキ禁断症状やサイレントマジョリティーやMIRACLE NEW STORYもすごく良かったですね…！
がぶちゃんの歌声ほんときれいで、もっといっぱい聴きたくなっちゃいます！

またのリクエスト歌枠も楽しみにしてますね！`,ye={video_title:ve,video_artist:ce,video_id:ue,video_publish_date_str:Se,song_timeline:be},Fe=Object.freeze(Object.defineProperty({__proto__:null,default:ye,song_timeline:be,video_artist:ce,video_id:ue,video_publish_date_str:Se,video_title:ve},Symbol.toStringTag,{value:"Module"}));export{Ne as _,je as a,Ie as b,Ce as c,Ge as d,Be as e,Le as f,Ue as g,Ke as h,De as i,ze as j,Ye as k,ke as l,Fe as m};
