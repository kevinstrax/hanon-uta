const e="【歌枠/カラオケJOYSOUND for STREAMER】初めての歌枠♡アイドル縛り【#鎖乙女がぶ /パレプロ研究生】",t="鎖乙女がぶ / Saotome Gabu 【パレプロ研究生】",i="nMmWVciVOgk",o="2024-12-27",n=`🐺💜セットリスト🐺💜
0:00:00 OP
0:02:05 開始、ミュート芸
0:03:15 01.星間飛行～Freyja Ver.～／ワルキューレ
0:12:05 02.だいしきゅーだいしゅき / femme fatale
0:17:25 03.サインはB / B小町 
0:23:55 04.わたしの一番かわいいところ / FRUITS ZIPPER
0:30:23 05.Starlight Prologue / Liella!
0:34:42 06.きっかけ / 乃木坂46 
0:41:13 07.サイレントマジョリティー / 欅坂46
0:49:37 08.ハート型ウイルス / AKB48
0:55:20 09.夢をかなえてドラえもん / Mao
1:00:43 みそラーメン
1:04:33 10.ぎゅっと / Sexy Zone
1:11:17 11.moreきゅん奴隷 / 戦慄かなの
1:20:13 12.恋のロケットランチャー / 佐々木喫茶
1:25:42 13.ポニーテールとシュシュ / AKB48
1:35:09 14. fashion check! / わか・ふうり・すなお・れみ・もえ from STAR☆ANIS
1:43:15 15.SOS / 黛　冬優子(幸村恵理) 
1:51:56 16.トライアングラー / 坂本真綾
2:02:40 17.Snow halation / μ's
2:11:18 18.放課後オーバーフロウ / ランカ・リー＝中島愛
2:19:00 ED


おつがぶでした！
歌声綺麗でとても良きでしたね〜！
しっかりセトリも練ってきてて流石でした！`,It={video_title:e,video_artist:t,video_id:i,video_publish_date_str:o,song_timeline:n},di=Object.freeze(Object.defineProperty({__proto__:null,default:It,song_timeline:n,video_artist:t,video_id:i,video_publish_date_str:o,video_title:e},Symbol.toStringTag,{value:"Module"})),_="【歌枠/カラオケJOYSOUND for STREAMER】新年1発目はオールジャンル歌枠っ！♡【#鎖乙女がぶ /パレプロ研究生】",d="鎖乙女がぶ / Saotome Gabu 【パレプロ研究生】",s="_DNXs9CJh3w",l="2025-01-06",a=`歌枠配信、おつがぶ～

[セトリ]
0:02:06 01. ムーンライト伝説 / DALI
0:10:01 02. 君の知らない物語 / supercell
0:19:38 03. 少女レイ / みきとP
0:28:48 04. 気まぐれロマンティック / いきものがかり
0:37:28 05. MIRACLE NEW STORY / Liella!
0:45:50 06. Shocking Party / A-RISE
0:55:54 07. 硝子ドール / もえ,すなお from STAR☆ANIS
1:07:51 08. サウダージ / ポルノグラフィティ
1:14:09 09. StaRt / Mrs. GREEN APPLE
1:23:05 10. 花に亡霊 / ヨルシカ
1:32:45 11. プラチナ / 坂本真綾
1:41:36 12. アイのシナリオ / CHiCO with HoneyWorks
1:49:01 13. きみわずらい / まねきケチャ
1:59:56 14. コネクト / ClariS`,Lt={video_title:_,video_artist:d,video_id:s,video_publish_date_str:l,song_timeline:a},si=Object.freeze(Object.defineProperty({__proto__:null,default:Lt,song_timeline:a,video_artist:d,video_id:s,video_publish_date_str:l,video_title:_},Symbol.toStringTag,{value:"Module"})),r="【ボカロ歌枠/カラオケJOYSOUND for STREAMER】懐かしのボカロ多め歌枠行くぞ～！！【#鎖乙女がぶ /パレプロ研究生】",v="鎖乙女がぶ / Saotome Gabu 【パレプロ研究生】",c="6TsXn5PJzFo",u="2025-01-12",S=`🐺💜セットリスト🐺💜
0:00:00 OP 
0:02:17 01.ワールドイズマイン / supercell
0:12:28 02.おじゃま虫 / DECO*27
0:23:10 03.ピエロ / 伊東歌詞太郎
0:32:10 04.地球最後の告白を / kemu
0:39:28 05.ニア / 夏代孝明
0:44:01 06.ラヴィ / すりぃ
0:50:32 07.アスノヨゾラ哨戒班 / Orangestar
0:55:30 08.ロミオとシンデレラ / doriko


おつがぶでした〜

初手ワールドイズマインで横転してしまいましたね…
地球最後の告白をとかアスノヨゾラ哨戒班、ロミオとシンデレラもすごく好きな曲なので聴けてよかったです！

ニアは初めて聴いたのですが、すごくきれいな曲で原曲も聴きたくなっちゃいました！`,Gt={video_title:r,video_artist:v,video_id:c,video_publish_date_str:u,song_timeline:S},li=Object.freeze(Object.defineProperty({__proto__:null,default:Gt,song_timeline:S,video_artist:v,video_id:c,video_publish_date_str:u,video_title:r},Symbol.toStringTag,{value:"Module"})),b="【カラオケJOYSOUND for STREAMER】高評価150行くまで終われまてんアニソン歌枠！！【#鎖乙女がぶ /パレプロ研究生】",m="鎖乙女がぶ / Saotome Gabu 【パレプロ研究生】",g="v8qbOm3yfRo",p="2025-01-25",$=`🐺💜セットリスト🐺💜
0:00:00 OP
0:03:08 開始
0:11:21 01.ユメセカイ / 戸松遥 
0:19:57 02.乙女のポリシー / 石田よう子
0:26:56 03.花になって / 緑黄色社会
0:34:13 04.破滅の純情 / ワルキューレ
0:42:57 05.ワルキューレは裏切らない / ワルキューレ
0:47:50 06.ルンがピカッと光ったら / ワルキューレ
0:55:09 07.トライアングラー / 坂本真綾
1:02:32 08.ニンジーン Loves you yeah! / ランカ・リー=中島愛
1:07:45 09.グランドエスケープ / RADWIMPS
1:15:11 10.サインはB / B小町
1:27:16 11.POP IN 2 / B小町
1:36:19 12.Overfly / 春奈るな
1:43:37 13.Ubiquitous dB / ユナ(CV:神田沙也加)
1:55:10 14.Second Sparkle / Liella!
2:00:59 15.貴方の側に。 / りりあ。


おつがぶでした～
お昼からがぶちゃんのお歌いっぱい聴けて楽しかったです！
最後の3曲はどれも初めて聴いたのですが、どれも良い曲でしたね…！`,zt={video_title:b,video_artist:m,video_id:g,video_publish_date_str:p,song_timeline:$},ai=Object.freeze(Object.defineProperty({__proto__:null,default:zt,song_timeline:$,video_artist:m,video_id:g,video_publish_date_str:p,video_title:b},Symbol.toStringTag,{value:"Module"})),O="【歌枠/カラオケJOYSOUND for STREAMER】平成のJ-POP縛り歌枠‼懐かしさで震えて眠れ【#鎖乙女がぶ /パレプロ研究生】",f="鎖乙女がぶ / Saotome Gabu 【パレプロ研究生】",h="x6c4IX-Z-YQ",A="2025-02-09",T=`0:00:00 OP
0:02:26 01. GLAMOROUS SKY / NANA starring MIKA NAKASHIMA
0:16:00 02.八月の夜 / Silent Siren
0:23:33 03.気まぐれロマンティック / いきものがかり
0:31:08 04.サウダージ / ポルノグラフィティ
0:35:17 05.シャボン玉 / モーニング娘。
0:44:13 06.小さな恋のうた / MONGOL800
0:48:30 07.ヒカリヘ / miwa
0:53:33 08.三日月 / 絢香
0:58:40 09.ハナミズキ / 一青窈
1:07:57 10.ただ君に晴れ / ヨルシカ
1:15:52 11.瞳 / 大原櫻子
1:25:21 12.高嶺の花子さん / back number
1:30:21 13.イチブトゼンブ / B'z
1:38:55 14.おどるポンポコリン / E-Girls
1:46:51 15.Catch You Catch Me / グミ
1:55:30 16.乙女のポリシー / 石田よう子
2:01:38 17.ロマンスの神様 / 広瀬 香美
2:16:01 18.ヘビーローテーション / AKB48
2:21:09 19.青春アミーゴ / 修二と彰`,Ct={video_title:O,video_artist:f,video_id:h,video_publish_date_str:A,song_timeline:T},ri=Object.freeze(Object.defineProperty({__proto__:null,default:Ct,song_timeline:T,video_artist:f,video_id:h,video_publish_date_str:A,video_title:O},Symbol.toStringTag,{value:"Module"})),P="【歌枠/カラオケJOYSOUND for STREAMER】バレンタインのあま～い恋愛ソング召し上がれ♡【#鎖乙女がぶ /パレプロ研究生】",y="鎖乙女がぶ / Saotome Gabu 【パレプロ研究生】",E="ZSoc5mLy9v0",M="2025-02-14",R=`🐺💜🎶セットリスト🐺💜🎶
0:00:00 OP
0:02:26 01.Love so sweet / 嵐
0:14:13 02.あたしを彼女にしたいなら / コレサワ
0:18:25 03.SOS / 黛冬優子 (CV.幸村恵理)
0:29:45 04.Bittersweet / 嵐
0:34:47 05.バレンタイン・キッス / 国生 さゆり
0:47:13 06.だいしきゅーだいしゅき / femme fatale
0:54:59 07.しゅきぴ / =LOVE
1:03:03 08.おじゃま虫 / DECO*27
1:12:09 09.わたしの一番かわいいところ / FRUITS ZIPPER
1:18:24 10.金曜日のおはよう / Gero
1:24:25 11.ワールドイズマイン / supercell
1:29:45 12.キャットラビング / 香椎モイミ
1:33:58 13.ハート型ウイルス / AKB48
1:41:15 14.初恋サイダー/Buono!
1:53:13 15.恋愛サーキュレーション / 千石撫子(花澤香菜) 


おつがぶでした～
遅れ馳せながらセトリをば
とっても甘々なセトリでたすかりすぎちゃいましたね…！`,Ut={video_title:P,video_artist:y,video_id:E,video_publish_date_str:M,song_timeline:R},vi=Object.freeze(Object.defineProperty({__proto__:null,default:Ut,song_timeline:R,video_artist:y,video_id:E,video_publish_date_str:M,video_title:P},Symbol.toStringTag,{value:"Module"})),j="【 #Vアイドルが歌う2次元アイドル歌枠リレー 】7番手！作品被り無しで盛り上がるぞっ！【#鎖乙女がぶ /パレプロ研究生】",N="鎖乙女がぶ / Saotome Gabu 【パレプロ研究生】",I="ZOYzqWUvWMQ",L="2025-03-01",G=`0:01:31 01.星間飛行 / ランカ・リー=中島愛 / マクロスF
0:08:43 02. STAR☆T☆RAIN / B小町 ルビー(CV:伊駒ゆりえ) 有馬かな(CV:潘めぐみ) MEMちょ(CV:大久保瑠美) / 推しの子
0:14:14 03.硝子ドール / もえ from STAR ANIS / アイカツ！
0:20:45 04.Cutie Panther / BiBi ～絢瀬絵里(南條愛乃)、西木野真姫(Pile)、矢澤にこ(徳井青空) from μ's～ / ラブライブ！
0:27:13 05.Starlight Prologue / Liella! / ラブライブ！スーパースター!!`,Bt={video_title:j,video_artist:N,video_id:I,video_publish_date_str:L,song_timeline:G},ci=Object.freeze(Object.defineProperty({__proto__:null,default:Bt,song_timeline:G,video_artist:N,video_id:I,video_publish_date_str:L,video_title:j},Symbol.toStringTag,{value:"Module"})),z="【歌枠/カラオケJOYSOUND for STREAMER】歌ったり喋ったり、寝たり。【#鎖乙女がぶ /パレプロ研究生】",C="鎖乙女がぶ / Saotome Gabu 【パレプロ研究生】",U="Avby-tqdntY",B="2025-03-07",k=`0:00:00 OP
0:01:13 開始
0:11:46 01.夜もすがら君想ふ / TOKOTOKO(西沢さんP)
0:27:15 02.僕らの戦場～Freyja Solo Edition～ / ワルキューレ
0:58:05 03.ANIMA / ReoNa
1:08:00 04.未来予報ハレルヤ！ / Liella!
1:49:57 05.シルエット / KANA-BOON
2:00:43 06.ワルキューレは裏切らない / ワルキューレ`,kt={video_title:z,video_artist:C,video_id:U,video_publish_date_str:B,song_timeline:k},ui=Object.freeze(Object.defineProperty({__proto__:null,default:kt,song_timeline:k,video_artist:C,video_id:U,video_publish_date_str:B,video_title:z},Symbol.toStringTag,{value:"Module"})),K="【歌枠/カラオケJOYSOUND for STREAMER】プロセカ収録ボカロ縛り歌枠！【#鎖乙女がぶ /パレプロ研究生】",D="鎖乙女がぶ / Saotome Gabu 【パレプロ研究生】",V="VFnobl-_9MI",Y="2025-04-06",w=`歌枠配信、おつがぶ～

[セトリ]
0:02:12 01.少女レイ / みきとP
0:21:35 02.白い雪のプリンセスは / のぼる↑
0:30:40 03.ハイドアンド・シーク / 19's Sound Factory
0:40:12 04.ハッピーシンセサイザ / EasyPop
0:45:33 05.夜もすがら君想ふ / TOKOTOKO(西沢さんP)
0:59:58 06.キャットラビング / 香椎モイミ
1:03:20 07.ワールドイズマイン / supercell
1:14:09 08.ロミオとシンデレラ / doriko
1:21:31 09.ヴァンパイア / DECO*27
1:37:42 10.エイリアンエイリアン / ナユタン星人
1:46:21 11.嗚呼、素晴らしきニャン生 / Nem
1:53:15 12.地球最後の告白を / kemu
1:58:18 13.ニア / 夏代孝明`,Kt={video_title:K,video_artist:D,video_id:V,video_publish_date_str:Y,song_timeline:w},Si=Object.freeze(Object.defineProperty({__proto__:null,default:Kt,song_timeline:w,video_artist:D,video_id:V,video_publish_date_str:Y,video_title:K},Symbol.toStringTag,{value:"Module"})),F="【歌枠/カラオケJOYSOUND for STREAMER】高評価150行くまで終われない歌枠！！【#鎖乙女がぶ /パレプロ研究生】",J="鎖乙女がぶ / Saotome Gabu 【パレプロ研究生】",H="QnjsujoZ-P8",W="2025-04-12",q=`🐺💜🎶セットリスト🐺💜🎶
0:00:00 OP
0:02:16 開始
0:10:13 01.君の知らない物語 / supercell
0:21:44 02.放課後オーバーフロウ / ランカ・リー=中島愛
0:29:06 03.ライオン / ワルキューレ
0:38:09 04.時の迷宮 / ランカ・リー=中島愛、シェリル・ノーム starring May'n
0:48:42 05.ユニバーサル・バニー / シェリル・ノーム starring May'n
1:01:28 06.GIRAFFE BLUES / ワルキューレ
1:09:43 07.美少女無罪♡パイレーツ / 宝鐘マリン
1:17:32 08.花になって - Be a flower / 緑黄色社会
1:24:29 09.Special Color / Liella!
1:32:50 10.ダイヤモンドハッピー / わか・ふうり・すなお from STAR☆ANIS
1:42:04 11.恋するフォーチュンクッキー / AKB48
1:52:32 12.ハート型ウイルス / AKB48
2:00:29 13.残酷な天使のテーゼ / 高橋洋子
2:16:16 14.サウダージ / ポルノグラフィティ
2:27:35 15.だいしきゅーだいしゅき / emme fatale
2:34:58 16.おじゃま虫 / DECO*27
2:38:46 雑談・告知タイム


おつがぶでした〜

Special Color初めて聴いたのですがとても良かったですね…
ダイヤモンドハッピーやハート型ウイルス、おじゃま虫とかかわいすぎました！

汗のお話助かりました🙏
メンシも開始したらぜひ入りたいですし、どんなスタンプ使えるようになるのかも楽しみです！`,Dt={video_title:F,video_artist:J,video_id:H,video_publish_date_str:W,song_timeline:q},bi=Object.freeze(Object.defineProperty({__proto__:null,default:Dt,song_timeline:q,video_artist:J,video_id:H,video_publish_date_str:W,video_title:F},Symbol.toStringTag,{value:"Module"})),Q="【 アイカツ！縛り歌枠 】アイカツ！のかっこいい＆キレイ系の歌を沢山歌う！！【#がぶかなめ #鎖乙女がぶ /#常磐カナメ】",Z="鎖乙女がぶ / Saotome Gabu 【パレプロ研究生】",x="dQeEFcMcQoU",X="2025-04-27",ee=`0:00:00 OP
0:03:01 開始
0:04:22 01.Move on now! / わか・ふうり・すなお・りすこ from STAR☆ANIS
0:11:50 02.オトナモード / りすこ・もな from STAR☆ANIS
0:21:08 03.タルト・タタン / もな from AIKATSU☆STARS!
0:28:10 04. Wake up my music / りさ・えいみ
0:36:32 05. MUSIC of DREAM!!! / せな from AIKATSU☆STARS!
0:46:34 06.Take Me Higher / りすこ・もえ・ゆな from STAR☆ANIS
0:57:38 07.硝子ドール  / もえ from STAR☆ANIS`,Vt={video_title:Q,video_artist:Z,video_id:x,video_publish_date_str:X,song_timeline:ee},mi=Object.freeze(Object.defineProperty({__proto__:null,default:Vt,song_timeline:ee,video_artist:Z,video_id:x,video_publish_date_str:X,video_title:Q},Symbol.toStringTag,{value:"Module"})),te="【誕生日配信/カラオケJOYSOUND for STREAMER】最後に重大発表あり！！お誕生日当日！！私が主役だ！！【#鎖乙女がぶ /#パレプロ研究生 】",ie="鎖乙女がぶ / Saotome Gabu 【パレプロ研究生】",oe="dQx_7qmiQ8w",ne="2025-05-01",_e=`1:38:38 1.SOS / 黛冬優子 (CV.幸村恵理)
1:50:21 2.ハム太郎とっとこうた / ハムちゃんず
1:53:16 3.夜もすがら君想ふ / TOKOTOKO(西沢さんP)`,Yt={video_title:te,video_artist:ie,video_id:oe,video_publish_date_str:ne,song_timeline:_e},gi=Object.freeze(Object.defineProperty({__proto__:null,default:Yt,song_timeline:_e,video_artist:ie,video_id:oe,video_publish_date_str:ne,video_title:te},Symbol.toStringTag,{value:"Module"})),de="【歌枠/ #パレ研24時間リレー 】私たちの歌を聞けぇぇええええ！！【＃がぶるか/ #鎖乙女がぶ /#彩音るか】",se="鎖乙女がぶ / Saotome Gabu 【パレプロ研究生】",le="ab91wpuk7Ow",ae="2025-05-05",re=`0:02:36 1.ロボキッス / W(ダブルユー)
0:06:19 2.てもでもの涙 / AKB48
0:10:12 3.ハート型ウイルス / AKB48
0:20:07 4.secret base 〜君がくれたもの〜 / ZONE
0:27:44 5.点描の唄 / Mrs. GREEN APPLE(feat. 井上苑子)
0:39:21 6.コネクト / ClariS
0:47:03 7.StaRt / Mrs. GREEN APPLE
0:51:55 8.SOS / 黛冬優子 (CV.幸村恵理)
1:00:20 9.花になって / 緑黄色社会
1:04:55 10.ロキ / みきとP feat. 鏡音リン、鏡音レン
1:15:25 11.チューリングラブ feat.Sou / ナナヲアカリ
1:24:17 12.だいしきゅーだいしゅき / femme fatale
1:37:29 13.ライラック / Mrs. GREEN APPLE
1:54:43 14.トキメキ禁断症状 / RouteHeart`,wt={video_title:de,video_artist:se,video_id:le,video_publish_date_str:ae,song_timeline:re},pi=Object.freeze(Object.defineProperty({__proto__:null,default:wt,song_timeline:re,video_artist:se,video_id:le,video_publish_date_str:ae,video_title:de},Symbol.toStringTag,{value:"Module"})),ve="【歌枠】初見さん大歓迎！リクエスト歌枠！そして今日はメイドの日・・・【#鎖乙女がぶ /パレプロ研究生】",ce="鎖乙女がぶ / Saotome Gabu 【パレプロ研究生】",ue="id4tAzHCPvI",Se="2025-05-10",be=`🐺💜🎶セットリスト🐺💜🎶
0:00:00 OP
0:04:21 開始
0:15:31 01.プラチナ / 坂本真綾
0:23:54 02.カレンダーガール / わか・ふうり・すなお from STAR☆ANIS
0:35:26 03.トキメキ禁断症状 / RouteHeart
0:47:33 04.サイレントマジョリティー / 欅坂46
0:57:37 05.白い雪のプリンセスは / のぼる↑
1:10:55 06.恋愛サーキュレーション / 千石撫子(花澤香菜)
1:22:51 07.MIRACLE NEW STORY / Liella!
1:30:52 08.ハム太郎 とっとこうた / ハムちゃんず
1:34:03 09.おどるポンポコリン / E-Girls
1:38:55 10.星間飛行 / ランカ・リー=中島愛
1:42:57 11.放課後オーバーフロウ / ランカ・リー=中島愛
1:50:07 12.ワルキューレは裏切らない / ワルキューレ
1:55:08 13.ルンがピカッと光ったら / ワルキューレ
2:02:43 14.GIRAFFE BLUES / ワルキューレ
2:10:57 15.アスノヨゾラ哨戒班 / Orangestar
2:14:27 16.君の知らない物語 / supercell
2:20:16 17.サウダージ / ポルノグラフィティ
2:31:17 18.気まぐれロマンティック / いきものがかり
2:38:15 19.ラヴィ/ すりぃ
2:46:06 20.花に亡霊 / ヨルシカ


おつがぶでした〜

カレンダーガール、ほんと好きな曲なので聴けてよかった〜！
トキメキ禁断症状やサイレントマジョリティーやMIRACLE NEW STORYもすごく良かったですね…！
がぶちゃんの歌声ほんときれいで、もっといっぱい聴きたくなっちゃいます！

またのリクエスト歌枠も楽しみにしてますね！`,Ft={video_title:ve,video_artist:ce,video_id:ue,video_publish_date_str:Se,song_timeline:be},$i=Object.freeze(Object.defineProperty({__proto__:null,default:Ft,song_timeline:be,video_artist:ce,video_id:ue,video_publish_date_str:Se,video_title:ve},Symbol.toStringTag,{value:"Module"})),me="【雑談/カラオケJOYSOUND for STREAMER】喋りながら歌って世界を救う。【#鎖乙女がぶ /#パレプロ研究生 】",ge="鎖乙女がぶ / Saotome Gabu 【パレプロ研究生】",pe="lm29O5cM04c",$e="2025-06-02",Oe=`🐺💜🎶セットリスト🐺💜🎶
0:00:00 OP
0:04:15 開始
0:16:03 01.ノンフィクション!! / Liella!
0:26:43 02.Dazzling Game / Liella!
0:37:58 03.シェキラ☆☆☆ / Liella!
1:01:16 04. So Beautiful Story / るか・せな from AIKATSU☆STARS!
1:10:09 05.Let's アイカツ! / るか・もな・みき from AIKATSU☆STARS!
1:14:41 06.SHINING LINE* / わか・ふうり・ゆな from STAR☆ANIS
1:32:12 07.Blowin' in the Mind / 森園わかな(CV.内田真礼)
1:42:46 08.眩耀夜行 / スリーズブーケ
2:06:28 09.Snow halation / μ's
2:17:15 10.Starlight Prologue / Liella!


おつがぶでした～

結構初めて聴く曲ばかりだったのですが、どの曲も良きでしたね…！
Liella!曲あまり知らなかったけどノンフィクション!! やシェキラ☆☆☆とても良かった…
Blowin' in the Mindも聴けて嬉しかったです！

(欲を言えばもっとプリリズ曲聴きたい気持ちあったので、今後聴ける可能性に期待していますね…！)`,Jt={video_title:me,video_artist:ge,video_id:pe,video_publish_date_str:$e,song_timeline:Oe},Oi=Object.freeze(Object.defineProperty({__proto__:null,default:Jt,song_timeline:Oe,video_artist:ge,video_id:pe,video_publish_date_str:$e,video_title:me},Symbol.toStringTag,{value:"Module"})),fe="【雑談/カラオケJOYSOUND for STREAMER】デビュー半年記念雑談！歌も歌うよ～！【#鎖乙女がぶ /#パレプロ研究生 】",he="鎖乙女がぶ / Saotome Gabu 【パレプロ研究生】",Ae="Wce689I0ypM",Te="2025-06-21",Pe=`一旦、一枠目、おつがぶ～
デビュー半年おめでとうございます🎉

[セトリ]
00:22:48 1.眩耀夜行 / スリーズブーケ`,Ht={video_title:fe,video_artist:he,video_id:Ae,video_publish_date_str:Te,song_timeline:Pe},fi=Object.freeze(Object.defineProperty({__proto__:null,default:Ht,song_timeline:Pe,video_artist:he,video_id:Ae,video_publish_date_str:Te,video_title:fe},Symbol.toStringTag,{value:"Module"})),ye="【雑談/カラオケJOYSOUND for STREAMER】デビュー半年記念雑談！歌も歌うよ～！【#鎖乙女がぶ /#パレプロ研究生 】",Ee="鎖乙女がぶ / Saotome Gabu 【パレプロ研究生】",Me="0yWTE2WZdyg",Re="2025-06-21 00:00:01",je=`🐺set list🩰

0:13:07 Holiday∞Holiday / スリーズブーケ
0:20:43 Bubble Rise / 澁谷かのん・ウィーン•マルガレーテ・鬼塚冬毬
0:34:33 START!! True dreams / Liella!
0:47:33 ココロ充電！ / プリティーリズム・オーロラドリーム 天宮りずむ
1:00:26 START DASH SENSATION / アイカツ！大空あかり
1:09:30 Dance in the rain / アイカツ！星宮いちご
1:28:16 SOS / シャニマス 黛 冬優子
1:36:05 ドリームインブルーム！ / Palette Project

練習
0:43:13 ビタミンSUMMER！ / Liella!
0:54:58 cherry-picking days / プリティーリズム・レインボーライブ 福原あん•森園わかな

半年おめでとう🎉セトリ無かったから置いとくねー
がぶちゃんアイドル曲とか可愛い歌似合うねドリブルもめちゃ良かった！！
`,Wt={video_title:ye,video_artist:Ee,video_id:Me,video_publish_date_str:Re,song_timeline:je},hi=Object.freeze(Object.defineProperty({__proto__:null,default:Wt,song_timeline:je,video_artist:Ee,video_id:Me,video_publish_date_str:Re,video_title:ye},Symbol.toStringTag,{value:"Module"})),Ne="【雑談/カラオケJOYSOUND for STREAMER】しっとり優しめの声でお歌を歌って寝かしつける【#鎖乙女がぶ /#パレプロ研究生 】",Ie="鎖乙女がぶ / Saotome Gabu 【パレプロ研究生】",Le="68lSA5pTNLU",Ge="2025-06-29",ze=`〜本日のセトリ〜
22:59  君の知らない物語/supercell
34:08  がぶちゃん、はじめてのおつかいお水買い出し編 
49:23  未来の音が聴こえる/Liella!
1:03:40  風になる/つじあやの
1:34:46  Wake up my music/りさ・えいみ(アイカツ)
1:44:39  ただ君に晴れ/ヨルシカ
1:49:52  少女レイ/みきとP
2:02:52  花に亡霊/ヨルシカ
2:18:21  怪獣のバラード(アカペラ)/-
1:15:01  カメラモードで遊ぶがぶちゃん可愛いからみんな見ていって〜！`,qt={video_title:Ne,video_artist:Ie,video_id:Le,video_publish_date_str:Ge,song_timeline:ze},Ai=Object.freeze(Object.defineProperty({__proto__:null,default:qt,song_timeline:ze,video_artist:Ie,video_id:Le,video_publish_date_str:Ge,video_title:Ne},Symbol.toStringTag,{value:"Module"})),Ce="【歌枠/Karaoke】マクロス縛り歌枠！私の歌を聴けぇええ！【#鎖乙女がぶ /#パレプロ研究生 】",Ue="鎖乙女がぶ / Saotome Gabu 【パレプロ研究生】",Be="wz7f_dIilLM",ke="2025-07-13",Ke=`【🐺🩰セトリ🐺💜🎶】
00:12:41 トライアングラー / 坂本真綾
00:23:20 星間飛行 〜Freyja Ver.〜 / ワルキューレ
00:36:53 僕らの戦場 〜Freyja Solo Edition〜 / ワルキューレ
00:52:17 Absolute 5 / ワルキューレ
01:02:36 一度だけの恋なら / ワルキューレ
01:31:28 破滅の純情 / ワルキューレ
01:39:52 AXIA 〜ダイスキでダイキライ〜 / ワルキューレ(ワンコーラス)  
01:44:23 放課後オーバーフロウ / ランカ・リー=中島愛
01:51:14 ルンがピカッと光ったら / ワルキューレ
02:09:58 不確定性⭐︎COSMIC MOVEMENT / ワルキューレ
02:15:57 GIRAFFE BLUES / ワルキューレ
02:21:17 ライオン / May’n/中島愛`,Qt={video_title:Ce,video_artist:Ue,video_id:Be,video_publish_date_str:ke,song_timeline:Ke},Ti=Object.freeze(Object.defineProperty({__proto__:null,default:Qt,song_timeline:Ke,video_artist:Ue,video_id:Be,video_publish_date_str:ke,video_title:Ce},Symbol.toStringTag,{value:"Module"})),De="【#ゲキパレ歌枠リレー】曲のギャップで風邪を引かせて涼しくさせちゃうぞっ！☆【#鎖乙女がぶ /#パレプロ研究生】",Ve="鎖乙女がぶ / Saotome Gabu 【パレプロ研究生】",Ye="9bdkkxfLpLk",we="2025-07-19",Fe=`🐺💜🎶セットリスト🐺💜🎶
0:00:00 OP
0:01:13 01.Trancend Lights / 星咲あかり(CV:赤尾ひかる)、高瀬梨緒(CV:久保ユリカ)、柏木美亜(CV:和氣あず未)、東雲つむぎ(CV:和泉風花)、皇城セツナ(CV:八巻アンナ)
0:09:11 02. Sweet♡Heart☆Palette♪ / Palette Project
0:18:27 03. Over Voltage / 高瀬梨緒(CV:久保ユリカ) 
0:26:21 04.トキメキ禁断症状 / RouteHeart


おつがぶでした～
かっこいい曲からかわいい曲まで、余すところなく堪能できました！
トキメキ禁断症状、分かり手すぎましたね…！`,Zt={video_title:De,video_artist:Ve,video_id:Ye,video_publish_date_str:we,song_timeline:Fe},Pi=Object.freeze(Object.defineProperty({__proto__:null,default:Zt,song_timeline:Fe,video_artist:Ve,video_id:Ye,video_publish_date_str:we,video_title:De},Symbol.toStringTag,{value:"Module"})),Je="【歌枠/Karaoke】夏を感じるさわやかな曲縛り！！【#鎖乙女がぶ /#パレプロ研究生 】",He="鎖乙女がぶ / Saotome Gabu 【パレプロ研究生】",We="HSYcu3NnbLw",qe="2025-07-26",Qe=`🐺💜🎶セットリスト🐺💜🎶
0:00:00 OP
0:04:20 開始
0:13:24 01.八月の夜 / SILENT SIREN
0:22:26 02.ポニーテールとシュシュ / AKB48
1:03:06 03.恋になりたいAQUARIUM / Aqours
1:13:18 04.おやすみ泣き声、さよなら歌姫 / クリープハイプ
1:17:24 05.花に亡霊 / ヨルシカ
1:22:09 06.少女レイ / みきとP
1:32:44 07.笑顔のSuncatcher / りすこ・もな from STAR☆ANIS
1:38:10 08.ビタミンSUMMER! / Liella!
1:44:51 09.青と夏 / Mrs. GREEN APPLE
1:51:49 10.夏の花は向日葵だけじゃない / 櫻坂46
2:08:34 11.secret base ～君がくれたもの～ / ZONE


おつがぶでした〜
とても夏感じられる歌枠でしたね…！
恋アクや少女レイ好きな曲だから聴けてよかったです！`,xt={video_title:Je,video_artist:He,video_id:We,video_publish_date_str:qe,song_timeline:Qe},yi=Object.freeze(Object.defineProperty({__proto__:null,default:xt,song_timeline:Qe,video_artist:He,video_id:We,video_publish_date_str:qe,video_title:Je},Symbol.toStringTag,{value:"Module"})),Ze="【雑談】#パレプロ感謝祭2025 のあった夜の寝落ちもちもち【#鎖乙女がぶ / #パレプロ研究生 】",xe="鎖乙女がぶ / Saotome Gabu 【パレプロ研究生】",Xe="jWKjtPdNkGQ",et="2025-08-02",tt=`【🐺🩰お歌TS🐺💜🎶】
0:06:13 ドリームインブルーム！/Palette Project
0:22:24 Re:Myself/Altimate!! (アカペラ)`,Xt={video_title:Ze,video_artist:xe,video_id:Xe,video_publish_date_str:et,song_timeline:tt},Ei=Object.freeze(Object.defineProperty({__proto__:null,default:Xt,song_timeline:tt,video_artist:xe,video_id:Xe,video_publish_date_str:et,video_title:Ze},Symbol.toStringTag,{value:"Module"})),it="【雑談】緊急配信！初見さん大歓迎♡【#鎖乙女がぶ /#パレプロ研究生 】",ot="鎖乙女がぶ / Saotome Gabu 【パレプロ研究生】",nt="sg7gWCvTdzc",_t="2025-08-11",dt=`【🐺🩰お歌🐺💜🎶】
2:53:41 Re:Myself/Altimate!! (オケありFull)
※パレ感後夜祭のリベンジ`,ei={video_title:it,video_artist:ot,video_id:nt,video_publish_date_str:_t,song_timeline:dt},Mi=Object.freeze(Object.defineProperty({__proto__:null,default:ei,song_timeline:dt,video_artist:ot,video_id:nt,video_publish_date_str:_t,video_title:it},Symbol.toStringTag,{value:"Module"})),st="【朝枠/雑談】初見さん20人・高評価200件いくまで終われない朝活♡【#鎖乙女がぶ /#パレプロ研究生 】",lt="鎖乙女がぶ / Saotome Gabu 【パレプロ研究生】",at="lPcmbzQqa4o",rt="2025-08-21",vt=`【🐺🩰朝活お歌セトリ🐺💜🎶】
2:06:55 Let’s be ONE/Liella!
2:15:16 夢をかなえてドラえもん/mao
2:26:28 ライラック/Mrs. GREEN APPLE

自分用に拾ってみたけど、お歌の時間前に出勤・通学で聴けなかった方にも需要あるかな？`,ti={video_title:st,video_artist:lt,video_id:at,video_publish_date_str:rt,song_timeline:vt},Ri=Object.freeze(Object.defineProperty({__proto__:null,default:ti,song_timeline:vt,video_artist:lt,video_id:at,video_publish_date_str:rt,video_title:st},Symbol.toStringTag,{value:"Module"})),ct="【雑談】初見さんも常連さんも寝かしつける♡【#鎖乙女がぶ /#パレプロ研究生 】",ut="鎖乙女がぶ / Saotome Gabu 【パレプロ研究生】",St="JgU5RzugT-Q",bt="2025-08-23",mt=`【ちょこっとお歌セトリ】
2:56:41 風になる / つじあやの

3:09:28 君の知らない物語 / Supercell

雑談もたっぷりお歌も聞けちゃって最高のもちもちだったね～！！
楽しすぎて時間たつのあっという間すぎ～！！
がぶちゃんもちもちは至高です🫶`,ii={video_title:ct,video_artist:ut,video_id:St,video_publish_date_str:bt,song_timeline:mt},ji=Object.freeze(Object.defineProperty({__proto__:null,default:ii,song_timeline:mt,video_artist:ut,video_id:St,video_publish_date_str:bt,video_title:ct},Symbol.toStringTag,{value:"Module"})),gt="【雑談】深夜にまたぁり雑談♡初見さんも常連さんも寝かしつけ♡【#鎖乙女がぶ /#パレプロ研究生 】",pt="鎖乙女がぶ / Saotome Gabu 【パレプロ研究生】",$t="u_4TqUsUReA",Ot="2025-08-24",ft=`【本日の子守歌💤】
2:27:09 花に亡霊 / ヨルシカ
深夜のもちもちおつがぶ～！！
途中からだったけどがぶちゃんと一緒に過ごせた夜がとても最高でしたね！！
いい夢見れます絶対に！おやすみ～！！`,oi={video_title:gt,video_artist:pt,video_id:$t,video_publish_date_str:Ot,song_timeline:ft},Ni=Object.freeze(Object.defineProperty({__proto__:null,default:oi,song_timeline:ft,video_artist:pt,video_id:$t,video_publish_date_str:Ot,video_title:gt},Symbol.toStringTag,{value:"Module"})),ht="【歌枠/Karaoke】アイドル縛り歌枠！2次元も3次元も♥【#鎖乙女がぶ /#パレプロ研究生 】",At="鎖乙女がぶ / Saotome Gabu 【パレプロ研究生】",Tt="k8UuddcKDzc",Pt="2025-09-06",yt=`0:05:21 始まりは君の空 / Liella!
0:25:04 全方位キュン / みらくらぱーく！
0:32:14 シャボン玉 / モーニング娘。
0:39:22 アイドルライフスターターパック / iLiFE!
0:52:14サヨナラの意味 / 乃木坂46
1:02:36 この涙を君に捧ぐ / NO NAME
1:11:48 Over Over / 澁谷かのん(CV.伊達さゆり)
1:16:24 Holiday∞Holiday / スリーズブーケ
1:20:54 ハナムスビ / スリーズブーケ
1:26:23 ハート型ウイルス / AKB48
1:31:13 キャンディー / 河西智美
1:42:33 サインはB / B小町
1:55:52 オトナモード / りすこ・もな from STAR☆ANIS
2:00:14 SOS / 黛冬優子 (CV.幸村恵理)

B小町はキャラ名と声優名入れたら長くなっちゃったから端折りました😣`,ni={video_title:ht,video_artist:At,video_id:Tt,video_publish_date_str:Pt,song_timeline:yt},Ii=Object.freeze(Object.defineProperty({__proto__:null,default:ni,song_timeline:yt,video_artist:At,video_id:Tt,video_publish_date_str:Pt,video_title:ht},Symbol.toStringTag,{value:"Module"})),Et="【雑談/歌枠】深夜の寝落ちもちもち配信♥ねかしつけ♥【#鎖乙女がぶ / #パレプロ研究生 】",Mt="鎖乙女がぶ / Saotome Gabu 【パレプロ研究生】",Rt="fi8PtOS6OUw",jt="2025-09-07",Nt=`【🐺🩰お歌セトリTS🐺💜🎶】
1:08:57 きっかけ / 乃木坂46
1:19:32 マリーゴールド / あいみょん
1:41:25 カタオモイ / Aimer
1:57:16 Starlight Prologue / Liella!

おまけ1:31:02 鳥貴族のお話`,_i={video_title:Et,video_artist:Mt,video_id:Rt,video_publish_date_str:jt,song_timeline:Nt},Li=Object.freeze(Object.defineProperty({__proto__:null,default:_i,song_timeline:Nt,video_artist:Mt,video_id:Rt,video_publish_date_str:jt,video_title:Et},Symbol.toStringTag,{value:"Module"}));export{Li as A,di as _,si as a,li as b,ai as c,ri as d,vi as e,ci as f,ui as g,Si as h,bi as i,mi as j,gi as k,pi as l,$i as m,Oi as n,fi as o,hi as p,Ai as q,Ti as r,Pi as s,yi as t,Ei as u,Mi as v,Ri as w,ji as x,Ni as y,Ii as z};
