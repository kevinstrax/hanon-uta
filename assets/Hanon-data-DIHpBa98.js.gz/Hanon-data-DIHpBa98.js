const n="【3D LIVE】香鳴ハノンバースデーライブ🌟バンドリ！オンリー！【#ハノ誕2024/パレプロ】",e="Palette Project Channel",t="fSXkEig2QRI",i="2024-03-03",o=`今回のタイムスタンプ＆セトリ\r
0:00:00 OP\r
\r
0:01:32 Daylight - デイライト - / Morfonica\r
0:07:21 ブルームブルーム / Morfonica\r
0:11:58 MC\r
0:18:20 えがおのオーケストラっ！ / ハロー、ハッピーワールド！\r
0:22:09 ゴーカ！ごーかい！？ファントムシーフ！ / ハロー、ハッピーワールド！\r
0:25:45 しゅわりん☆どり～みん / Pastel*Palettes\r
0:29:54 MC\r
0:31:13 壱雫空 / MyGO!!!!\r
0:34:25 Hey-day狂騒曲(カプリチオ) / Afterglow\r
0:38:18 ティアドロップス / Poppin'Party\r
0:42:06 MC\r
0:43:04 FIRE BIRD / Roselia\r
0:48:26 - HEROIC ADVENT - / Roselia\r
0:52:15 ENC\r
0:53:17 STAR BEAT! ～ホシノコドウ～ / Poppin'Party\r
0:58:36 Y.O.L.O!!!!! / Afterglow\r
\r
1:03:05 MC\r
1:06:34 グッズ紹介、告知\r
1:12:26 エンドカード

素晴らしい誕生日ライブありがとうございました！\r
改めて誕生日おめでとう！`,kd={video_title:n,video_artist:e,video_id:t,video_publish_date_str:i,song_timeline:o},ra=Object.freeze(Object.defineProperty({__proto__:null,default:kd,song_timeline:o,video_artist:e,video_id:t,video_publish_date_str:i,video_title:n},Symbol.toStringTag,{value:"Module"})),_="【歌枠/KARAOKE】新衣装で✨バラード縛り歌枠🎤🌙【香鳴ハノン/パレプロ】",s="Hanon Ch. 香鳴ハノン【パレプロ】",d="lI3T2zB1kpc",r="2024-03-11",l=`0:03:03 はのはー！
0:07:34 Lemon / 米津玄師
0:14:10 たばこ / コレサワ
0:21:44 カブトムシ / aiko
0:29:12 First Love / 宇多田ヒカル
0:35:02 雑談 - 本日のハノンちゃん、確定申告など -
0:41:12 優しい彗星 / YOASOBI

0:46:35 花に亡霊 / ヨルシカ
0:51:40 ひまわりの約束 / 秦基博
1:00:42 ハルノヒ / あいみょん
1:08:54 奏 / スキマスイッチ

1:18:00 明日の配信予定
1:18:40 はのはー！
1:18:52 END`,Yd={video_title:_,video_artist:s,video_id:d,video_publish_date_str:r,song_timeline:l},la=Object.freeze(Object.defineProperty({__proto__:null,default:Yd,song_timeline:l,video_artist:s,video_id:d,video_publish_date_str:r,video_title:_},Symbol.toStringTag,{value:"Module"})),a="【歌枠/KARAOKE】白いイメージの曲を歌うホワイトデーの歌枠🎤🤍【香鳴ハノン/パレプロ】",v="Hanon Ch. 香鳴ハノン【パレプロ】",c="KoGhYZWumAw",u="2024-03-14",b=`0:02:52 はのはー！

0:05:29 01. 白日 / King Gnu
0:13:14 02. 白い恋人達 / 桑田佳祐
0:19:26 03. 粉雪 / レミオロメン
0:25:12 雑談 - 雪の日の思い出 -
0:31:22 04. 雪の華 / 中島美嘉
0:38:42 05. White Love / SPEED

0:45:43 06. ロマンスの神様 / 広瀬香美
0:55:11 07. 津軽海峡・冬景色 / 石川さゆり

1:00:30 スパチャ読み
1:04:53 はのはー！
1:06:08 END / Cパート`,Fd={video_title:a,video_artist:v,video_id:c,video_publish_date_str:u,song_timeline:b},aa=Object.freeze(Object.defineProperty({__proto__:null,default:Fd,song_timeline:b,video_artist:v,video_id:c,video_publish_date_str:u,video_title:a},Symbol.toStringTag,{value:"Module"})),g="【歌枠/KARAOKE】ドラマ＆映画の主題歌・挿入歌を歌う！🎤✨【香鳴ハノン/パレプロ】",p="Hanon Ch. 香鳴ハノン【パレプロ】",m="c7_uUrX4KSQ",$="2024-03-16",O=`0:02:40 はのはー！
0:04:55 ハノンノオト最速タイピング選手権？

0:06:31 01. 前前前世 / RADWIMPS
0:13:44 02. Precious / 伊藤由奈
0:20:53 03. Pretender / Official髭男dism
0:28:52 04. タイヨウのうた / Kaoru Amane
0:36:13 05. Good-bye days / YUI for 雨音薫

0:44:16 06. ヒカリヘ / miwa
0:54:03 07. Love so sweet / 嵐
0:59:05 08. One Love / 嵐
1:05:47 09. 糸 / 中島みゆき
1:13:11 10. heavenly days / 新垣結衣

1:18:36 11. アイのうた / 福井舞
1:27:43 12. 渡月橋 〜君 想ふ〜 / 倉木麻衣
1:33:51 13. さよならエレジー / 菅田将暉
1:39:42 14. 裸の心 / あいみょん
1:47:54 15. HANABI / Mr.Children

1:56:51 16. ちっぽけな愛のうた / 小枝理子＆小笠原秋

2:08:38 スパチャ読み
2:17:41 はのはー！
2:18:07 END / Cパート`,Wd={video_title:g,video_artist:p,video_id:m,video_publish_date_str:$,song_timeline:O},va=Object.freeze(Object.defineProperty({__proto__:null,default:Wd,song_timeline:O,video_artist:p,video_id:m,video_publish_date_str:$,video_title:g},Symbol.toStringTag,{value:"Module"})),h="【縦型配信/KARAOKE】1時間くらい歌うよ～～1曲聞いてって✨【香鳴ハノン/パレプロ】 #shorts #縦型配信",A="Hanon Ch. 香鳴ハノン【パレプロ】",S="9FdHnrn4z9g",y="2024-03-21",f=`🎀🎶今回のタイムスタンプ＆セトリ🎀🎶
0:00:00 OP
0:02:04 はのは～

0:06:45 Butter-Fly / 和田光司 ~0:11:06 
0:12:28 シンデレラボーイ / Saucy Dog ~0:16:21 
0:17:39 青春アミーゴ / 修二と彰 ~0:22:16 
0:22:17 雑談 / 今日何してた？
0:27:56 シーソーゲーム 〜勇敢な恋の歌〜 / Mr.Children ~0:32:31 
0:33:33 檄！帝国華撃団 / 真宮時さくら＆帝国歌劇団 ~0:36:40 
0:38:40 春を告げる / Yama ~0:42:12 
0:42:21 SAKURA / いきものがかり ~0:48:19 
0:49:10 あの夢をなぞって / YOASOBI ~0:53:14 
0:55:48 ギラギラ / Ado ~1:00:22 
1:02:25 私は最強 / Ado ~1:06:49 
1:08:08 雑談 / えるすりーの話
1:14:08 アイドル / YOASOBI ~1:17:48 

1:18:25 スパチャ読み
1:22:27 エンドカード
∟1:25:13 Cパート`,wd={video_title:h,video_artist:A,video_id:S,video_publish_date_str:y,song_timeline:f},ca=Object.freeze(Object.defineProperty({__proto__:null,default:wd,song_timeline:f,video_artist:A,video_id:S,video_publish_date_str:y,video_title:h},Symbol.toStringTag,{value:"Module"})),C="【歌枠/KARAOKE】令和の曲を歌おう🎤🎶【香鳴ハノン/パレプロ】",E="Hanon Ch. 香鳴ハノン【パレプロ】",P="3wjotxVKkJc",R="2024-03-29",M=`0:02:05 はのはー！

0:04:25 01. ギラギラ / Ado
0:10:18 02. 怪獣の花唄 / Vaundy
0:17:01 03. わたしの一番かわいいところ / FRUITS ZIPPER
0:21:33 雑談 - ハノンちゃんの一番かわいいところってどこ？？
0:23:49 04. すきっ！ / 超ときめき宣伝部
0:31:27 05. 可愛くてごめん / HoneyWorks

0:35:49 06. シル・ヴ・プレジデント / P丸様。
0:42:42 07. だいしきゅーだいしゅき / femme fatale
0:49:27 08. ミックスナッツ / Official髭男dism
0:53:06 雑談 - ハノミレてぇてぇ
0:59:50 09. 春泥棒 / ヨルシカ
1:04:53 雑談 - ハノ誕の思い出
1:08:59 10. Pale Blue / 米津玄師

1:15:44 11. ギラギラ / Ado

1:22:10 スパチャ読み
1:24:23 はのはー！
1:24:38 END / Cパート

1:25:25 4月生写真サンプル公開
　└ 1:26:09 1枚目
　└ 1:27:22 2枚目
　└ 1:28:41 3枚目
　└ 1:29:32 4枚目
　└ 1:30:31 5枚目
　└ 1:31:28 6枚目
　└ 1:32:25 7枚目
　└ 1:33:35 8枚目
　└ 1:34:19 9枚目
　└ 1:35:18 10枚目`,Qd={video_title:C,video_artist:E,video_id:P,video_publish_date_str:R,song_timeline:M},ua=Object.freeze(Object.defineProperty({__proto__:null,default:Qd,song_timeline:M,video_artist:E,video_id:P,video_publish_date_str:R,video_title:C},Symbol.toStringTag,{value:"Module"})),K="【歌枠/KARAOKE】バンド曲縛り歌枠！かっこいいとこ見せるぞ🎸✨【#パレプロ #香鳴ハノン】",N="Hanon Ch. 香鳴ハノン【パレプロ】",T="wqVOMPpqPvs",j="2024-04-10",H=`0:01:46 はのはー！
0:06:04 01. 願い / sumika
0:14:22 02. Shout Baby / 緑黄色社会
0:21:32 03. MONSTER DANCE / KEYTALK
0:26:24 04. シルエット / KANA-BOON
0:31:21 05. ともに / WANIMA

0:35:51 06. ダンスホール / Mrs. GREEN APPLE
0:42:47 07. イエスタデイ / Official髭男dism
0:50:59 08. ヤングアダルト / マカロニえんぴつ
0:57:58 09. オリオンをなぞる / UNISON SQUARE GARDEN

1:04:19 スパチャ読み
1:12:22 はのはー！`,Jd={video_title:K,video_artist:N,video_id:T,video_publish_date_str:j,song_timeline:H},ba=Object.freeze(Object.defineProperty({__proto__:null,default:Jd,song_timeline:H,video_artist:N,video_id:T,video_publish_date_str:j,video_title:K},Symbol.toStringTag,{value:"Module"})),I="【歌枠/KARAOKE】2010年代ヒットソング歌枠！初見さんも大歓迎✨【#パレプロ #香鳴ハノン】",D="Hanon Ch. 香鳴ハノン【パレプロ】",B="MxlMzxT8rYk",L="2024-04-14",V=`🎀🎶今回のタイムスタンプ＆セトリ🎀🎶
0:00:00 OP
0:03:03 はのは～

0:05:35 ありがとう / いきものがかり ~0:11:33 
0:14:28 会いたくて 会いたくて / 西野カナ ~0:19:37 
0:21:26 行くぜっ!怪盗少女 / ももいろクローバーZ ~0:25:16 
0:26:18 コネクト / ClariS ~0:30:48 
0:32:27 ポニーテールとシュシュ / AKB48 ~0:37:01 
0:44:03 片想いFinally / SKE48 ~0:48:32 
0:53:21 ミラクル / miwa ~0:58:00 
0:59:08 Let It Go～ありのままで～ / 松たか子 ~1:02:53 

1:08:05 シュガーソングとビターステップ / UNISON SQUARE GARDEN ~1:12:18 
1:14:52 新宝島 / サカナクション ~1:19:51 
1:21:09 トリセツ / 西野カナ ~1:25:28
1:29:18 不協和音 / 櫻坂46 ~1:33:22 
1:36:53 ともに / WANIMA ~1:40:21 
1:42:20 打上花火 / DAOKOと米津玄師 ~1:47:28 
1:50:05 Lemon / 米津玄師 ~1:54:27 
1:55:57 マリーゴールド / あいみょん ~2:01:04 

2:06:16 スパチャ読み
2:07:54 エンドカード`,Zd={video_title:I,video_artist:D,video_id:B,video_publish_date_str:L,song_timeline:V},ga=Object.freeze(Object.defineProperty({__proto__:null,default:Zd,song_timeline:V,video_artist:D,video_id:B,video_publish_date_str:L,video_title:I},Symbol.toStringTag,{value:"Module"})),U="【朝活歌枠/KARAOKE】朝から元気が出る歌＆癒しの歌を歌う🎤✨【香鳴ハノン/パレプロ】 #shorts #縦型配信",z="Hanon Ch. 香鳴ハノン【パレプロ】",G="CyrdsISfKRE",k="2024-04-18",Y=`0:02:55 はのはー！
0:10:29 01. プラチナ /  坂本真綾
0:15:54 02. SUN / 星野源
0:20:18 雑談 - ネイル、昨日のお買い物
0:27:03 03. 春を告げる / yama
0:33:54 04. さくらんぼ / 大塚愛
0:38:04 雑談 - 倫理ぃ、同調圧力、気をつけてること
0:48:07 05. 猫 / DISH//
0:52:45 雑談 - 笑わず歌えるようになった、1on1、夜も会える、声好き嬉しい

1:03:30 06. ガーネット / 奥華子
1:08:45 たすかる
1:09:05 雑談 - 昨日の地震、ショート動画出します
1:12:59 07. 星間飛行 / ランカ・リー=中島愛

1:18:38 スパチャ読み
1:19:59 告知
1:20:45 はのはー！
1:21:05 END / Cパート`,Xd={video_title:U,video_artist:z,video_id:G,video_publish_date_str:k,song_timeline:Y},pa=Object.freeze(Object.defineProperty({__proto__:null,default:Xd,song_timeline:Y,video_artist:z,video_id:G,video_publish_date_str:k,video_title:U},Symbol.toStringTag,{value:"Module"})),F="【歌枠/KARAOKE】ボカロ歌枠！初見さんも大歓迎✨【#パレプロ #香鳴ハノン】",W="Hanon Ch. 香鳴ハノン【パレプロ】",w="hWJtAan0BO8",Q="2024-04-20",J=`0:02:39 はのはー！
0:11:27 01. 酔いどれ知らず / Kanaria
0:15:37 02. 神っぽいな / ピノキオピー
0:19:25 雑談 - もっと言って、気持ちいいから
0:22:57 03. 強風オールバック / ゆこぴ
0:25:41 04. 寝起きヤシの木 / ゆこぴ
0:29:27 05. いーあるふぁんくらぶ / みきとP

0:35:34 06. 少女レイ / みきとP
0:40:50 雑談 - 最近着る服に困る
0:48:10 07. トンデモワンダーズ / sasakureꓸUK feat. 初音ミク
0:57:36 08. シャルル / バルーン
1:02:46 09. グッバイ宣言 / Chinozo
1:07:53 10. ヴァンパイア / DECO*27

1:13:32 11. 千本桜 / 黒うさP feat. 初音ミク
1:18:33 12. メランコリック / Junky feat. 鏡音リン

1:22:37 スパチャ読み
1:27:00 はのはー！
1:27:15 END / Cパート`,qd={video_title:F,video_artist:W,video_id:w,video_publish_date_str:Q,song_timeline:J},ma=Object.freeze(Object.defineProperty({__proto__:null,default:qd,song_timeline:J,video_artist:W,video_id:w,video_publish_date_str:Q,video_title:F},Symbol.toStringTag,{value:"Module"})),Z="【歌枠/KARAOKE】アニソン歌枠！初見さんも大歓迎✨【#パレプロ #香鳴ハノン】",X="Hanon Ch. 香鳴ハノン【パレプロ】",q="0yHUSUg45A4",x="2024-04-22",nn=`0:03:22 はのはー！

0:06:23 01. インフェルノ / Mrs. GREEN APPLE
0:12:49 02. Rising Hope / LiSA
0:20:40 03. Q&A リサイタル! / 戸松遥
0:27:01 04. 君の知らない物語 / supercell
0:34:08 05. ふでペン ~ボールペン~ / 放課後ティータイム

0:39:30 06. ギー太に首ったけ / 平沢唯（CV:豊崎愛生）
0:44:54 07. 星座になれたら / 結束バンド
0:51:11 08. ちゅ、多様性。 / ano
0:55:24 09. サインはB / Ｂ小町 アイ（CV:高橋李依）
1:01:05 10. アイドル / YOASOBI

1:07:39 11. クラクラ / Ado
1:11:34 12. 怪物 / YOASOBI
1:18:30 13. 空色デイズ / 中川翔子
1:24:54 14. ステラブリーズ / 春奈るな
1:30:58 15. adrenaline!!! / TrySail

1:36:31 スパチャ読み
1:38:58 はのはー！
1:39:17 END / Cパート`,xd={video_title:Z,video_artist:X,video_id:q,video_publish_date_str:x,song_timeline:nn},$a=Object.freeze(Object.defineProperty({__proto__:null,default:xd,song_timeline:nn,video_artist:X,video_id:q,video_publish_date_str:x,video_title:Z},Symbol.toStringTag,{value:"Module"})),en="【歌枠/KARAOKE】今夜もアニソン歌枠！初見さんも大歓迎✨【#パレプロ #香鳴ハノン】",tn="Hanon Ch. 香鳴ハノン【パレプロ】",on="e8USVpxK7XA",_n="2024-04-26",sn=`0:02:38 はのはー！

0:04:24 01. 残酷な天使のテーゼ / 高橋洋子
0:14:41 02. ライオン / May'n/中島愛
0:20:46 03. 星間飛行 / ランカ・リー=中島愛
0:26:17 04. いけないボーダーライン / ワルキューレ
0:33:27 05. 泪のムコウ / ステレオポニー

0:39:39 06. 心絵 / ロードオブメジャー
0:44:24 07. 曇天 / DOES
0:48:37 08. 光るなら / Goose house
0:53:20 雑談 - ジェルボール破裂しちゃった
0:55:33 09. Don't say "lazy" / 桜高軽音部
1:03:00 10. NO,Thank You! / 放課後ティータイム

1:09:02 11. Listen!! / 放課後ティータイム
1:16:00 12. God knows... / 涼宮ハルヒ(C.V.平野綾)
1:23:06 13. 月光花 / Janne Da Arc
1:28:04 雑談 - ブラックジャック、ダレン・シャン観たくなってきた
1:34:57 14. シャル・ウィ・ダンス？ / ReoNa
1:41:58 15. Butter-Fly / 和田光司

1:46:47 スパチャ読み
1:51:49 はのはー！
1:52:09 END / Cパート（ミュート）`,nr={video_title:en,video_artist:tn,video_id:on,video_publish_date_str:_n,song_timeline:sn},Oa=Object.freeze(Object.defineProperty({__proto__:null,default:nr,song_timeline:sn,video_artist:tn,video_id:on,video_publish_date_str:_n,video_title:en},Symbol.toStringTag,{value:"Module"})),dn="【歌枠/KARAOKE】同接200人目標歌枠！初見さんも大歓迎✨【#パレプロ #香鳴ハノン】",rn="Hanon Ch. 香鳴ハノン【パレプロ】",ln="nLxIPb2ytkU",an="2024-04-30",vn=`0:01:55 はのはー！

0:10:45 01. 夢をかなえてドラえもん / mao
0:15:25 雑談 - 欲しいドラえもんのひみつ道具
0:19:37 02. ムーンライト伝説 / DALI
0:22:34 雑談 - セーラームーン見たことある？子供の頃に見てたアニメとか
0:30:25 03. 猫 / DISH//
0:38:45 音声トラブルにより中断（0:39:12 配信再開）
0:41:16 04. 香水 / 瑛人
0:45:56 05. 夜に駆ける / YOASOBI

0:50:29 06. 群青 / YOASOBI
0:56:33 07. 言って。 / ヨルシカ
1:03:56 08. ただ君に晴れ / ヨルシカ
1:07:36 09. だから僕は音楽を辞めた / ヨルシカ
1:12:05 雑談 - パレプロ公式からのツイート見た？ハノンちゃんの効果って？
1:19:58 10. 秒針を噛む / ずっと真夜中でいいのに。

1:25:04 11. 勘ぐれい / ずっと真夜中でいいのに。
1:34:23 12. 正しくなれない / ずっと真夜中でいいのに。
1:45:45 13. ミュージック・アワー / ポルノグラフィティ
1:53:38 14. シル・ヴ・プレジデント / P丸様。
2:02:48 15. Rising Hope / LiSA
2:07:47 雑談 - 同接200人達成うれしい！ライトなハノモニさん？？？

2:17:45 16. ラムのラブソング / 松谷祐子
2:25:02 17. オリオンをなぞる / UNISON SQUARE GARDEN
2:31:04 18. 天体観測 / BUMP OF CHICKEN

2:36:23 スパチャ読み
2:43:18 はのはー！
2:43:45 END / Cパート
2:44:00 5月生写真サンプル公開（5枚）`,er={video_title:dn,video_artist:rn,video_id:ln,video_publish_date_str:an,song_timeline:vn},ha=Object.freeze(Object.defineProperty({__proto__:null,default:er,song_timeline:vn,video_artist:rn,video_id:ln,video_publish_date_str:an,video_title:dn},Symbol.toStringTag,{value:"Module"})),cn="【耐久歌枠｜前半】登録者31000人&同接500人達成するまで歌い続ける！！🎤🎀【#パレプロ #香鳴ハノン】",un="Hanon Ch. 香鳴ハノン【パレプロ】",bn="CrJ7XbyRvhs",gn="2024-05-02",pn=`0:03:13 はのはー！
目指せ30,758→31,000人！

0:08:57 01. CHE.R.RY / YUI
0:18:10 02. SAKURA / いきものがかり
0:34:17 03. ハルカ / YOASOBI
0:45:41 04. 春泥棒 / ヨルシカ
0:51:20 05. チェリー / スピッツ
0:59:36 06. 春を告げる / yama
1:07:02 07. 打上花火 / DAOKO × 米津玄師
1:13:50 08. 怪獣の花唄 / Vaundy
1:19:11 09. 気まぐれロマンティック / いきものがかり
1:22:00 同接300人達成
1:28:29 10. 新時代 / Ado

1:38:04 11. Happiness / 嵐
1:50:26 12. 水平線 / back number
1:58:59 13. ベテルギウス / 優里
2:12:35 14. First Love / 宇多田ヒカル
2:23:18 15. Pretender / Official髭男dism
2:33:13 16. 愛のうた / ストロベリー・フラワー
2:42:31 17. ぼくはくま / 宇多田ヒカル
2:48:44 18. ハッピー・ジャムジャム / M.S.J
2:51:40 19. 強風オールバック
2:56:05 20. ハム太郎とっとこうた / ハムちゃんず

3:00:42 21. めざせポケモンマスター / 松本梨香
3:06:00 22. Together / あきよしふみえ
3:16:43 23. ヒトリゴト / ClariS
3:24:10 24. ダンデライオン / BUMP OF CHICKEN
3:29:15 25. カサブタ / 千綿ヒデノリ
3:33:26 26. 星間飛行 / ランカ・リー＝中島愛
3:38:25 27. プラチナ / 坂本真綾
3:45:45 28. 檄！帝国華撃団 / 真宮寺さくら(横山智佐)&帝国歌劇団
3:50:19 29. 星座になれたら / 結束バンド
4:01:05 30. 魂のルフラン / 高橋洋子

4:10:03 31. 風になる / つじあやの
4:24:09 32. 丸ノ内サディスティック / 椎名林檎
4:32:14 33. 花に亡霊 / ヨルシカ
4:37:41 34. 少女レイ / みきとP
4:51:49 35. かくれんぼ / AliA
5:00:20 36. だいしきゅーだいしゅき / femme fatale
5:09:07 37. 青と夏 / Mrs. GREEN APPLE
5:16:10 38. ダンスホール / Mrs. GREEN APPLE
5:24:10 39. インフェルノ / Mrs. GREEN APPLE
5:33:36 40. ふ・れ・ん・ど・し・た・い / 学園生活部
5:35:05 CH登録者数30900人突破

5:36:55 41. 恋愛サーキュレーション / 千石撫子（花澤香菜）
5:43:54 42. メランコリック / Junky feat. 鏡音リン

5:49:41 次枠に引っ越し`,tr={video_title:cn,video_artist:un,video_id:bn,video_publish_date_str:gn,song_timeline:pn},Aa=Object.freeze(Object.defineProperty({__proto__:null,default:tr,song_timeline:pn,video_artist:un,video_id:bn,video_publish_date_str:gn,video_title:cn},Symbol.toStringTag,{value:"Module"})),mn="【耐久歌枠｜後半】登録者31000人&同接500人達成するまで歌い続ける！！🎤🎀【#パレプロ #香鳴ハノン】",$n="Hanon Ch. 香鳴ハノン【パレプロ】",On="S2wujBC4F_A",hn="2024-05-02 12:00:02",An=`0:00:05 引っ越し完了

0:07:57 43. ミックスナッツ / Official髭男dism　※楽曲番号は前枠から継続
0:15:41 44. 勘冴えて悔しいわ / ずっと真夜中でいいのに。
0:23:20 45. 残響散歌 / Aimer
0:28:54 46. カタオモイ / Aimer
0:39:21 47. 糸 / 中島みゆき
0:47:55 48. 黒毛和牛上塩タン焼680円 / 大塚愛
0:56:29 49. 少女A / 中森明菜
1:00:14 50. 異邦人 / 久保田早紀

1:05:08 51. M / PRINCESS PRINCESS
1:09:45 52. 瑠璃色の地球 / 松田聖子
1:16:10 53. 地上の星 / 中島みゆき
1:26:01 54. UFO / ピンク・レディー
1:33:46 55. 大阪LOVER / DREAMS COME TRUE
1:41:47 56. Hello, Again 〜昔からある場所〜 / My Little Lover
1:48:33 57. 夏の日の1993 / class
2:07:55 「『ステラ』-じん covered 常磐カナメ」同時視聴@常磐カナメCH
2:20:05 58. 恋しさと せつなさと 心強さと / 篠原涼子
2:25:48 59. ラブレター / YOASOBI
2:33:17 60. 桜坂 / 福山雅治

2:43:12 61. Lemon / 米津玄師
2:52:36 62. Pale Blue / 米津玄師
3:04:19 63. 唱 / Ado
3:08:07 64. うっせぇわ / Ado
3:12:47 65. 未来予想図 II / DREAMS COME TRUE
3:23:13 66. staple stable / 戦場ヶ原ひたぎ(斎藤千和)
3:29:18 67. 帰り道 / 八九寺真宵(加藤英美里)
3:29:35 チャンネル登録者数31000人達成
3:38:51 68. あの夢をなぞって / YOASOBI
3:46:16 69. yell / 香鳴ハノン

3:56:48 はのはー！
3:57:47 END / Cパート`,ir={video_title:mn,video_artist:$n,video_id:On,video_publish_date_str:hn,song_timeline:An},Sa=Object.freeze(Object.defineProperty({__proto__:null,default:ir,song_timeline:An,video_artist:$n,video_id:On,video_publish_date_str:hn,video_title:mn},Symbol.toStringTag,{value:"Module"})),Sn="【歌枠 / KARAOKE】2000年代のヒットソングを歌う🎤🎀【#パレプロ #香鳴ハノン】",yn="Hanon Ch. 香鳴ハノン【パレプロ】",fn="Clo_uZkDtKU",Cn="2024-05-04",En=`🎀🎶今回のタイムスタンプ＆セトリ🎀🎶
0:00:00 OP
0:01:45 はのは～

0:11:42 明日への扉 / 川嶋あい ~0:16:38 
0:17:54 プラネタリウム / 大塚愛 ~0:23:11 
0:25:02 キセキ / GReeeeN ~0:29:41 
0:32:21 AM11：00 / HY ~0:37:44 
0:41:39 小さな恋のうた / MONGOL800 ~0:45:23 
0:47:45 KISSして / KOH+ ~0:51:45 
0:51:51 かたちあるもの / 柴咲コウ ~0:56:09 

0:58:47 全人類に耳寄りな情報
1:06:31 青いベンチ / サスケ ~1:10:31 
1:11:03 Love so sweet / 嵐 ~1:15:59 
1:17:29 涙そうそう / 夏川りみ ~1:21:47 
1:21:56 三日月 / 絢香 ~1:26:37 
1:27:54 愛のうた / 倖田來未 ~1:32:52 
1:36:01 キューティーハニー / 前川陽子 ~1:38:22 
1:43:35 HANABI / Mr.Children ~1:49:22 
1:54:17 Butterfly / 木村カエラ ~1:58:32 

2:01:39 スパチャ読み
2:05:24 エンドカード`,or={video_title:Sn,video_artist:yn,video_id:fn,video_publish_date_str:Cn,song_timeline:En},ya=Object.freeze(Object.defineProperty({__proto__:null,default:or,song_timeline:En,video_artist:yn,video_id:fn,video_publish_date_str:Cn,video_title:Sn},Symbol.toStringTag,{value:"Module"})),Pn="【歌枠 / KARAOKE】1曲聴いていきませんか？1時間だけのさくっと歌枠🎤🎀【#パレプロ #香鳴ハノン】",Rn="Hanon Ch. 香鳴ハノン【パレプロ】",Mn="BW5CsFVhumM",Kn="2024-05-06",Nn=`今回のタイムスタンプ＆セトリ\r
0:00:00 OP\r
0:02:24 はのは～\r
\r
0:04:19 青春コンプレックス / 結束バンド ~0:07:42 \r
0:08:04 星座になれたら / 結束バンド ~0:12:21 \r
0:14:01 オリオンをなぞる / UNISON SQUARE GARDEN ~0:18:22 \r
0:18:54 紅蓮華 / LiSA ~0:22:54 \r
0:24:27 怪物 / YOASOBI ~0:28:01 \r
0:30:18 シルエット / KANA-BOON ~0:34:22 \r
0:34:50 ヒトヒラのハナビラ / ステレオポニー ~0:38:26 \r
0:38:34 ツキアカリのミチシルベ / ステレオポニー ~0:42:46 \r
0:45:28 瞬間センチメンタル / SCANDAL ~0:49:13 \r
0:49:19 少女S / SCANDAL ~0:52:42 \r
0:54:07 again / YUI ~0:58:24 \r
1:00:27 ブルーバード / いきものがかり ~1:04:08 \r
\r
1:05:20 告知 スパチャ読み\r
1:07:18 エンドカード`,_r={video_title:Pn,video_artist:Rn,video_id:Mn,video_publish_date_str:Kn,song_timeline:Nn},fa=Object.freeze(Object.defineProperty({__proto__:null,default:_r,song_timeline:Nn,video_artist:Rn,video_id:Mn,video_publish_date_str:Kn,video_title:Pn},Symbol.toStringTag,{value:"Module"})),Tn="【歌枠 / KARAOKE】1990年代縛り！1時間だけのさくっと歌枠🎤🎀【#パレプロ #香鳴ハノン】",jn="Hanon Ch. 香鳴ハノン【パレプロ】",Hn="ppFnzeVmdBQ",In="2024-05-11",Dn=`🎀🎶今回のタイムスタンプ＆セトリ🎀🎶
0:00:00 OP
0:01:50 はのは～

0:03:09 研究生ちゃんたちの話
0:09:39 出逢った頃のように / Every Little Thing ~0:14:05 
0:14:45 負けないで / ZARD ~0:18:29 
0:19:00 続研究生ちゃんたちの話
0:28:32 ロマンスの神様 / 広瀬香美 ~0:33:03 
0:35:18 カブトムシ / Aiko ~0:40:23 (コメ欄虫が苦手な人は注意)
0:44:56 PRIDE / 今井美樹 ~0:50:59 
0:54:23 愛は勝つ / KAN ~0:58:25 
0:59:52 真夏の果実 / サザンオールスターズ(アカペラ少しだけ)
1:03:11 Tomorrow never knows / Mr.Children ~1:08:10 
1:08:12 同接が安定して200人超すようになったよ
1:13:37 夢見る少女じゃいられない / 相川七瀬 ~1:17:50 

1:21:11 どんなときも。 / 槇原敬之 ~1:26:00 
1:30:55 スパチャ読み
1:34:03 エンドカード`,sr={video_title:Tn,video_artist:jn,video_id:Hn,video_publish_date_str:In,song_timeline:Dn},Ca=Object.freeze(Object.defineProperty({__proto__:null,default:sr,song_timeline:Dn,video_artist:jn,video_id:Hn,video_publish_date_str:In,video_title:Tn},Symbol.toStringTag,{value:"Module"})),Bn="【歌枠 / KARAOKE】1970～1980年代縛り！スナックハノンへようこそ🎤🎀【#パレプロ #香鳴ハノン】",Ln="Hanon Ch. 香鳴ハノン【パレプロ】",Vn="ViFL8ZQmhz0",Un="2024-05-16",zn=`🎀🎶今回のスナックハノンメニュー🎀🎶
0:00:00 OP
0:02:31 はのは～

0:07:30 さよならの向こう側 / 山口百恵 ~0:13:45 
0:15:14 りこママとご飯に行ったよ
0:18:00 プレイバック part 2 / 山口百恵 ~0:21:31 
0:23:53 少女A / 中森明菜 ~0:27:38 
0:31:27 あゝ無情 / アン・ルイス ~0:35:25 
0:39:13 青い珊瑚礁 / 松田聖子 ~0:42:56 
0:43:15 瑠璃色の地球 / 松田聖子 ~0:47:28 
0:48:50 赤いスイートピー / 松田聖子 ~0:52:33 
0:55:18 UFO / ピンク・レディー ~0:58:36 

1:00:56 S・O・S / ピンク・レディー(アカペラ) ~1:02:45 
1:03:38 木綿のハンカチーフ / 太田裕美 ~1:07:35 
1:09:55 ルージュの伝言 / 松任谷由実 ~1:13:10 
1:15:26 異邦人 / 久保田早紀 ~1:19:13 
1:28:13 桃色吐息 / 高橋真梨子(アカペラ) ~1:31:03 
1:31:33 次の曲とか研究生ちゃんと明日の配信について
1:39:22 恋におちて - Fall in love - / 小林明子 ~1:44:22 
1:46:42 M / プリンセス プリンセス ~1:51:08 
1:51:13 子供の頃から高校時代のお話

2:01:07 フレンズ / レベッカ ~2:05:39 
2:14:50 バレンタイン・キッス / 国生さゆり ~2:18:43 
2:22:49 タッチ / 岩崎良美 ~2:26:02 
2:26:13 タッチの話から昔のものについての話
2:43:36 プラスティック・ラヴ / 竹内まりや ~2:48:07 
2:51:10 君は天然色 / 大滝詠一 ~2:52:53 
2:55:36 君は天然色 / 大滝詠一 ~3:00:21 
3:08:44 無音空間(ハノンちゃんのお顔をお楽しみください)
3:09:43 セーラー服と機関銃 / 薬師丸ひろ子(アカペラ) ~3:13:24 
3:16:11 飾りじゃないのよ涙は / 中森明菜 ~3:20:27 

3:23:15 スパチャ読み
3:30:48 告知
3:37:52 エンドカード`,dr={video_title:Bn,video_artist:Ln,video_id:Vn,video_publish_date_str:Un,song_timeline:zn},Ea=Object.freeze(Object.defineProperty({__proto__:null,default:dr,song_timeline:zn,video_artist:Ln,video_id:Vn,video_publish_date_str:Un,video_title:Bn},Symbol.toStringTag,{value:"Module"})),Gn="【歌枠 / KARAOKE】マクロスF縛り！初チャレンジの曲も🎤🎀【#パレプロ #香鳴ハノン】",kn="Hanon Ch. 香鳴ハノン【パレプロ】",Yn="zcHuJgDFKCo",Fn="2024-05-18",Wn=`今回のタイムスタンプ＆セトリ\r
0:00:00 OP\r
0:01:38 はのは～\r
\r
0:02:33 ノーザンクロス / May'n ~0:07:46 \r
0:09:33 ダイアモンド クレバス / May'n ~0:15:24 \r
0:18:18 放課後オーバーフロウ / 中島愛 ~0:23:44 \r
0:29:48 アナタノオト / 中島愛 ~0:34:39 \r
0:34:53 蒼のエーテル / 中島愛 ~0:38:34 \r
0:42:19 トライアングラー / 坂本真綾 ~0:47:00 \r
0:48:24 星間飛行 / 中島愛 ~0:52:07 \r
0:53:18 ﾊﾉﾝﾁｬﾝｶﾜｲｲﾖ\r
0:55:18 ライオン / May'n、中島愛 ~1:00:21 \r
1:02:28 ノーザンクロス / May'n ~1:07:48 \r
\r
1:11:32 スパチャ読み\r
1:25:28 告知\r
1:30:19 エンドカード`,rr={video_title:Gn,video_artist:kn,video_id:Yn,video_publish_date_str:Fn,song_timeline:Wn},Pa=Object.freeze(Object.defineProperty({__proto__:null,default:rr,song_timeline:Wn,video_artist:kn,video_id:Yn,video_publish_date_str:Fn,video_title:Gn},Symbol.toStringTag,{value:"Module"})),wn="【歌枠 / KARAOKE】田淵智也さん作曲アニソン縛り歌枠！#ぴよノン【#江波キョウカ #香鳴ハノン】",Qn="Hanon Ch. 香鳴ハノン【パレプロ】",Jn="biEDVnne0rY",Zn="2024-05-20",Xn=`0:01:58 こんばんはー！
0:04:06 01. 桜のあと (all quartets lead to the?) / UNISON SQUARE GARDEN
0:15:54 02. Q&A リサイタル! / 戸松遥
0:24:20 03. Rising Hope / LiSA
0:34:16 04. Catch the Moment / LiSA
0:42:21 05. おもいでしりとり / DIALOGUE+
0:50:25 06. シュガーソングとビターステップ / UNISON SQUARE GARDEN
0:57:09 07. オリオンをなぞる / UNISON SQUARE GARDEN

アンコール
1:10:46 08. Q&A リサイタル! / 戸松遥
1:17:12 09. Rising Hope / LiSA
1:24:47 10. おもいでしりとり / DIALOGUE+

1:31:40 スパチャ読み
1:37:05 おつぴよのん！ 
1:37:12 END / Cパート`,lr={video_title:wn,video_artist:Qn,video_id:Jn,video_publish_date_str:Zn,song_timeline:Xn},Ra=Object.freeze(Object.defineProperty({__proto__:null,default:lr,song_timeline:Xn,video_artist:Qn,video_id:Jn,video_publish_date_str:Zn,video_title:wn},Symbol.toStringTag,{value:"Module"})),qn="【歌枠 / KARAOKE】ロリ！？かわいい！？キュートボイスに全振り歌枠🎤🎀【#パレプロ #香鳴ハノン】",xn="Hanon Ch. 香鳴ハノン【パレプロ】",ne="F8PF-hXbIek",ee="2024-05-24",te=`0:02:21 はのはー！
0:04:41 01. いぬねこ。青春真っ盛り / わーすた
0:09:40 02. 可愛くてごめん / HoneyWorks
0:15:09 03. だいしきゅーだいしゅき / femme fatale
0:19:05 04. わたしの一番かわいいところ / FRUITS ZIPPER
0:24:41 05. すきっ！ / 超ときめき宣伝部

0:32:01 06. トリセツ / 西野カナ
0:40:29 07. おもいでしりとり / DIALOGUE+
0:48:15 08. シル・ヴ・プレジデント / P丸様。
0:52:47 09. プラチナ / 坂本真綾
1:01:55 10. 白金ディスコ / 阿良々木月火(井口裕香)

1:06:41 11. 恋愛サーキュレーション / 千石撫子(花澤香菜)
1:11:20 12. 世界は恋に落ちている / CHiCO with HoneyWorks
1:17:40 セリフパート（リベンジ）
1:19:03 ばかばかばーか！
1:20:08 13. 帰り道 / 八九寺真宵(加藤英美里)
1:25:38 14. ファンサ / mona(夏川椎菜)

1:30:22 スパチャ読み
1:35:30 はのはー！`,ar={video_title:qn,video_artist:xn,video_id:ne,video_publish_date_str:ee,song_timeline:te},Ma=Object.freeze(Object.defineProperty({__proto__:null,default:ar,song_timeline:te,video_artist:xn,video_id:ne,video_publish_date_str:ee,video_title:qn},Symbol.toStringTag,{value:"Module"})),ie="【歌枠 / KARAOKE】かっこいい！？クールボイスに全振り歌枠🎤🎸【#パレプロ #香鳴ハノン】",oe="Hanon Ch. 香鳴ハノン【パレプロ】",_e="Lm9ERKX4nJQ",se="2024-05-28",de=`0:01:25 はのはー！
0:03:46 01. 唱 / Ado
0:08:54 02. Cry Baby / Official髭男dism
0:14:25 03. Rising Hope / LiSA
0:19:45 04. 神っぽいな / ピノキオピー
0:24:25 05. 残響散歌 / Aimer

0:31:27 06. ともに / WANIMA
0:38:09 07. ダンスホール / Mrs. GREEN APPLE
0:42:45 08. Butter-Fly / 和田光司
0:49:25 09. 群青日和 / 東京事変
0:53:34 10. 怪獣の花唄 / Vaundy

0:59:06 11. 星座になれたら / 結束バンド
1:04:53 12. だから僕は音楽を辞めた / ヨルシカ
1:10:21 13. crossing field / LiSA
1:16:24 14. Catch the Moment / LiSA
1:22:49 15. KING / Kanaria

1:29:07 16. Don't say "lazy" / 桜高軽音部
1:34:32 17. 唱 / Ado

1:39:18 スパチャ読み
1:46:34 はのはー！
1:47:20 END / Cパート`,vr={video_title:ie,video_artist:oe,video_id:_e,video_publish_date_str:se,song_timeline:de},Ka=Object.freeze(Object.defineProperty({__proto__:null,default:vr,song_timeline:de,video_artist:oe,video_id:_e,video_publish_date_str:se,video_title:ie},Symbol.toStringTag,{value:"Module"})),re="【歌枠 / KARAOKE】アニソン14曲ノンストップ歌枠🎤🎸BGMにどうぞ【#パレプロ #香鳴ハノン】",le="Hanon Ch. 香鳴ハノン【パレプロ】",ae="66-J8xU2WMo",ve="2024-05-31",ce=`今回のタイムスタンプ＆セトリ\r
0:00:00 OP\r
0:02:38 はのはー\r
\r
0:04:02 怪物 / YOASOBI  \r
0:07:29 Believe / Folder5 \r
0:11:19 オリオンをなぞる / UNISON SQUARE GARDEN\r
0:15:40 ミックスナッツ / Official髭男dism\r
0:19:14 花になって / 緑黄色社会\r
0:22:33 星座になれたら / 結束バンド\r
0:26:52 ヒトリゴト / ClariS\r
0:30:51 ナイショの話 / ClariS\r
0:35:14 カサブタ / 千綿偉功\r
0:38:30 残酷な天使のテーゼ / 高橋洋子\r
0:42:42 星間飛行 / 中島愛\r
0:46:34 放課後オーバーフロウ / 中島愛\r
0:51:55 創聖のアクエリオン / AKINO\r
0:56:35 HoneyCome!! / 小倉唯\r
\r
1:00:43 エンドトーク\r
1:02:14 スパチャ読み\r
1:05:41 エンドカード\r
1:09:00 6月生写真紹介\r
\r
※今回はほぼノンストップで曲間MCがほぼ無いので曲の頭のみになります`,cr={video_title:re,video_artist:le,video_id:ae,video_publish_date_str:ve,song_timeline:ce},Na=Object.freeze(Object.defineProperty({__proto__:null,default:cr,song_timeline:ce,video_artist:le,video_id:ae,video_publish_date_str:ve,video_title:re},Symbol.toStringTag,{value:"Module"})),ue="【歌枠 / KARAOKE】ピアノカラオケでこそこそささやき歌枠🐏🌙【#パレプロ #香鳴ハノン】",be="Hanon Ch. 香鳴ハノン【パレプロ】",ge="JmfVDJ-obGc",pe="2024-06-04",me=`0:03:50 はのはー！

0:06:18 01. いつか / Saucy Dog
0:10:52 02. なんでもないよ、 / マカロニえんぴつ
0:14:38 03. わたがし / back number
0:19:01 04. 花束 / back number
0:25:19 05. 高嶺の花子さん / back number

0:30:12 06. 少女レイ / みきとP feat.初音ミク
0:35:03 07. ただ君に晴れ / ヨルシカ
0:42:32 08. 115万キロのフィルム / Official髭男dism
0:48:00 09. I LOVE... / Official髭男dism
0:53:13 10. カタオモイ / Aimer

0:56:58 11. たばこ / コレサワ
1:07:31 12. 夜に駆ける / YOASOBI
1:11:56 13. アイノカタチ feat. HIDE / MISIA
1:16:32 14. なんでもないや / RADWIMPS
1:22:23 15. スパークル / RADWIMPS

1:31:32 16. 怪獣の花唄 / Vaundy
1:37:00 17. 群青 / YOASOBI
1:41:22 18. ドライフラワー / 優里

1:48:11 スパチャ読み

1:55:33 19. Pale Blue / 米津玄師
2:00:25 ばいばーい！`,ur={video_title:ue,video_artist:be,video_id:ge,video_publish_date_str:pe,song_timeline:me},Ta=Object.freeze(Object.defineProperty({__proto__:null,default:ur,song_timeline:me,video_artist:be,video_id:ge,video_publish_date_str:pe,video_title:ue},Symbol.toStringTag,{value:"Module"})),$e="【歌枠 / KARAOKE】楽しく歌う！喋る！歌枠💗【#パレプロ #香鳴ハノン】",Oe="Hanon Ch. 香鳴ハノン【パレプロ】",he="zj9HBoXh10k",Ae="2024-06-10",Se=`0:02:28 はのはー！

0:04:06 01. わたしの一番かわいいところ / FRUITS ZIPPER
0:10:15 02. 言い訳Maybe / AKB48
0:17:31 03. 大声ダイヤモンド / AKB48
0:29:28 04. 10年桜 / AKB48
0:36:46 05. 涙サプライズ！ / AKB48

0:42:46 06. サインはB New Arrange Ver. / B小町 ルビー(CV:伊駒ゆりえ) 有馬かな(CV:潘めぐみ) MEMちょ(CV:大久保瑠美)
0:48:31 07. No brand girls / μ's
0:54:05 08. Snow halation / μ's
1:01:00 09. おもいでしりとり / DIALOGUE+
1:10:19 10. Make you happy / NiziU

1:24:05 11. Q&Aリサイタル！ / 戸松遥
1:38:23 12. 可愛くてごめん / HoneyWorks
1:46:24 13. ダダダダ天使 / ナナヲアカリ
1:51:34 14. 粛聖!! ロリ神レクイエム☆ / しぐれうい
1:58:30 15. シル・ヴ・プレジデント / P丸様。

2:13:27 16. アイドル / YOASOBI
2:19:16 17. ファンサ / mona（CV：夏川椎菜）
2:26:41 18. #超絶かわいい / mona（CV：夏川椎菜）

2:36:20 スパチャ読み
2:45:20 はのはー！
2:45:41 END / Cパート`,br={video_title:$e,video_artist:Oe,video_id:he,video_publish_date_str:Ae,song_timeline:Se},ja=Object.freeze(Object.defineProperty({__proto__:null,default:br,song_timeline:Se,video_artist:Oe,video_id:he,video_publish_date_str:Ae,video_title:$e},Symbol.toStringTag,{value:"Module"})),ye="【歌枠 / KARAOKE】お姉さんな歌声で歌う✨【#パレプロ #香鳴ハノン】",fe="Hanon Ch. 香鳴ハノン【パレプロ】",Ce="1nBxHOUStHY",Ee="2024-06-14",Pe=`0:02:19 はのはー！

0:06:30 01. 愛のうた / 倖田來未
0:14:28 02. マリーゴールド / あいみょん
0:22:23 03. 貴方の恋人になりたいのです / 阿部真央
0:28:32 04. カタオモイ / Aimer
0:33:58 05. 風になる / つじあやの

0:39:45 06. BLUE BIRD / 浜崎あゆみ
0:44:40 07. 茜色の約束 / いきものがかり
0:51:08 08. コイスルオトメ / いきものがかり
0:58:15 09. 影 / 柴咲コウ
1:02:47 10. ひと恋めぐり / 柴咲コウ

1:08:40 11. Best Friend / Kiroro
1:16:10 12. Can You Keep A Secret? / 宇多田ヒカル
1:22:33 13. ラムのラブソング / 松谷祐子
1:26:58 14. 少女レイ / みきとP
1:32:17 15. だから僕は音楽を辞めた / ヨルシカ

1:37:23 16. ただ君に晴れ / ヨルシカ
1:40:54 17. 春泥棒 / ヨルシカ
1:47:35 18. 言って。 / ヨルシカ
1:57:10 19. Yeah! めっちゃホリディ / 松浦亜弥
2:02:09 20. LOVEマシーン / モーニング娘。

2:13:42 21. たばこ / コレサワ
2:20:47 22. トリセツ / 西野カナ
2:27:20 23. オトナブルー / 新しい学校のリーダーズ
2:32:00 24. 渡月橋 ～君 想ふ～ / 倉木麻衣
2:42:13 25. ダイアモンド クレバス / シェリル・ノーム starring May'n

2:48:53 26. トライアングラー / 坂本真綾
2:57:23 27. レット・イット・ゴー～ありのままで～ / 松たか子

3:05:22 スパチャ読み
3:08:12 はのはー！
3:08:23 END / Cパート`,gr={video_title:ye,video_artist:fe,video_id:Ce,video_publish_date_str:Ee,song_timeline:Pe},Ha=Object.freeze(Object.defineProperty({__proto__:null,default:gr,song_timeline:Pe,video_artist:fe,video_id:Ce,video_publish_date_str:Ee,video_title:ye},Symbol.toStringTag,{value:"Module"})),Re="【 #昭和レトロ歌枠リレー 】歌って踊る令和のVアイドルが色っぽく歌う…！？💗【#パレプロ #香鳴ハノン】",Me="Hanon Ch. 香鳴ハノン【パレプロ】",Ke="Gj-0sJZ6oS8",Ne="2024-06-15",Te=`0:01:15 はのはー！

0:04:38 01. MUGO・ん・・・色っぽい / 工藤 静香
0:10:24 02. ペッパー警部 / ピンク・レディー
0:16:25 03. S・O・S / ピンク・レディー
0:19:19 04. セカンド・ラブ / 中森明菜
0:25:43 05. 瑠璃色の地球 / 松田聖子

0:30:24 はのはー！`,pr={video_title:Re,video_artist:Me,video_id:Ke,video_publish_date_str:Ne,song_timeline:Te},Ia=Object.freeze(Object.defineProperty({__proto__:null,default:pr,song_timeline:Te,video_artist:Me,video_id:Ke,video_publish_date_str:Ne,video_title:Re},Symbol.toStringTag,{value:"Module"})),je="【歌枠 / KARAOKE】かわいいアニソン縛り歌枠💗【#パレプロ #香鳴ハノン】",He="Hanon Ch. 香鳴ハノン【パレプロ】",Ie="Y1IQ1WyBQgM",De="2024-06-18",Be=`0:01:47 はのはー！

0:05:12 01. 恋は渾沌の隷也 / 後ろから這いより隊Ｇ
0:11:15 02. Baby Sweet Berry Love / 小倉唯
0:17:40 03. HoneyCome!! / 小倉唯
0:23:41 04. 星間飛行 / ランカ・リー＝中島愛
0:27:51 05. ハレ晴レユカイ / 平野綾(涼宮ハルヒ)・茅原実里(長門有希)・後藤邑子(朝比奈みくる) 

0:33:10 06. ふわふわ時間 / 桜高軽音部
0:38:40 07. ごはんはおかず / 放課後ティータイム
0:42:00 08. 天使にふれたよ / 放課後ティータイム
0:48:28 09. ちゅ、多様性。 / ano
0:53:14 10. 恋は渾沌の隷也 / 後ろから這いより隊Ｇ

1:02:38 11. Q&A リサイタル! / 戸松遥

1:09:20 スパチャ読み
1:14:00 はのはー！
1:14:09 END / Cパート`,mr={video_title:je,video_artist:He,video_id:Ie,video_publish_date_str:De,song_timeline:Be},Da=Object.freeze(Object.defineProperty({__proto__:null,default:mr,song_timeline:Be,video_artist:He,video_id:Ie,video_publish_date_str:De,video_title:je},Symbol.toStringTag,{value:"Module"})),Le="【歌枠 / KARAOKE】1曲聴いていきませんか？アニソン中心に色々歌う✨【#パレプロ #香鳴ハノン】",Ve="Hanon Ch. 香鳴ハノン【パレプロ】",Ue="W_OLTm30V7I",ze="2024-06-23",Ge=`0:02:32 はのはー！

0:06:46 01. ステラブリーズ / 春奈るな
0:12:12 02. アイヲウタエ / 春奈るな
0:19:54 03. 君の知らない物語 / supercell
0:27:21 04. 青春コンプレックス / 結束バンド
0:31:06 05. 星座になれたら / 結束バンド

0:40:26 06. U&I / 放課後ティータイム
0:48:49 07. Unmei♪wa♪Endless! / 放課後ティータイム
0:52:56 08. GO! GO! MANIAC / 放課後ティータイム
0:58:37 09. ぴゅあぴゅあはーと / 放課後ティータイム
1:03:26 10. ギー太に首ったけ / 平沢唯(CV:豊崎愛生)

1:07:10 11. ふでペン ～ボールペン～ / 放課後ティータイム
1:13:10 12. ミックスナッツ / Official髭男dism
1:17:51 13. 恋は渾沌の隷也 / 後ろから這いより隊G
1:22:46 14. 恋は渾沌の隷也 / 後ろから這いより隊G
1:27:08 15. 恋は渾沌の隷也 / 後ろから這いより隊G

1:35:02 16. かくしん的☆めたまるふぉ～ぜっ! / 土間うまる(田中あいみ)
1:46:35 17. ふ・れ・ん・ど・し・た・い / 学園生活部
1:51:30 18. アンハッピーエンドワールド / 直樹美紀(高橋李依)＆恵飛須沢胡桃(小澤亜李) ※アカペラ歌唱
1:56:47 19. クラクラ / Ado
2:01:00 20. 色彩 / yama

2:07:02 21. 小さな魔法 / ステレオポニー
2:12:19 22. ないない / ReoNa
2:17:04 23. Rising Hope / LiSA
2:22:30 24. アイドル / YOASOBI
2:29:07 25. Together / あきよしふみえ

2:37:30 26. 星間飛行 / ランカ・リー＝中島愛

2:44:10 スパチャ読み
2:54:01 はのはー！`,$r={video_title:Le,video_artist:Ve,video_id:Ue,video_publish_date_str:ze,song_timeline:Ge},Ba=Object.freeze(Object.defineProperty({__proto__:null,default:$r,song_timeline:Ge,video_artist:Ve,video_id:Ue,video_publish_date_str:ze,video_title:Le},Symbol.toStringTag,{value:"Module"})),ke="【歌枠 / KARAOKE】ずっと真夜中でいいのに。縛り歌枠🌙【#パレプロ #香鳴ハノン】",Ye="Hanon Ch. 香鳴ハノン【パレプロ】",Fe="hkLrFFMDKwA",We="2024-06-28",we=`0:02:25 はのはー！

0:03:58 01. 低血ボルト / ずっと真夜中でいいのに。
0:08:19 02. あいつら全員同窓会 / ずっと真夜中でいいのに。
0:14:54 03. ヒューマノイド / ずっと真夜中でいいのに。
0:21:02 04. 勘冴えて悔しいわ / ずっと真夜中でいいのに。
0:25:45 05. MILABO / ずっと真夜中でいいのに。

0:31:59 06. 勘ぐれい / ずっと真夜中でいいのに。
0:37:54 07. 脳裏上のクラッカー / ずっと真夜中でいいのに。
0:43:21 08. お勉強しといてよ / ずっと真夜中でいいのに。
0:51:29 09. 正しくなれない / ずっと真夜中でいいのに。
0:55:55 10. 秒針を噛む / ずっと真夜中でいいのに。

1:06:15 はのはー！（２周目スタート）

1:07:07 11. 低血ボルト / ずっと真夜中でいいのに。
1:10:57 12. あいつら全員同窓会 / ずっと真夜中でいいのに。 ※パソコンくんの不調により中断あり
1:13:53 おかえりー！
1:16:38 12. あいつら全員同窓会 / ずっと真夜中でいいのに。
1:21:58 13. ヒューマノイド / ずっと真夜中でいいのに。
1:26:40 14. 勘冴えて悔しいわ / ずっと真夜中でいいのに。
1:30:54 15. MILABO / ずっと真夜中でいいのに。

1:35:35 16. 勘ぐれい / ずっと真夜中でいいのに。
1:40:09 17. 脳裏上のクラッカー / ずっと真夜中でいいのに。
1:45:05 18. お勉強しといてよ / ずっと真夜中でいいのに。
1:50:42 19. 正しくなれない / ずっと真夜中でいいのに。
1:57:30 20. 秒針を噛む / ずっと真夜中でいいのに。

2:03:35 雑談（配信欲がすごいハノンちゃん、オール？？？）
2:15:00 スパチャ読み
2:18:00 はのはー！
2:18:30 END / Cパート
2:19:07 7月生写真サンプル公開`,Or={video_title:ke,video_artist:Ye,video_id:Fe,video_publish_date_str:We,song_timeline:we},La=Object.freeze(Object.defineProperty({__proto__:null,default:Or,song_timeline:we,video_artist:Ye,video_id:Fe,video_publish_date_str:We,video_title:ke},Symbol.toStringTag,{value:"Module"})),Qe="【歌枠 / KARAOKE】ウエディングソング＆ラブソング縛り歌枠🌙【#パレプロ #香鳴ハノン】",Je="Hanon Ch. 香鳴ハノン【パレプロ】",Ze="Tp0AqHmYt3I",Xe="2024-06-29",qe=`0:01:21 はのはー！

0:05:56 01. 愛の花 / あいみょん
0:11:59 02. 永遠にともに / コブクロ
0:17:19 03. 結婚闘魂行進曲「マブダチ」 / 氣志團
0:24:12 04. CAN YOU CELEBRATE? / 安室奈美恵 ※ワンコーラス
0:29:49 05. 虹 / 菅田将暉 ※サビだけ

0:31:59 06. バンザイ〜好きでよかった〜 / ウルフルズ
0:37:17 07. ハッピーウェディング前ソング / ヤバイTシャツ屋さん
0:42:36 08. Million Films / コブクロ
0:48:30 09. OCEAN / B'z
0:57:45 10. スターラブレイション / ケラケラ

1:03:55 11. 超めでたいソング 〜こんなに幸せでいいのかな？〜 / FRUITS ZIPPER
1:10:04 12. 恋文 / Every Little Thing
1:17:41 13. Lovers / sumika
1:22:45 14. Familia / sumika
1:29:36 15. 恋 / 星野源

1:35:20 16. 糸 / 中島みゆき
1:40:16 17. 愛をこめて花束を / Superfly
1:46:40 18. Lovers / sumika

1:51:36 スパチャ読み
1:58:26 はのはー！
1:58:46 END / Cパート`,hr={video_title:Qe,video_artist:Je,video_id:Ze,video_publish_date_str:Xe,song_timeline:qe},Va=Object.freeze(Object.defineProperty({__proto__:null,default:hr,song_timeline:qe,video_artist:Je,video_id:Ze,video_publish_date_str:Xe,video_title:Qe},Symbol.toStringTag,{value:"Module"})),xe="【歌枠｜KARAOKE】夏曲縛り！夏祭りに行きたくなる歌枠🍧【#パレプロ #香鳴ハノン】",nt="Hanon Ch. 香鳴ハノン【パレプロ】",et="yNW8Ry_8frk",tt="2024-07-19",it=`🎀🎶今回のタイムスタンプ＆セトリ🎀🎶
※編集後対応版(ほぼハノンちゃんの作ったチャプターと同じものになります)
0:00:00 OP
0:03:00 はのは～

0:06:16 マイリッチサマーブルース / Sumika 
0:14:30 世界は恋に落ちている / CHiCO 
0:22:12 東京サマーセッション / HoneyWorks 
0:28:03 うたかた花火 / Supercell 
0:35:14 SUMMER SONG / YUI   
0:39:58 夏祭り / Whiteberry 
0:44:31 夏色 / ゆず 
0:48:45 わたがし / Back number 
1:01:43 マイリッチサマーブルース / Sumika 
1:06:51 ミュージック・アワー / ポルノグラフィティ 
1:17:31 青と夏 / Mrs. GREEN APPLE 
1:29:28 東京サマーセッション / HoneyWorks
1:35:00 スパチャ読み

1:38:00 ツイッターのインプが爆のびした話
1:43:16 エンドカード`,Ar={video_title:xe,video_artist:nt,video_id:et,video_publish_date_str:tt,song_timeline:it},Ua=Object.freeze(Object.defineProperty({__proto__:null,default:Ar,song_timeline:it,video_artist:nt,video_id:et,video_publish_date_str:tt,video_title:xe},Symbol.toStringTag,{value:"Module"})),ot="【縦型歌雑】初見さんのコメントで「世界一可愛い私」を歌える雑談歌枠💗【香鳴ハノン/パレプロ】",_t="Hanon Ch. 香鳴ハノン【パレプロ】",st="cUW9LSiyCiI",dt="2024-07-21",rt=`今回のタイムスタンプ＆セトリ\r
0:00:00 OP\r
0:04:58 はのはー
\r
0:14:30 ；0:18:34 世界一可愛い私 / 藤田ことね\r
0:25:04 ；0:28:59 世界一可愛い私 / 藤田ことね\r
0:29:08 ；0:33:08 世界一可愛い私 / 藤田ことね\r
0:33:15 学マスの話\r
0:46:35 shiny smile(アカペラ)\r
0:50:37 何の話しようか\r
0:53:55 ；0:57:56 世界一可愛い私 / 藤田ことね\r
0:59:31 学マス楽曲あれこれ歌いたいよね\r
1:32:28 学校の給食の話\r
1:36:28 ほんとに言ってる！？
\r
1:48:56  ；1:52:56 世界一可愛い私 / 藤田ことね\r
1:55:01  ；1:59:04 世界一可愛い私 / 藤田ことね\r
2:12:20  ；2:16:19 世界一可愛い私 / 藤田ことね\r
2:18:08  ；2:22:09 世界一可愛い私 / 藤田ことね\r
2:28:24  ；2:32:25 世界一可愛い私 / 藤田ことね\r
2:32:55  ；2:36:54 世界一可愛い私 / 藤田ことね\r
\r
2:39:02 スパチャ読み\r
\r
2:42:36  ；2:46:43 世界一可愛い私 / 藤田ことね\r
2:49:52 エンドカード`,Sr={video_title:ot,video_artist:_t,video_id:st,video_publish_date_str:dt,song_timeline:rt},za=Object.freeze(Object.defineProperty({__proto__:null,default:Sr,song_timeline:rt,video_artist:_t,video_id:st,video_publish_date_str:dt,video_title:ot},Symbol.toStringTag,{value:"Module"})),lt="【歌枠｜KARAOKE】同接200人目指して！オールジャンル歌う🎤✨【#パレプロ #香鳴ハノン】",at="Hanon Ch. 香鳴ハノン【パレプロ】",vt="FCVw8lVUwN0",ct="2024-07-24",ut=`0:01:28 はのはー！

0:08:19 01. 群青日和 / 東京事変
0:18:22 02. Everyday、カチューシャ / AKB48
0:24:55 03. いぬねこ。青春真っ盛り / わーすた
0:33:34 04. すきっ！ / 超ときめき宣伝部
0:40:11 05. 世界一可愛い私 / 藤田ことね

0:46:51 06. #超絶かわいい / mona（CV：夏川椎菜）
0:51:26 07. わたしの一番かわいいところ / FRUITS ZIPPER
0:57:34 08. うたかた花火 / supercell
1:04:29 09. 君の知らない物語 / supercell
1:11:30 10. 唱 / Ado

1:17:54 11. Good-bye days / YUI for 雨音薫
1:23:55 12. 星座になれたら / 結束バンド
1:34:44 13. 怪獣の花唄 / Vaundy
1:41:54 14. ダンスホール / Mrs. GREEN APPLE

1:49:45 8月生写真サンプル公開
2:00:02 スパチャ読み
2:06:24 はのはー！
2:07:22 END / Cパート`,yr={video_title:lt,video_artist:at,video_id:vt,video_publish_date_str:ct,song_timeline:ut},Ga=Object.freeze(Object.defineProperty({__proto__:null,default:yr,song_timeline:ut,video_artist:at,video_id:vt,video_publish_date_str:ct,video_title:lt},Symbol.toStringTag,{value:"Module"})),bt="【歌枠｜KARAOKE】学園アイドルマスターオンリーセトリ🎤💗【#パレプロ #香鳴ハノン】",gt="Hanon Ch. 香鳴ハノン【パレプロ】",pt="6jDomuGjUVg",mt="2024-07-26",$t=`0:01:54 はのはー！

0:04:54 01. 初 / 初星学園
0:13:07 02. Fighting My Way / 花海咲季
0:18:59 03. Luna say maybe / 月村手毬
0:25:26 04. 世界一可愛い私 / 藤田ことね
0:30:53 05. The Rolling Riceball / 花海佑芽

0:36:37 06. Wonder Scale / 倉本千奈
0:44:23 07. 光景 / 篠澤広
0:53:52 08. Tame-Lie-One-Step / 紫雲清夏
1:03:02 09. Fluorite / 有村麻央
1:09:54 10. clumsy trick / 姫崎莉波

1:16:09 11. 白線 / 葛城リーリヤ
1:21:46 12. Campus mode!! / 初星学園
1:35:51 13. 光景 / 篠澤広
1:42:37 14. Luna say maybe / 月村手毬
1:48:54 15. Luna say maybe / 月村手毬

1:54:45 16. Fighting My Way / 花海咲季
1:59:07 17. 白線 / 葛城リーリヤ
2:04:53 18. Campus mode!! / 初星学園

2:10:54 スパチャ読み
2:20:28 はのはー！
2:20:46 END / Cパート`,fr={video_title:bt,video_artist:gt,video_id:pt,video_publish_date_str:mt,song_timeline:$t},ka=Object.freeze(Object.defineProperty({__proto__:null,default:fr,song_timeline:$t,video_artist:gt,video_id:pt,video_publish_date_str:mt,video_title:bt},Symbol.toStringTag,{value:"Module"})),Ot="【歌枠｜KARAOKE】平成アニソンといえば！？有名＆懐かしい曲をたくさん歌う🎤✨【#パレプロ #香鳴ハノン】",ht="Hanon Ch. 香鳴ハノン【パレプロ】",At="WiABilUXp-A",St="2024-07-30",yt=`0:03:20 はのはー！

0:12:17 01. カサブタ / 千綿偉功
0:22:01 02. 檄! 帝国華撃団 / 真宮寺さくら(横山智佐)&帝国歌劇団
0:26:20 03. 撲殺天使ドクロちゃん / ドクロちゃん(千葉紗子)
0:37:04 04. Butter-Fly / 和田光司
0:44:06 05. Q&Aリサイタル / 戸松遥

0:56:20 06. かくしん的☆めたまるふぉ～ぜっ!  / 土間うまる(田中あいみ)
1:02:11 07. はなまるぴっぴはよいこだけ / A応P
1:12:29 08. プラチナ / 坂本真綾
1:18:17 09. おジャ魔女カーニバル!! / MAHO堂
1:28:52 10. ハレ晴レユカイ / 涼宮ハルヒ(平野綾)・長門有希(茅原実里)・朝比奈みくる(後藤邑子)

1:36:23 11. God knows... / 涼宮ハルヒ(平野綾)
1:45:00 12. 青空のナミダ / 高橋瞳
1:51:20 13. only my railgun / fripSide
2:05:56 14. Rising Hope / LiSA
2:15:14 15. 空色デイズ / 中川翔子

2:20:47 16. Don't say "lazy" / 桜高軽音部
2:27:46 17. staple stable / 戦場ヶ原ひたぎ(斎藤千和)
2:33:48 18. ナイショの話 / ClariS
2:39:42 19. 創聖のアクエリオン / AKINO
2:46:33 20. 撲殺天使ドクロちゃん / ドクロちゃん(千葉紗子)

2:59:14 スパチャ読み
3:25:33 はのはー！
3:25:41 END / Cパート
3:26:34 8月生写真一挙公開`,Cr={video_title:Ot,video_artist:ht,video_id:At,video_publish_date_str:St,song_timeline:yt},Ya=Object.freeze(Object.defineProperty({__proto__:null,default:Cr,song_timeline:yt,video_artist:ht,video_id:At,video_publish_date_str:St,video_title:Ot},Symbol.toStringTag,{value:"Module"})),ft="【歌枠｜KARAOKE】アイドル全開歌枠💗アイドルソング中心に歌う🎤✨学マスも！？【#パレプロ #香鳴ハノン】",Ct="Hanon Ch. 香鳴ハノン【パレプロ】",Et="0zowYftP2OE",Pt="2024-08-03",Rt=`0:04:26 はのはー！

0:07:28 01. だいしきゅーだいしゅき / femme fatale
0:16:39 02. プロミスザスター / BiSH
0:24:14 03. アンビバレント / 櫻坂46
0:36:59 04. ナギイチ / NMB48
0:43:47 05. 白線 / 葛城リーリヤ

0:48:48 06. 世界一可愛い私 / 藤田ことね
0:56:41 07. Campus mode!! / 初星学園
1:07:15 08. 行くぜっ!怪盗少女 / ももいろクローバーZ
1:12:53 09. Baby Sweet Berry Love / 小倉唯
1:18:49 10. いぬねこ。青春真っ盛り / わーすた

1:25:00 11. 言い訳Maybe / AKB48
1:34:18 12. 片想いFinally / SKE48
1:41:22 13. おもいでしりとり / DIALOGUE+
1:49:28 14. 白線 / 葛城リーリヤ
1:53:53 15. 白線 / 葛城リーリヤ

2:03:50 スパチャ読み
2:08:12 はのはー！
2:09:45 END / Cパート`,Er={video_title:ft,video_artist:Ct,video_id:Et,video_publish_date_str:Pt,song_timeline:Rt},Fa=Object.freeze(Object.defineProperty({__proto__:null,default:Er,song_timeline:Rt,video_artist:Ct,video_id:Et,video_publish_date_str:Pt,video_title:ft},Symbol.toStringTag,{value:"Module"})),Mt="【耐久歌枠】10人初見さん来てくれるまで寝れない！？雑談歌枠💗【#パレプロ #香鳴ハノン】",Kt="Hanon Ch. 香鳴ハノン【パレプロ】",Nt="OfNSAsHXfR0",Tt="2024-08-04",jt=`0:02:20 はのはー！

0:11:22 01. 白線 / 葛城リーリヤ
0:23:13 02. Snow halation / μ's
0:30:43 03. 世界一可愛い私 / 藤田ことね
0:37:40 04. あの夢をなぞって / YOASOBI
0:43:15 05. Rising Hope / LiSA

1:00:45 06. ハレ晴レユカイ / 涼宮ハルヒ(平野綾)・長門有希(茅原実里)・朝比奈みくる(後藤邑子)
1:05:48 07. 炎 / LiSA
1:12:20 08. サインはB New Arrange Ver. / B小町 ルビー(伊駒ゆりえ)、有馬かな(潘めぐみ)、MEMちょ(大久保瑠美)
1:18:32 09. adrenaline!!! / TrySail
1:30:33 10. 星間飛行 / ランカ・リー＝中島愛

1:37:29 11. 脳裏上のクラッカー / ずっと真夜中でいいのに。
1:47:06 12. 神っぽいな / Ado
1:54:19 13. 怪物 / YOASOBI

2:04:28 スパチャ読み
2:09:04 はのはー！
2:09:14 END / Cパート`,Pr={video_title:Mt,video_artist:Kt,video_id:Nt,video_publish_date_str:Tt,song_timeline:jt},Wa=Object.freeze(Object.defineProperty({__proto__:null,default:Pr,song_timeline:jt,video_artist:Kt,video_id:Nt,video_publish_date_str:Tt,video_title:Mt},Symbol.toStringTag,{value:"Module"})),Ht="【歌枠｜KARAOKE】初見さんも大歓迎！オールジャンル歌う夏曲歌枠👙✨【#パレプロ #香鳴ハノン】",It="Hanon Ch. 香鳴ハノン【パレプロ】",Dt="bzl27VqJq5k",Bt="2024-08-08",Lt=`0:01:05 はのはー！

0:08:17 01. 真夏のSounds good / AKB48
0:18:47 02. 夢見る 15歳 / スマイレージ
0:24:19 03. 世界には愛しかない / 欅坂46
0:31:13 04. 青い珊瑚礁 / 松田聖子
0:35:55 05. 出逢った頃のように / Every Little Thing

0:41:59 06. 少女レイ / みきとP
0:50:17 07. うたかた花火 / supercell
0:57:33 08. カブトムシ / aiko
1:04:47 09. あの夢をなぞって / YOASOBI
1:10:57 10. 青と夏 / Mrs. GREEN APPLE

1:17:56 11. 花に亡霊 / ヨルシカ
1:23:13 12. ひまわりの約束 / 秦基博
1:28:50 13. プラネタリウム / 大塚愛
1:36:37 14. 貴女の恋人になりたいのです / 阿部真央
1:43:11 15. secret base 〜君がくれたもの〜 / ZONE

1:48:44 スパチャ読み
1:51:33 はのはー！
1:51:52 END / Cパート`,Rr={video_title:Ht,video_artist:It,video_id:Dt,video_publish_date_str:Bt,song_timeline:Lt},wa=Object.freeze(Object.defineProperty({__proto__:null,default:Rr,song_timeline:Lt,video_artist:It,video_id:Dt,video_publish_date_str:Bt,video_title:Ht},Symbol.toStringTag,{value:"Module"})),Vt="【歌枠｜KARAOKE】盛り上がる！有名アニソンを歌う！初見さんも大歓迎✨【#パレプロ #香鳴ハノン】",Ut="Hanon Ch. 香鳴ハノン【パレプロ】",zt="DHzcNIkS7hk",Gt="2024-08-15",kt=`0:02:37 はのはー！

0:08:17 01. 残酷な天使のテーゼ / 高橋洋子
0:13:53 02. コネクト / ClariS
0:21:30 03. シュガーソングとビターステップ / UNISON SQUARE GARDEN
0:26:02 04. オリオンをなぞる / UNISON SQUARE GARDEN
0:32:29 05. 星座になれたら / 結束バンド

0:39:32 06. 君の知らない物語 / supercell
0:51:08 07. タッチ / 岩崎良美
0:55:09 08. そばかす / JUDY AND MARY
1:01:57 09. いけないボーダーライン / ワルキューレ
1:14:22 10. 吹雪 / 西沢幸奏

1:21:45 11. 吹雪 / 西沢幸奏
1:38:05 12. トライアングラー / 坂本真綾
1:43:47 13. 謎 / 小松未歩
1:49:47 14. ラムのラブソング / 松谷祐子
1:54:38 15. ムーンライト伝説 / DALI

1:58:59 実家の子供達かわいいエピソード
2:01:48 スパチャ読み
2:21:00 はのはー！
2:21:42 END / Cパート`,Mr={video_title:Vt,video_artist:Ut,video_id:zt,video_publish_date_str:Gt,song_timeline:kt},Qa=Object.freeze(Object.defineProperty({__proto__:null,default:Mr,song_timeline:kt,video_artist:Ut,video_id:zt,video_publish_date_str:Gt,video_title:Vt},Symbol.toStringTag,{value:"Module"})),Yt="【#世界で1番かわいい歌枠リレー】Vアイドル全力のかわいいをお届け💗【#パレプロ #香鳴ハノン】",Ft="Hanon Ch. 香鳴ハノン【パレプロ】",Wt="XnU-DC7zR8o",wt="2024-08-17",Qt=`0:01:27 はのはー！

0:04:27 01. 世界一可愛い私 / 藤田ことね
0:10:26 02. irony / ClariS
0:18:37 03. スマイル / 森七菜
0:22:59 04. 太陽曰く燃えよカオス / 後ろから這いより隊G
0:27:01 05. HoneyCome!! / 小倉唯

0:31:04 はのはー！`,Kr={video_title:Yt,video_artist:Ft,video_id:Wt,video_publish_date_str:wt,song_timeline:Qt},Ja=Object.freeze(Object.defineProperty({__proto__:null,default:Kr,song_timeline:Qt,video_artist:Ft,video_id:Wt,video_publish_date_str:wt,video_title:Yt},Symbol.toStringTag,{value:"Module"})),Jt="白線 - 初星学園＆葛城リーリヤ Covered by 香鳴ハノン / パレプロ【歌ってみた】",Zt="Hanon Ch. 香鳴ハノン【パレプロ】",Xt="HkiSReblkiI",qt="2024-08-18",xt="0:00:00 白線 / 葛城リーリヤ",Nr={video_title:Jt,video_artist:Zt,video_id:Xt,video_publish_date_str:qt,song_timeline:xt},Za=Object.freeze(Object.defineProperty({__proto__:null,default:Nr,song_timeline:xt,video_artist:Zt,video_id:Xt,video_publish_date_str:qt,video_title:Jt},Symbol.toStringTag,{value:"Module"})),n0="【歌枠｜KARAOKE】活動5年目もよろしくね✨深夜のピアノカラオケ歌枠🌙J-POP・バラード中心【#パレプロ #香鳴ハノン】",e0="Hanon Ch. 香鳴ハノン【パレプロ】",t0="Da9-XONRwgs",i0="2024-08-19",o0=`0:04:31 はのはー！

0:12:34 01. 猫 / DISH//
0:19:48 02. マリーゴールド / あいみょん
0:25:01 03. 君はロックを聴かない / あいみょん
0:32:34 04. Lemon / 米津玄師
0:39:18 05. Pale Blue / 米津玄師

0:47:13 06. 水平線 / back number
0:57:45 07. First Love / 宇多田ヒカル
1:02:08 08. ハナミズキ / 一青窈
1:10:10 09. 366日 / HY
1:18:25 10. クリスマスソング / back number

1:25:34 11. 奏 / スキマスイッチ
1:31:20 12. ひまわりの約束 / 秦基博
1:39:44 13. カタオモイ / Aimer
1:47:15 14. ただ君に晴れ / ヨルシカ
1:53:07 15. なんでもないよ、 / マカロニえんぴつ

1:59:36 スパチャ読み
2:29:36 はのはー！
2:30:04 END / Cパート`,Tr={video_title:n0,video_artist:e0,video_id:t0,video_publish_date_str:i0,song_timeline:o0},Xa=Object.freeze(Object.defineProperty({__proto__:null,default:Tr,song_timeline:o0,video_artist:e0,video_id:t0,video_publish_date_str:i0,video_title:n0},Symbol.toStringTag,{value:"Module"})),_0="【歌枠｜KARAOKE】明るい気持ちになれる歌を歌う🎤✨【#パレプロ #香鳴ハノン】",s0="Hanon Ch. 香鳴ハノン【パレプロ】",d0="n8hn4PimJpA",r0="2024-08-22",l0=`0:01:54 はのはー！

0:05:16 01. 風になる / つじあやの
0:10:49 02. SUMMER SONG / YUI
0:17:24 03. ルージュの伝言 / 荒井由実
0:21:26 04. ダンスホール / Mrs. GREEN APPLE
0:26:23 05. 青と夏 / Mrs. GREEN APPLE

0:35:49 06. Happiness / 嵐
0:41:44 07. ともに / WANIMA
0:48:35 08. ミュージック・アワー / ポルノグラフィティ
0:54:01 09. 気まぐれロマンティック / いきものがかり
0:58:16 10. さくらんぼ / 大塚愛

1:04:29 11. Together / あきよしふみえ
1:11:42 12. ミックスナッツ / Official髭男dism
1:17:29 13. SUN / 星野源
1:23:18 14. ドラえもん / 星野源
1:32:22 15. サインはB / B小町 アイ(高橋李依)

1:39:23 スパチャ読み
1:42:14 はのはー！
1:42:41 END / Cパート`,jr={video_title:_0,video_artist:s0,video_id:d0,video_publish_date_str:r0,song_timeline:l0},qa=Object.freeze(Object.defineProperty({__proto__:null,default:jr,song_timeline:l0,video_artist:s0,video_id:d0,video_publish_date_str:r0,video_title:_0},Symbol.toStringTag,{value:"Module"})),a0="【#パレプロ感謝祭直前歌枠リレー】6番手💗パワフルな歌声で魅せちゃうぞ！【#パレプロ #香鳴ハノン】",v0="Hanon Ch. 香鳴ハノン【パレプロ】",c0="9He-662gsAY",u0="2024-08-25",b0=`今回のタイムスタンプ＆セトリ\r
0:00:00 OP
0:01:39 白線 / 初星学園と葛城リーリヤ
0:09:13 Catch You Catch Me / グミ
0:13:02 Lovers / Sumika
0:20:48 ALIVE / ClariS
0:24:23 花の塔 / さユり

おつのんでしたー`,Hr={video_title:a0,video_artist:v0,video_id:c0,video_publish_date_str:u0,song_timeline:b0},xa=Object.freeze(Object.defineProperty({__proto__:null,default:Hr,song_timeline:b0,video_artist:v0,video_id:c0,video_publish_date_str:u0,video_title:a0},Symbol.toStringTag,{value:"Module"})),g0="【歌枠｜KARAOKE】学マス廃課金Vアイドルによる学マスオリ曲オンリーセトリ歌枠🎤💗【#パレプロ #香鳴ハノン】",p0="Hanon Ch. 香鳴ハノン【パレプロ】",m0="OckRsZaSMFU",$0="2024-08-30",O0=`0:04:49 はのはー！

0:09:11 01. 初 / 初星学園
0:18:21 02. Fighting My Way / 花海咲季
0:23:37 03. Boom Boom Pow / 花海咲季
0:29:09 04. Luna say maybe / 月村手毬
0:35:25 05. アイヴイ / 月村手毬

0:43:10 06. 叶えたい、ことばかり / 月村手毬
0:49:00 07. 世界一可愛い私 / 藤田ことね
0:53:01 08. The Rolling Riceball / 花海佑芽
0:58:27 09. 光景 / 篠澤広
1:02:52 10. Fluorite / 有村麻央

1:12:30 11. clumsy trick / 姫崎莉波
1:16:25 12. Tame-Lie-One-Step / 紫雲清夏
1:22:43 13. Wonder Scale / 倉本千奈
1:27:19 14. 白線 / 葛城リーリヤ
1:34:00 15. Yellow Big Bang！ / 藤田ことね

1:38:11 16. Campus mode!! / 初星学園
1:50:50 17. Luna say maybe / 月村手毬
1:56:41 18. Tame-Lie-One-Step / 紫雲清夏
2:01:38 19. Fighting My Way / 花海咲季
2:05:05 20. Fighting My Way / 花海咲季

2:11:35 スパチャ読み
2:18:00 はのはー！
2:18:21 END / Cパート`,Ir={video_title:g0,video_artist:p0,video_id:m0,video_publish_date_str:$0,song_timeline:O0},n4=Object.freeze(Object.defineProperty({__proto__:null,default:Ir,song_timeline:O0,video_artist:p0,video_id:m0,video_publish_date_str:$0,video_title:g0},Symbol.toStringTag,{value:"Module"})),h0="【歌枠｜KARAOKE】オールジャンル！リクエスト曲を歌う長時間歌枠🎤✨【#パレプロ #香鳴ハノン】",A0="Hanon Ch. 香鳴ハノン【パレプロ】",S0="xEek0CuiqiQ",y0="2024-09-02",f0=`0:03:49 はのはー！

0:16:48 01. 星座になれたら / 結束バンド
0:24:37 02. ALIVE / ClariS
0:41:58 03. Q&Aリサイタル / 戸松遥
0:49:52 04. 泪のムコウ / ステレオポニー
1:02:54 05. 変わらないもの / 奥華子

1:08:33 06. 糸 / 中島みゆき
1:18:43 07. すきっ! / 超ときめき♡宣伝部
1:30:21 08. 放課後オーバーフロウ / ランカ・リー＝中島愛 
1:39:03 09. かくれんぼ / AliA
1:50:44 10. なんでもないよ / マカロニえんぴつ

1:56:10 11. 勘ぐれい / ずっと真夜中でいいのに。
2:04:21 12. HoneyCome!! / 小倉唯
2:11:41 13. 白線 / 葛城リーリヤ
2:25:10 14. yell / 香鳴ハノン
2:36:23 15. 世界一可愛い私 / 藤田ことね

2:44:06 16. irony / ClariS
2:50:09 17. スマイル / 森七菜
2:59:35 18. プラチナ / 坂本真綾
3:05:38 19. ふわふわ時間 / 放課後ティータイム
3:16:57 20. あの夢をなぞって / YOASOBI

3:25:39 21. トリセツ / 西野カナ
3:31:39 22. シャルル / バルーン
3:36:32 23. 少女レイ / みきとP
3:44:55 24. Lovers / sumika
3:50:51 25. おもいでしりとり / DIALOGUE+

3:58:52 26. ともに / WANIMA

4:03:44 スパチャ読み
4:27:52 はのはー！
4:28:02 END / Cパート
4:28:58 9月生写真サンプル公開`,Dr={video_title:h0,video_artist:A0,video_id:S0,video_publish_date_str:y0,song_timeline:f0},e4=Object.freeze(Object.defineProperty({__proto__:null,default:Dr,song_timeline:f0,video_artist:A0,video_id:S0,video_publish_date_str:y0,video_title:h0},Symbol.toStringTag,{value:"Module"})),C0="【歌枠｜KARAOKE】アニソン縛りで楽しく歌う歌枠🎤✨【#パレプロ #香鳴ハノン】",E0="Hanon Ch. 香鳴ハノン【パレプロ】",P0="PiDVIGcZbKs",R0="2024-09-04",M0=`0:04:24 はのはー！

0:12:04 01. 月並みに輝け / 結束バンド
0:18:30 02. 青春コンプレックス / 結束バンド
0:24:04 03. ステラブリーズ / 春奈るな
0:31:37 04. Believe / Folder5
0:37:08 05. Rising Hope / LiSA

0:45:19 06. Listen!! / 放課後ティータイム
0:51:48 07. インフェルノ / Mrs. GREEN APPLE
0:58:28 08. カサブタ / 千綿偉功
1:09:35 09. 星間飛行 / ランカ・リー＝中島愛
1:13:38 10. ライオン / May'n/中島愛

1:21:47 11. Catch You Catch Me / 日向めぐみ
1:27:08 12. God knows... / 涼宮ハルヒ(平野綾)
1:33:59 13. only my railgun / fripSide
1:40:26 14. Catch the Moment / LiSA
1:47:08 15. シュガーソングとビターステップ / UNISON SQUARE GARDEN

1:56:32 16. コネクト / ClariS
2:11:54 17. U&I / 放課後ティータイム
2:34:17 18. 星座になれたら / 結束バンド
2:40:23 19. 花の塔 / さユり
2:46:51 20. Butter-Fly / 和田光司

2:53:21 スパチャ読み
3:04:20 はのはー！
3:04:46 END / Cパート`,Br={video_title:C0,video_artist:E0,video_id:P0,video_publish_date_str:R0,song_timeline:M0},t4=Object.freeze(Object.defineProperty({__proto__:null,default:Br,song_timeline:M0,video_artist:E0,video_id:P0,video_publish_date_str:R0,video_title:C0},Symbol.toStringTag,{value:"Module"})),K0="【歌枠｜KARAOKE】初見さんが来ないと歌えない！？セットリストも初見さんに全委ね歌枠🎤✨【#パレプロ #香鳴ハノン】",N0="Hanon Ch. 香鳴ハノン【パレプロ】",T0="kPs8Y5XX76w",j0="2024-09-06",H0=`0:03:20 はのはー！

0:15:29 01. SHAMROCK / UVERworld
0:20:45 02. ミックスナッツ / Official髭男dism
0:28:12 03. ファンサ / mona（CV：夏川椎菜）
0:37:40 04. そばかす / JUDY AND MARY
0:47:35 05. プラチナ / 坂本真綾

0:54:21 06. だから僕は音楽を辞めた / ヨルシカ
1:28:27 07. 春泥棒 / ヨルシカ
1:35:54 08. Rising Hope / LiSA
1:45:59 09. 創聖のアクエリオン / AKINO
1:52:24 10. ブルーバード / いきものがかり

2:02:33 11. 世界一可愛い私 / 藤田ことね
2:16:53 12. 白金ディスコ / 阿良々木月火(井口裕香)
2:23:37 13. 愛をこめて花束を / Superfly
2:30:53 14. シルエット / KANA-BOON
2:41:13 15. 怪物 / YOASOBI

2:45:22 16. 丸ノ内サディスティック / 椎名林檎
2:51:18 17. ハム太郎とっとこうた / ハムちゃんず
2:53:12 18. ハム太郎とっとこうた / ハムちゃんず

3:00:47 スパチャ読み
3:04:21 はのはー！
3:04:38 END / Cパート`,Lr={video_title:K0,video_artist:N0,video_id:T0,video_publish_date_str:j0,song_timeline:H0},i4=Object.freeze(Object.defineProperty({__proto__:null,default:Lr,song_timeline:H0,video_artist:N0,video_id:T0,video_publish_date_str:j0,video_title:K0},Symbol.toStringTag,{value:"Module"})),I0="【歌枠｜KARAOKE】アニソン縛りでかっこかわいく歌う歌枠🎤💫【パレプロ / 香鳴ハノン】",D0="Hanon Ch. 香鳴ハノン【パレプロ】",B0="22zTmN4cRQQ",L0="2024-09-11",V0=`0:03:22 はのはー！

0:04:15 01. 忘れてやらない / 結束バンド
0:08:01 02. 青春コンプレックス / 結束バンド
0:12:20 03. ギターと孤独と蒼い惑星 / 結束バンド
0:17:26 04. 星座になれたら / 結束バンド
0:24:23 05. 月並みに輝け / 結束バンド

0:29:52 06. Don't say "lazy" / 桜高軽音部
0:35:18 07. ギー太に首ったけ / 平沢唯(CV:豊崎愛生)
0:39:09 08. ふでペン ～ボールペン～ / 放課後ティータイム
0:43:09 09. カレーのちライス / 放課後ティータイム
0:46:37 10. ぴゅあぴゅあはーと / 放課後ティータイム

0:51:20 11. わたしの恋はホッチキス / 放課後ティータイム
0:58:43 12. 恋愛サーキュレーション / 千石撫子(花澤香菜)
1:04:25 13. 帰り道 / 八九寺真宵(加藤英美里)
1:09:24 14. アイヲウタエ / 春奈るな
1:13:53 15. ナイショの話 / ClariS

1:20:18 16. staple stable / 戦場ヶ原ひたぎ(斎藤千和)
1:28:26 17. 白金ディスコ / 阿良々木月火(井口裕香)
1:33:37 18. 君の知らない物語 / supercell
1:43:28 19. 蒼のエーテル / ランカ・リー＝中島愛
1:48:16 20. 放課後オーバーフロウ / ランカ・リー＝中島愛

1:54:09 21. 星間飛行 / ランカ・リー＝中島愛

2:01:44 スパチャ読み
2:03:40 はのはー！
2:04:14 ED / Cパート`,Vr={video_title:I0,video_artist:D0,video_id:B0,video_publish_date_str:L0,song_timeline:V0},o4=Object.freeze(Object.defineProperty({__proto__:null,default:Vr,song_timeline:V0,video_artist:D0,video_id:B0,video_publish_date_str:L0,video_title:I0},Symbol.toStringTag,{value:"Module"})),U0="【歌枠｜KARAOKE】バンドリ縛りコラボ歌枠！かわいい編💗【#パレプロ #常磐カナメ #香鳴ハノン】",z0="Hanon Ch. 香鳴ハノン【パレプロ】",G0="Nm6PBbb7JLI",k0="2024-09-12",Y0=`0:02:04 こんばんはー！

0:05:25 01. 天下卜ーイツA to Z☆ / Pastel*Palettes
0:15:17 02. しゅわりん☆どり～みん / Pastel*Palettes
0:23:27 03. えがおのオーケストラっ！ / ハロー、ハッピーワールド！
0:35:56 04. えがお・シング・あ・ソング / ハロー、ハッピーワールド！
0:42:18 05. ブルームブルーム / Morfonica

0:50:23 06. キズナミュージック♪ / Poppin'Party

0:57:01 Sputrip4周年ライブのお知らせ
0:57:38 ありがとうございましたー！`,Ur={video_title:U0,video_artist:z0,video_id:G0,video_publish_date_str:k0,song_timeline:Y0},_4=Object.freeze(Object.defineProperty({__proto__:null,default:Ur,song_timeline:Y0,video_artist:z0,video_id:G0,video_publish_date_str:k0,video_title:U0},Symbol.toStringTag,{value:"Module"})),F0="【歌枠｜KARAOKE】全力のカワボ歌枠💗かわいい声ってどうやって出すんだっけ！？【パレプロ / 香鳴ハノン】",W0="Hanon Ch. 香鳴ハノン【パレプロ】",w0="LG1Rh-gnDY0",Q0="2024-09-16",J0=`0:03:39 はのはー！

0:06:40 01. GO MY WAY!! / THE IDOLM@STER
0:12:42 02. Cutie Panther / BiBi
0:18:42 03. No brand girls / μ's
0:27:25 04. irony / ClariS
0:34:13 05. ふわふわ時間 / 放課後ティータイム

0:40:46 06. Rising Hope / LiSA
0:47:11 07. シル・ヴ・プレジデント / P丸様。
0:53:47 08. 唱 / Ado
0:59:35 09. 私は最強 (ウタ from ONE PIECE FILM RED) / Ado
1:07:20 10. 猫 / DISH//

1:14:11 11. Lovers / sumika
1:20:04 12. Cry Baby / Official髭男dism
1:27:02 13. adrenaline!!! / TrySail
1:36:31 14. ミックスナッツ / Official髭男dism
1:44:04 15. 気まぐれロマンティック / いきものがかり

1:50:01 16. 恋は渾沌の隷也 / 後ろから這いより隊G
1:56:15 17. 粛聖!! ロリ神レクイエム☆ / しぐれうい

2:06:14 スパチャ読み
2:13:11 はのはー！
2:13:17 END / Cパート`,zr={video_title:F0,video_artist:W0,video_id:w0,video_publish_date_str:Q0,song_timeline:J0},s4=Object.freeze(Object.defineProperty({__proto__:null,default:zr,song_timeline:J0,video_artist:W0,video_id:w0,video_publish_date_str:Q0,video_title:F0},Symbol.toStringTag,{value:"Module"})),Z0="【歌枠｜KARAOKE】アニソン縛りでテンションあげてこ🎤💫【パレプロ / 香鳴ハノン】",X0="Hanon Ch. 香鳴ハノン【パレプロ】",q0="Pj6m2JEm3M4",x0="2024-09-18",ni=`0:04:15 はのはー！

0:07:25 01. サインはB / B小町 アイ(高橋李依)
0:15:48 02. アイドル / YOASOBI
0:20:29 03. チャンス！ / 月島きらり starring 久住小春(モーニング娘。)
0:25:36 04. バラライカ / 月島きらり starring 久住小春(モーニング娘。)
0:30:21 05. アナタボシ / MilkyWay

0:34:50 06. おジャ魔女カーニバル!! / MAHO堂
0:45:17 07. 星間飛行 / ランカ・リー＝中島愛
0:50:32 08. ラムのラブソング / 松谷祐子
0:55:22 09. Unmei♪wa♪Endless! / 放課後ティータイム
1:00:54 10. GO! GO! MANIAC / 放課後ティータイム

1:07:32 11. 謎 / 小松未歩
1:12:51 12. 渡月橋 ～君 想ふ～ / 倉木麻衣
1:18:29 13. 小さな魔法 / ステレオポニー
1:25:36 14. ツキアカリのミチシルベ / ステレオポニー
1:36:57 15. ヒトヒラのハナビラ / ステレオポニー

1:43:55 16. again / YUI
1:49:42 17. 瞬間センチメンタル / SCANDAL
2:03:01 18. Butter-Fly / 和田光司
2:08:31 19. ウィーアー! / きただにひろし
2:14:52 20. カサブタ / 千綿偉功

2:19:08 21. 月光花 / Janne Da Arc
2:24:20 22. 黒毛和牛上塩タン焼680円 / 大塚愛
2:30:49 23. オリオンをなぞる / UNISON SQUARE GARDEN
2:37:57 24. 青空のナミダ / 高橋瞳
2:44:06 25. 空色デイズ / 中川翔子

2:50:07 26. God knows... / 涼宮ハルヒ(平野綾)

2:57:49 スパチャ読み
3:04:39 はのはー！`,Gr={video_title:Z0,video_artist:X0,video_id:q0,video_publish_date_str:x0,song_timeline:ni},d4=Object.freeze(Object.defineProperty({__proto__:null,default:Gr,song_timeline:ni,video_artist:X0,video_id:q0,video_publish_date_str:x0,video_title:Z0},Symbol.toStringTag,{value:"Module"})),ei="【歌枠｜KARAOKE】珍しく朝活✨寝起きボイスでもさわやかに歌える…はず？【パレプロ / 香鳴ハノン】",ti="Hanon Ch. 香鳴ハノン【パレプロ】",ii="xuTySpDKoww",oi="2024-09-23",_i=`0:02:35 はのはー！

0:14:58 01. パプリカ / Foorin
0:19:12 02. チェリー / スピッツ
0:25:07 03. さくらんぼ / 大塚愛
0:31:27 04. チョコレイト・ディスコ / Perfume
0:36:52 05. 初恋サイダー / Buono!

0:42:12 06. カレーのちライス / 放課後ティータイム
0:47:52 07. Lemon / 米津玄師
1:12:45 08. 忘れてやらない / 結束バンド
1:19:45 09. 月並みに輝け / 結束バンド
1:26:03 10. 青春コンプレックス / 結束バンド

1:34:57 11. ダンデライオン / BUMP OF CHICKEN
1:41:19 12. カルマ / BUMP OF CHICKEN
1:49:18 13. ダンスホール / Mrs. GREEN APPLE
1:53:25 14. 青と夏 / Mrs. GREEN APPLE

2:02:14 スパチャ読み
2:03:25 はのはー！
2:03:39 END / Cパート`,kr={video_title:ei,video_artist:ti,video_id:ii,video_publish_date_str:oi,song_timeline:_i},r4=Object.freeze(Object.defineProperty({__proto__:null,default:kr,song_timeline:_i,video_artist:ti,video_id:ii,video_publish_date_str:oi,video_title:ei},Symbol.toStringTag,{value:"Module"})),si="【歌枠｜KARAOKE】#ぴよノン 学マスオリ曲オンリーセトリ歌枠💗Vアイドルの歌聴いてって✨【#江波キョウカ #香鳴ハノン】",di="Hanon Ch. 香鳴ハノン【パレプロ】",ri="8Zpvfud2XWw",li="2024-09-27",ai=`0:01:50 こんばんはー！

0:13:34 01. 初 / 初星学園
0:21:49 02. 世界一可愛い私 / 藤田ことね
0:37:30 03. 光景 / 篠澤広
0:43:35 04. clumsy trick / 姫崎莉波
0:58:09 05. Boom Boom Pow / 花海咲季

1:17:04 06. Luna say maybe / 月村手毬
1:26:21 07. Yellow Big Bang！ / 藤田ことね
1:31:18 08. 白線 / 葛城リーリヤ
1:36:35 09. The Rolling Riceball / 花海佑芽
1:44:51 10. 世界一可愛い私 / 藤田ことね

1:52:55 スパチャ読み
1:57:44 番外編：アイマスの推しを探そう！
2:57:09 おつぴよのん！
2:57:23 END`,Yr={video_title:si,video_artist:di,video_id:ri,video_publish_date_str:li,song_timeline:ai},l4=Object.freeze(Object.defineProperty({__proto__:null,default:Yr,song_timeline:ai,video_artist:di,video_id:ri,video_publish_date_str:li,video_title:si},Symbol.toStringTag,{value:"Module"})),vi="【歌枠｜KARAOKE】昭和にタイムスリップ！晩酌のおともにいかが？✨#なっとうぷりん【#暁月クララ #香鳴ハノン】",ci="Hanon Ch. 香鳴ハノン【パレプロ】",ui="MKO82yznn7o",bi="2024-09-30",gi=`0:02:20 こんばんはー！

0:10:11 01. 少女A / 中森明菜
0:18:02 02. M / プリンセス プリンセス
0:31:57 03. キューティハニー / 前川陽子
0:38:33 04. UFO / ピンク・レディー
0:44:12 05. ルージュの伝言 / 荒井由実

0:50:23 06. 学園天国 / フィンガー5
1:03:48 07. タッチ / 岩崎良美
1:10:03 08. 赤いスイートピー / 松田聖子
1:15:29 09. M / プリンセス プリンセス

1:28:20 ぴょこはのは〜！
1:28:42 END`,Fr={video_title:vi,video_artist:ci,video_id:ui,video_publish_date_str:bi,song_timeline:gi},a4=Object.freeze(Object.defineProperty({__proto__:null,default:Fr,song_timeline:gi,video_artist:ci,video_id:ui,video_publish_date_str:bi,video_title:vi},Symbol.toStringTag,{value:"Module"})),pi="【歌枠｜KARAOKE】同接200人目指して✨有名なJ-POP中心に歌う🎤💞【パレプロ / 香鳴ハノン】",mi="Hanon Ch. 香鳴ハノン【パレプロ】",$i="fkohTL_nlfY",Oi="2024-10-01",hi=`今回のタイムスタンプ＆セトリ\r
0:00:00 OP\r
0:03:21 はのは～\r
\r
0:05:46；0:11:07 Pretender / Official髭男dism\r
0:13:13；0:17:43 夜に駆ける / YOASOBI\r
0:20:21；0:24:08 怪獣の花唄 / Vaundy\r
0:26:37；0:32:43 たばこ / コレサワ\r
0:34:57；0:39:30 風になる / つじあやの\r
∟0:35:04 同接200人達成\r
0:43:13；0:46:45 SUMMER SONG / Yui\r
0:48:22；0:51:38 少年時代 / 井上陽水\r
0:53:26；0:58:29 Tomorrow never knows / Mr.Children\r
\r
0:59:41；1:04:03 天体観測 / BUMP OF CHICKEN\r
1:04:54；1:08:58 青いベンチ / サスケ\r
1:14:35；1:18:40 気まぐれロマンティック / いきものがかり\r
1:21:39；1:26:35 ヒカリへ / miwa\r
\r
1:29:57 スパチャ読み\r
1:38:16 エンドカード`,Wr={video_title:pi,video_artist:mi,video_id:$i,video_publish_date_str:Oi,song_timeline:hi},v4=Object.freeze(Object.defineProperty({__proto__:null,default:Wr,song_timeline:hi,video_artist:mi,video_id:$i,video_publish_date_str:Oi,video_title:pi},Symbol.toStringTag,{value:"Module"})),Ai="【歌枠｜KARAOKE】「カラオケJOYSOUND for STREAMER」でアイドルソング縛り歌枠🎤💞【パレプロ / 香鳴ハノン】",Si="Hanon Ch. 香鳴ハノン【パレプロ】",yi="1CCTVPvdJTQ",fi="2024-10-04",Ci=`0:03:20 はのは〜！

0:06:29 01. 青春のラップタイム / NMB48
0:12:21 02. 君のことが好きだから / AKB48
0:17:58 03. キャンディー / AKB48
0:24:48 04. アボガドじゃね〜し… / AKB48
0:29:47 05. となりのバナナ / AKB48

0:35:14 06. ハート型ウイルス / AKB48
0:39:33 07. 初日 / AKB48
0:44:14 08. てもでもの涙 / AKB48
0:49:42 09. 渚のCHERRY / AKB48
0:55:19 10. Only today / AKB48
---ここまで調整済み

1:00:46 11. 遠距離ポスター / AKB48
1:08:28 12. W.W.D / でんぱ組.inc
1:16:13 13. ワニとシャンプー / ももいろクローバーZ
1:22:06 14. サラバ、愛しき悲しみたちよ / ももいろクローバーZ
1:28:52 15. ももクロのニッポン万歳！ / ももいろクローバーZ

1:38:20 16. BiSH - 星が瞬く夜に / BiSH
1:43:35 17. My Landscape / BiSH
1:52:14 18. ジャンプ / 私立恵比寿中学
1:58:35 19. シンガロン・シンガソン / 私立恵比寿中学
2:04:48 20. 紅の詩 / 私立恵比寿中学

2:11:01 21. 感情電車 / 私立恵比寿中学
2:21:08 22. 泡沫サタデーナイト / モーニング娘。
2:26:02 23. ミニモニ。ジャンケンぴょん！ / ミニモニ。
2:34:57 24. 夏の花は向日葵だけじゃない / 欅坂46
2:42:11 25. ガールズルール / 乃木坂46

2:51:41 26. それでも好きだよ / 指原莉乃

2:59:00 スパチャ読み
3:11:23 はのは〜！`,wr={video_title:Ai,video_artist:Si,video_id:yi,video_publish_date_str:fi,song_timeline:Ci},c4=Object.freeze(Object.defineProperty({__proto__:null,default:wr,song_timeline:Ci,video_artist:Si,video_id:yi,video_publish_date_str:fi,video_title:Ai},Symbol.toStringTag,{value:"Module"})),Ei="【歌枠｜KARAOKE】学マス大好きアイドルの学マスオリ曲オンリーセトリ歌枠🎤💗【#パレプロ #香鳴ハノン】",Pi="Hanon Ch. 香鳴ハノン【パレプロ】",Ri="_HhebizPio8",Mi="2024-10-05",Ki=`0:03:48 はのは〜！

0:09:19 01. 初 / 初星学園
0:15:42 02. Fighting My Way / 花海咲季
0:21:56 03. Boom Boom Pow / 花海咲季
0:25:30 04. Yellow Big Bang！ / 藤田ことね
0:31:16 05. 世界一可愛い私 / 藤田ことね

0:37:27 06. 叶えたい、ことばかり / 月村手毬
0:43:18 07. アイヴイ / 月村手毬
0:46:52 08. Luna say maybe / 月村手毬
0:53:15 09. Fluorite / 有村麻央
0:57:32 10. Tame-Lie-One-Step / 紫雲清夏

1:01:40 11. clumsy trick / 姫崎莉波
1:08:23 12. The Rolling Riceball / 花海佑芽
1:12:53 13. 光景 / 篠澤広
1:17:36 14. Wonder Scale / 倉本千奈
1:26:53 15. 白線 / 葛城リーリヤ

1:33:40 16. Campus mode!! / 初星学園
1:42:27 17. Fighting My Way / 花海咲季
1:47:36 18. The Rolling Riceball / 花海佑芽 ※噛み噛みVer
1:49:54 19. The Rolling Riceball / 花海佑芽
1:57:39 20. Wonder Scale / 倉本千奈

2:23:48 スパチャ読み
2:27:33 はのは〜！
2:27:48 END / Cパート`,Qr={video_title:Ei,video_artist:Pi,video_id:Ri,video_publish_date_str:Mi,song_timeline:Ki},u4=Object.freeze(Object.defineProperty({__proto__:null,default:Qr,song_timeline:Ki,video_artist:Pi,video_id:Ri,video_publish_date_str:Mi,video_title:Ei},Symbol.toStringTag,{value:"Module"})),Ni="【歌枠｜KARAOKE】だいすきなみちゃとコラボ歌枠💞#ハノミレ てぇてぇしてって✨【Mirea Sheltzs / 香鳴ハノン】",Ti="Hanon Ch. 香鳴ハノン【パレプロ】",ji="YA1GTZJEmTQ",Hi="2024-10-11",Ii=`0:03:15 こんばんはー！

0:30:56 01. 三日月 / 絢香
0:53:09 02. だから僕は音楽を辞めた / ヨルシカ
1:15:42 03. オトナブルー / 新しい学校のリーダーズ
1:23:59 04. 恋のバカンス / ザ・ピーナッツ
1:32:37 05. タッチ / 岩崎良美

2:07:15 はのは〜！
2:07:54 END`,Jr={video_title:Ni,video_artist:Ti,video_id:ji,video_publish_date_str:Hi,song_timeline:Ii},b4=Object.freeze(Object.defineProperty({__proto__:null,default:Jr,song_timeline:Ii,video_artist:Ti,video_id:ji,video_publish_date_str:Hi,video_title:Ni},Symbol.toStringTag,{value:"Module"})),Di="【歌枠｜KARAOKE】新3D✨お披露目歌枠🎤💗【#パレプロ / #香鳴ハノン】",Bi="Hanon Ch. 香鳴ハノン【パレプロ】",Li="iwjfCBbO_H8",Vi="2024-10-17",Ui=`0:02:38 はのは〜！

0:10:26 01. いぬねこ。青春真っ盛り / わーすた
0:21:29 02. アイドル / YOASOBI
0:30:36 03. コネクト / ClariS
0:47:12 04. ダンスホール / Mrs. GREEN APPLE
1:06:55 05. 世界一可愛い私 / 藤田ことね
1:15:29 06. 学園天国 / フィンガー5

1:19:59 スクショタイム
1:39:24 スパチャ読み
1:47:30 はのは〜！
1:48:00 END / Cパート`,Zr={video_title:Di,video_artist:Bi,video_id:Li,video_publish_date_str:Vi,song_timeline:Ui},g4=Object.freeze(Object.defineProperty({__proto__:null,default:Zr,song_timeline:Ui,video_artist:Bi,video_id:Li,video_publish_date_str:Vi,video_title:Di},Symbol.toStringTag,{value:"Module"})),zi="【歌枠｜KARAOKE】男性アーティスト楽曲縛り歌枠🎤💗【#パレプロ / #香鳴ハノン】",Gi="Hanon Ch. 香鳴ハノン【パレプロ】",ki="Wbh8G1QO3ro",Yi="2024-10-21",Fi=`0:04:15 はのは〜！

0:08:45 01. ヤングアダルト / マカロニえんぴつ
0:16:26 02. なんでもないよ、 / マカロニえんぴつ
0:23:29 03. Lemon / 米津玄師
0:38:56 04. HANABI / Mr.Children
0:51:49 05. 別の人の彼女になったよ / wacci

0:58:13 06. 世界に一つだけの花 / SMAP
1:05:45 07. ダンスホール / Mrs. GREEN APPLE
1:12:18 08. 奏 / スキマスイッチ
1:19:06 09. イエスタデイ / Official髭男dism
1:25:57 10. カルマ / BUMP OF CHICKEN

1:30:27 11. 天体観測 / BUMP OF CHICKEN
1:35:55 12. ダンデライオン / BUMP OF CHICKEN
1:40:13 13. 恋 / 星野源
1:48:32 14. 月光花 / Janne Da Arc
2:10:00 15. 世界はそれを愛と呼ぶんだぜ / サンボマスター

2:17:01 16. 水平線 / back number

2:25:49 スパチャ読み
2:40:52 はのは〜！
2:41:25 END / Cパート`,Xr={video_title:zi,video_artist:Gi,video_id:ki,video_publish_date_str:Yi,song_timeline:Fi},p4=Object.freeze(Object.defineProperty({__proto__:null,default:Xr,song_timeline:Fi,video_artist:Gi,video_id:ki,video_publish_date_str:Yi,video_title:zi},Symbol.toStringTag,{value:"Module"})),Wi="【歌枠｜KARAOKE】平成ヒットソング縛り歌枠🎤💗【#パレプロ / #香鳴ハノン】",wi="Hanon Ch. 香鳴ハノン【パレプロ】",Qi="pYR-dfurtRg",Ji="2024-10-24",Zi=`0:02:53 はのは〜！

0:04:28 01. ありがとう / いきものがかり
0:10:51 02. 空も飛べるはず / スピッツ
0:16:39 03. キセキ / GReeeeN
0:22:21 04. ハナミズキ / 一青窈
0:29:40 05. 涙そうそう / 森山良子

0:34:25 06. 夏色 / ゆず
0:54:54 07. Love so sweet / 嵐
1:00:28 08. Hello, Again 〜昔からある場所〜 / My Little Lover
1:05:52 09. さくらんぼ / 大塚愛
1:12:00 10. シーソーゲーム 〜勇敢な恋の歌〜 / Mr.Children

1:23:51 11. プラネタリウム / 大塚愛
1:29:24 12. 会いたくて 会いたくて / 西野カナ
1:35:33 13. Best Friend / 西野カナ
1:42:40 14. 負けないで / ZARD
1:50:16 15. 小さな恋のうた / MONGOL800

1:57:31 スパチャ読み
2:12:30 はのは〜！
2:12:48 END / Cパート`,qr={video_title:Wi,video_artist:wi,video_id:Qi,video_publish_date_str:Ji,song_timeline:Zi},m4=Object.freeze(Object.defineProperty({__proto__:null,default:qr,song_timeline:Zi,video_artist:wi,video_id:Qi,video_publish_date_str:Ji,video_title:Wi},Symbol.toStringTag,{value:"Module"})),Xi="【歌枠｜KARAOKE】スナックハノン！？昭和の名曲縛り歌枠🎤💗【#パレプロ / #香鳴ハノン】",qi="Hanon Ch. 香鳴ハノン【パレプロ】",xi="9kei_kHIBA4",no="2024-10-26",eo=`0:03:19 はのは〜！

0:05:25 01. 待つわ / あみん
0:10:49 02. 桃色吐息 / 髙橋真梨子
0:21:04 03. 見上げてごらん夜の星を / 坂本九
0:28:08 04. 飾りじゃないのよ涙は / 中森明菜
0:32:46 05. セカンド・ラブ / 中森明菜

0:38:00 06. セーラー服と機関銃 / 薬師丸ひろ子
0:47:23 07. 真赤な太陽 / 美空ひばり
0:51:42 08. S・O・S / ピンク・レディー
0:54:29 09. ペッパー警部 / ピンク・レディー
1:17:30 10. 学園天国 / フィンガー5

1:21:40 11. 翼をください / 赤い鳥
1:28:25 12. 津軽海峡・冬景色 / 石川さゆり
1:34:31 13. 異邦人 シルクロードのテーマ / 久保田早紀
1:41:17 14. 木綿のハンカチーフ / 太田裕美
1:45:40 15. 糸 / 中島みゆき

1:51:38 スパチャ読み（前半）

1:55:48 16. 赤いスイートピー / 松田聖子

2:00:13 スパチャ読み（後半））
2:06:20 はのは〜！
2:06:45 END / Cパート`,xr={video_title:Xi,video_artist:qi,video_id:xi,video_publish_date_str:no,song_timeline:eo},$4=Object.freeze(Object.defineProperty({__proto__:null,default:xr,song_timeline:eo,video_artist:qi,video_id:xi,video_publish_date_str:no,video_title:Xi},Symbol.toStringTag,{value:"Module"})),to="【歌枠｜KARAOKE】オンゲキ収録曲オンリー歌枠🎤🎶全曲初めて歌うよ✨【#パレプロ #香鳴ハノン】",io="Hanon Ch. 香鳴ハノン【パレプロ】",oo="5yVskYRBP34",_o="2024-10-29",so=`0:02:40 はのは〜！

0:07:23 01. GranFatalité / 柏木咲姫(CV:石見舞菜香)
0:14:35 02. No Limit RED Force / 星咲あかり(CV:赤尾ひかる)、藍原椿(CV:橋本ちなみ)、早乙女彩華(CV:中島唯)、柏木咲姫(CV:石見舞菜香)、柏木美亜(CV:和氣あず未)
0:22:00 03. 本能的 Survivor / ⊿TRiEDGE [高瀬梨緒(CV:久保ユリカ)、結城莉玖(CV:朝日奈丸佳)、藍原椿(CV:橋本ちなみ)]
0:27:16 04. Starring Stars / ASTERISM [星咲あかり(CV:赤尾 ひかる)、藤沢柚子(CV:久保田 梨沙)、三角葵(CV:春野 杏)]
0:33:23 05. まっすぐ→→→ストリーム! / 日向千夏(CV:岡咲美保)
0:50:03 06. UTAKATA / 九條楓(CV:佳村はるか)

☆おまけ枠
1:00:48 07. シャノワール / シュガーポケッツ
1:18:15 08. Let’s Starry Party！ / ⊿TRiEDGE [高瀬梨緒(CV:久保ユリカ)、結城莉玖(CV:朝日奈丸佳)、藍原椿(CV:橋本ちなみ)]
1:32:58 09. ポケットからぬりつぶせ！ / マーチングポケッツ [日向 千夏(CV:岡咲 美保)、柏木 美亜(CV:和氣 あず未)、東雲 つむぎ(CV:和泉 風花)]
1:50:37 10. 花時は夢を見る。 / 藍原椿(CV:橋本ちなみ)
1:53:53 11. 花時は夢を見る。 / 藍原椿(CV:橋本ちなみ)

1:58:07 スパチャ読み
2:04:55 はのは〜！
2:05:09 END / Cパート`,nl={video_title:to,video_artist:io,video_id:oo,video_publish_date_str:_o,song_timeline:so},O4=Object.freeze(Object.defineProperty({__proto__:null,default:nl,song_timeline:so,video_artist:io,video_id:oo,video_publish_date_str:_o,video_title:to},Symbol.toStringTag,{value:"Module"})),ro="【歌枠｜KARAOKE】ハノンちゃんとカラオケ来てる風！学マスオリ曲オンリーセトリ歌枠🎤💗ALL初歌い！【#パレプロ #香鳴ハノン】",lo="Hanon Ch. 香鳴ハノン【パレプロ】",ao="ooLiDnGb2E0",vo="2024-10-30",co=`0:02:56 はのは〜！

0:08:38 01. 仮装狂騒曲 / 初星学園
0:13:35 02. 仮装狂騒曲 / 初星学園
0:18:56 (途中まで) 仮装狂騒曲 / 初星学園
0:21:11 (途中まで) 仮装狂騒曲 / 初星学園
0:21:52 03. 仮装狂騒曲 / 初星学園
0:28:04 04. 仮装狂騒曲 / 初星学園
0:34:16 05. 日々、発見的ステップ！ / 倉本千奈

0:39:26 06. キミとセミブルー / 初星学園
0:50:50 07. コントラスト / 篠澤広
0:58:05 08. ミラクルナナウ(ﾟ∀ﾟ)！ / 初星学園
1:05:16 09. ミラクルナナウ(ﾟ∀ﾟ)！ / 初星学園
1:13:33 10. がむしゃらに行こう！ / 初星学園

1:19:35 11. 冠菊 / 初星学園
1:25:00 12. 冠菊 / 初星学園
1:34:53 13. Wake up!! / 葛城リーリヤ
1:41:51 14. Wake up!! / 葛城リーリヤ
1:56:51 15. Howling over the World / 初星学園

2:11:27 16. 憧れをいっぱい / 倉本千奈
2:18:11 17. 仮装狂騒曲 / 初星学園
2:29:21 18. 仮装狂騒曲 / 初星学園
2:38:19 19. コントラスト / 篠澤広
2:42:20 20. コントラスト / 篠澤広

2:46:42 21. キミとセミブルー / 初星学園
2:52:07 22. 冠菊 / 初星学園
3:06:48 23. がむしゃらに行こう！ / 初星学園
3:12:18 24. Wake up!! / 葛城リーリヤ
3:18:51 25. 仮装狂騒曲 / 初星学園 - 千奈ちゃん風

3:23:32 26. 仮装狂騒曲 / 初星学園 - 広ちゃん風
3:27:42 27. 仮装狂騒曲 / 初星学園 - 手毬ちゃん風

3:35:00 スパチャ読み
3:40:25 はのは〜！ 
3:40:40 END / Cパート`,el={video_title:ro,video_artist:lo,video_id:ao,video_publish_date_str:vo,song_timeline:co},h4=Object.freeze(Object.defineProperty({__proto__:null,default:el,song_timeline:co,video_artist:lo,video_id:ao,video_publish_date_str:vo,video_title:ro},Symbol.toStringTag,{value:"Module"})),uo="【歌枠｜KARAOKE】11月新衣装で💞ラブソング歌枠💗【#パレプロ #香鳴ハノン】",bo="Hanon Ch. 香鳴ハノン【パレプロ】",go="zoRT1N2JRMg",po="2024-11-01",mo=`0:03:05 はのは〜！

0:07:04 01. CHE.R.RY / YUI
0:13:30 02. One Love / 嵐
0:23:24 03. トリセツ / 西野カナ
0:29:10 眼鏡着用
0:32:27 04. 桃色片想い / 松浦亜弥
0:38:49 05. すきっ! / 超ときめき♡宣伝部

0:46:17 06. 恋愛サーキュレーション / 花澤香菜
0:55:46 07. Lovers / sumika
1:02:04 08. Wherever You Are / ONE OK ROCK

1:07:43 スパチャ読み
1:10:16 はのは〜！
1:10:55 END / Cパート`,tl={video_title:uo,video_artist:bo,video_id:go,video_publish_date_str:po,song_timeline:mo},A4=Object.freeze(Object.defineProperty({__proto__:null,default:tl,song_timeline:mo,video_artist:bo,video_id:go,video_publish_date_str:po,video_title:uo},Symbol.toStringTag,{value:"Module"})),$o="【歌枠｜KARAOKE】ボカロ歌枠！✨高音中心だけどがんばるぞ～！【#パレプロ #香鳴ハノン】",Oo="Hanon Ch. 香鳴ハノン【パレプロ】",ho="wcDOtq5wRck",Ao="2024-11-04",So=`Today's Set List\r
0:00:00 OP\r
0:03:11 はのは～\r
\r
0:05:17 ； 0:08:12 グッバイ宣言 / Chinozo\r
0:09:56 ； 0:12:21 KING / Kanaria\r
0:14:04 ； 0:17:16 ヴァンパイア / DECO*27\r
0:23:38 ； 0:27:02 神っぽいな / ピノキオピー\r
0:29:14 ； 0:33:06 シャルル / バルーンP\r
0:38:43 ； 0:42:23 メランコリック / Junky feat. 鏡音リン\r
0:44:18 ； 0:46:36 酔いどれ知らず / Kanaria\r
0:48:31 ； 0:53:22 少女レイ / みきとP\r
0:56:06 ； 0:59:24 フォニイ / ツミキ\r
1:01:39 ； 1:05:43 千本桜 / 黒うさP\r
1:10:03 ； 1:12:26 強風オールバック / ゆこぴ\r
\r
1:13:02 スパチャ読み\r
1:15:21 エンドカード 11月衣装生写真紹介`,il={video_title:$o,video_artist:Oo,video_id:ho,video_publish_date_str:Ao,song_timeline:So},S4=Object.freeze(Object.defineProperty({__proto__:null,default:il,song_timeline:So,video_artist:Oo,video_id:ho,video_publish_date_str:Ao,video_title:$o},Symbol.toStringTag,{value:"Module"})),yo="【歌枠｜KARAOKE】オールジャンル歌枠！最近のことをお話しながら✨【#パレプロ #香鳴ハノン】",fo="Hanon Ch. 香鳴ハノン【パレプロ】",Co="_rlhD293m4A",Eo="2024-11-07",Po=`0:02:50 はのは〜！

0:16:26 01. Butter-Fly / 和田光司
0:28:28 02. Together / あきよしふみえ
0:43:32 03. プラチナ / 坂本真綾
0:49:12 04. Catch You Catch Me / グミ
0:57:55 05. 翼をください（けいおん！Ver） / 桜高軽音部

1:02:57 06. シル・ヴ・プレジデント / P丸様。
1:12:18 07. 春を告げる / yama
1:19:34 08. シュガーソングとビターステップ / UNISON SQUARE GARDEN
1:25:18 09. 紅蓮華 / LiSA
1:42:31 10. 秒針を噛む / ずっと真夜中でいいのに。

2:01:58 11. メランコリック / Junky

2:07:55 スパチャ読み
2:14:02 はのは〜！
2:14:24 END / Cパート
2:19:12 11月生写真サンプル公開`,ol={video_title:yo,video_artist:fo,video_id:Co,video_publish_date_str:Eo,song_timeline:Po},y4=Object.freeze(Object.defineProperty({__proto__:null,default:ol,song_timeline:Po,video_artist:fo,video_id:Co,video_publish_date_str:Eo,video_title:yo},Symbol.toStringTag,{value:"Module"})),Ro="【歌枠｜KARAOKE】バンド縛り歌枠！かっこよく魅せる🎸✨【#パレプロ #香鳴ハノン】",Mo="Hanon Ch. 香鳴ハノン【パレプロ】",Ko="9CkukWQb8jY",No="2024-11-11",To=`0:03:09 はのは〜！

0:05:31 01. シルエット / KANA-BOON
0:14:04 02. 瞬間センチメンタル / SCANDAL
0:19:19 03. ヒトヒラのハナビラ / ステレオポニー
0:30:04 04. ツキアカリのミチシルベ / ステレオポニー
0:35:44 05. Shout Baby / 緑黄色社会

0:42:40 06. Mela! / 緑黄色社会
0:49:07 07. インフェルノ / Mrs. GREEN APPLE
0:56:02 08. イエスタデイ / Official髭男dism
1:05:39 09. オリオンをなぞる / UNISON SQUARE GARDEN

1:15:19 はのは〜！
1:15:50 END / Cパート`,_l={video_title:Ro,video_artist:Mo,video_id:Ko,video_publish_date_str:No,song_timeline:To},f4=Object.freeze(Object.defineProperty({__proto__:null,default:_l,song_timeline:To,video_artist:Mo,video_id:Ko,video_publish_date_str:No,video_title:Ro},Symbol.toStringTag,{value:"Module"})),jo="【歌枠｜KARAOKE】初見さんにセットリストを決めてもらう歌枠✨【#パレプロ #香鳴ハノン】",Ho="Hanon Ch. 香鳴ハノン【パレプロ】",Io="qAVXNRet4lY",Do="2024-11-15",Bo=`0:03:39 はのは〜！

0:13:27 01. 月光花 / Janne Da Arc
0:23:06 02. サウダージ / ポルノグラフィティ
0:44:11 03. フォニイ / ツミキ
0:50:26 04. No brand girls / μ's
1:28:01 05. 謎 / 小松未歩

1:37:50 スパチャ読み
1:44:25 はのは〜！
1:44:45 END / Cパート`,sl={video_title:jo,video_artist:Ho,video_id:Io,video_publish_date_str:Do,song_timeline:Bo},C4=Object.freeze(Object.defineProperty({__proto__:null,default:sl,song_timeline:Bo,video_artist:Ho,video_id:Io,video_publish_date_str:Do,video_title:jo},Symbol.toStringTag,{value:"Module"})),Lo="【歌枠｜KARAOKE】超有名アニソン歌いまくる歌枠～～！！【#パレプロ #香鳴ハノン】",Vo="Hanon Ch. 香鳴ハノン【パレプロ】",Uo="npR9-zrnOy4",zo="2024-11-19",Go=`0:02:05 はのは〜！

0:06:05 01. Butter-Fly / 和田光司
0:11:02 02. カサブタ / 千綿偉功
0:22:43 03. Don't say "lazy" / 桜高軽音部
0:32:01 04. God knows... / 涼宮ハルヒ (CV.平野 綾)
0:36:44 05. 創聖のアクエリオン / AKINO

0:41:28 06. ライオン / May'n / 中島愛
0:47:27 07. 星間飛行 / ランカ・リー＝中島愛
0:51:21 08. めざせポケモンマスター / 松本梨香
0:55:35 09. Together / あきよしふみえ
1:03:59 10. コネクト / ClariS

1:12:10 11. ギターと孤独と蒼い惑星 / 結束バンド
1:16:07 12. 空色デイズ / 中川翔子
1:21:29 13. 新時代 / Ado
1:27:11 14. Rising Hope / LiSA
1:32:28 15. again / YUI

1:37:09 16. ブルーバード / いきものがかり
1:42:11 17. ウィーアー! / きただにひろし
1:46:39 18. Believe / Folder5
1:52:51 19. ハム太郎とっとこうた / ハムちゃんず

1:58:08 スパチャ読み
2:00:42 Live2D新衣装お披露目 サムネ公開（※新衣装成分2%含む）
2:08:16 はのは〜！
2:08:32 END / Cパート`,dl={video_title:Lo,video_artist:Vo,video_id:Uo,video_publish_date_str:zo,song_timeline:Go},E4=Object.freeze(Object.defineProperty({__proto__:null,default:dl,song_timeline:Go,video_artist:Vo,video_id:Uo,video_publish_date_str:zo,video_title:Lo},Symbol.toStringTag,{value:"Module"})),ko="【歌枠｜KARAOKE】新米オンゲキーズによるオンゲキ収録曲オンリー歌枠🎶【#パレプロ #香鳴ハノン】",Yo="Hanon Ch. 香鳴ハノン【パレプロ】",Fo="4_Cg-qLiwy8",Wo="2024-11-22",wo=`0:03:25 はのは〜！

0:11:33 01. UTAKATA / 九條 楓(CV：佳村はるか)
0:17:47 02. シャノワール / シュガーポケッツ「ラピスリライツ」
0:27:57 03. My precious holiday / 桜井 春菜(CV：近藤 玲奈)
0:39:21 04. GranFatalité / 柏木 咲姫(CV：石見 舞菜香)
0:49:12 05. give it up to you / bitter flavor [桜井 春菜(CV：近藤 玲奈)、早乙女 彩華(CV：中島 唯)]

0:56:41 06. give it up to you / bitter flavor [桜井 春菜(CV：近藤 玲奈)、早乙女 彩華(CV：中島 唯)]
1:06:01 07. Kiss Me Kiss / bitter flavor [桜井 春菜(CV：近藤 玲奈)、早乙女 彩華(CV：中島 唯)]
1:16:04 08. 感情アクセラレイション / AQUAシューターズ
1:22:57 09. タテマエと本心の大乱闘 / 藍原 椿(CV：橋本 ちなみ)
1:36:14 10. 花時は夢を見る。 / 藍原 椿(CV：橋本 ちなみ)

1:49:06 11. SWEET SHAKE!! / 桜井 春菜(CV：近藤 玲奈)
1:55:55 12. まっすぐ→→→ストリーム！ / 日向 千夏(CV:岡咲 美保)
2:09:55 13. Let's Starry Party / ⊿TRiEDGE [高瀬 梨緒(CV：久保 ユリカ)、結城 莉玖(CV：朝日奈 丸佳)、藍原 椿(CV：橋本 ちなみ)]
2:15:52 14. Starring Stars / ASTERISM [星咲 あかり(CV：赤尾 ひかる)、藤沢 柚子(CV：久保田 梨沙)、三角 葵(CV：春野 杏)]
2:21:46 15. ポケットからぬりつぶせ！ / マーチングポケッツ [日向 千夏(CV:岡咲 美保)、柏木 美亜(CV:和氣 あず未)、東雲 つむぎ(CV:和泉 風花)]

2:32:00 16. 本能的 Survivor / ⊿TRiEDGE [高瀬 梨緒(CV：久保 ユリカ)、結城 莉玖(CV：朝日奈 丸佳)、藍原 椿(CV：橋本 ちなみ)]
2:38:29 17. No Limit RED Force / オンゲキシューターズ
2:45:12 アカペラNo Limit RED Force！？
2:45:54 18. No Limit RED Force / オンゲキシューターズ
2:54:13 19. タテマエと本心の大乱闘 / 藍原 椿(CV：橋本 ちなみ)
2:57:42 20. UTAKATA / 九條 楓(CV：佳村はるか)

3:06:48 スパチャ読み
3:19:27 はのは〜！
3:19:52 END / Cパート`,rl={video_title:ko,video_artist:Yo,video_id:Fo,video_publish_date_str:Wo,song_timeline:wo},P4=Object.freeze(Object.defineProperty({__proto__:null,default:rl,song_timeline:wo,video_artist:Yo,video_id:Fo,video_publish_date_str:Wo,video_title:ko},Symbol.toStringTag,{value:"Module"})),Qo="【#1人1アニメ歌枠リレー】トップバッター！選んだのは推しの子💖アイドル力見せてくよ～！🎤🌟【#パレプロ #香鳴ハノン】",Jo="Hanon Ch. 香鳴ハノン【パレプロ】",Zo="_cMjlIrv3EE",Xo="2024-11-30",qo=`Today's Set List\r
0:00:00 OP\r
0:01:14 はのは～\r
\r
0:02:31 アイドル / YOASOBI\r
0:06:06 ピーマン体操 / 有馬かな\r
0:12:42 STAR☆T☆RAIN / B小町\r
0:16:30 POP IN 2 / B小町\r
0:20:57 サインはB / B小町\r
\r
27:18 告知\r
28:51 エンドカード？\r
29:52 エンドカード\r
\r
1人1アニメ歌枠リレートップバッターおつのんでした！`,ll={video_title:Qo,video_artist:Jo,video_id:Zo,video_publish_date_str:Xo,song_timeline:qo},R4=Object.freeze(Object.defineProperty({__proto__:null,default:ll,song_timeline:qo,video_artist:Jo,video_id:Zo,video_publish_date_str:Xo,video_title:Qo},Symbol.toStringTag,{value:"Module"})),xo="【歌枠｜KARAOKE】ほのかチャンと初めてのコラボ歌枠💗平成楽曲で聴かせます✨【#陽茅ほのか #香鳴ハノン】",n1="Hanon Ch. 香鳴ハノン【パレプロ】",e1="NcgR9fC6ScU",t1="2024-12-06",i1=`0:03:58 こんばんは〜！

0:08:26 01. スパークル / RADWIMPS
0:23:06 02. ボクノート / スキマスイッチ
0:35:40 03. 世界は恋に落ちている / CHiCO with HoneyWorks
0:42:46 04. 花に亡霊 / ヨルシカ
0:49:12 05. シルエット / KANA-BOON
0:58:52 06. again / YUI
1:05:25 07. 世界は恋に落ちている / CHiCO with HoneyWorks

1:16:25 ほのはのは〜！
1:17:33 END`,al={video_title:xo,video_artist:n1,video_id:e1,video_publish_date_str:t1,song_timeline:i1},M4=Object.freeze(Object.defineProperty({__proto__:null,default:al,song_timeline:i1,video_artist:n1,video_id:e1,video_publish_date_str:t1,video_title:xo},Symbol.toStringTag,{value:"Module"})),o1="【#オンゲキ歌枠リレー】トリは紫譜面ABFB視野の新米オンゲキーズ！全力で盛り上げてくぞ🎤✨【#パレプロ #香鳴ハノン】",_1="Hanon Ch. 香鳴ハノン【パレプロ】",s1="gO1wLFQe0UI",d1="2024-12-08",r1=`0:01:07 はのは〜！

0:07:59 01. ポケットからぬりつぶせ！ / マーチングポケッツ [日向千夏(CV:岡咲美保)、柏木美亜(CV:和氣あず未)、東雲つむぎ(CV:和泉風花)]
0:16:02 02. タテマエと本心の大乱闘 / 藍原椿(CV：橋本ちなみ)
0:18:58 03. よいまちカンターレ / コーロまちカド(シャミ子･桃･リリス･ミカン)
0:28:13 04. シャノワール / シュガーポケッツ「ラピスリライツ」
0:32:00 05. 夜明けのストリング / 東雲つむぎ(CV:和泉風花)

0:44:23 06. give it up to you / bitter flavor [桜井春菜(CV：近藤玲奈)、早乙女彩華(CV：中島唯)]
0:47:34 07. 宣誓センセーション / KiRaRe
0:54:41 08. GranFatalité / 柏木咲姫(CV：石見舞菜香)

0:59:01 告知
1:00:50 はのは〜！`,vl={video_title:o1,video_artist:_1,video_id:s1,video_publish_date_str:d1,song_timeline:r1},K4=Object.freeze(Object.defineProperty({__proto__:null,default:vl,song_timeline:r1,video_artist:_1,video_id:s1,video_publish_date_str:d1,video_title:o1},Symbol.toStringTag,{value:"Module"})),l1="【3Dカラオケ】アイドル縛りでわちゃわちゃカラオケ女子会💗✨【#海月シェル #白玖ウタノ #香鳴ハノン #暁月クララ】",a1="Hanon Ch. 香鳴ハノン【パレプロ】",v1="6vLYrjCuLfc",c1="2024-12-11",u1=`今回のタイムスタンプ＆セトリ
0:00:00 OP 
0:02:03 わたしの一番かわいいところ / FRUITS ZIPPER(全員)

0:06:18 自己紹介
0:12:46 だいしきゅーだいしゅき / femme fatale(シェルちゃん、クララちゃん)
0:16:24 てもでもの涙 / AKB48(ウタノちゃん、ハノンちゃん)
0:20:11 ハート型ウイルス / AKB48(ウタノちゃん、クララちゃん)
0:24:32 普段どんな曲聴く？
0:26:51 Shake!Shake! / 海月シェル(シェルちゃんソロ)
0:30:53 人生イージー？ / DIALOGUE+(ハノンちゃんソロ)

0:34:55 アボガドじゃね〜し… / AKB48(クララちゃん、ハノンちゃん)
0:39:10 プロミスザスター / BiSH(シェルちゃん、ウタノちゃん)
0:44:32 カラオケもいいけどこのメンバーで何かしたいことある？
0:47:51 秘密のトワレ / 一ノ瀬志希(クララちゃんソロ)
0:52:59 神様は死んだ、って / 斑鳩ルカ(ウタノちゃんソロ)
0:57:00 夢見る15歳 / アンジュルム(シェルちゃん、ハノンちゃん)

1:01:42 告知
1:05:11 ヘビーローテーション / AKB48

1:10:05 エンドカード

コラボ女子会歌枠おつかれさまでした
みんな楽しそうで何より`,cl={video_title:l1,video_artist:a1,video_id:v1,video_publish_date_str:c1,song_timeline:u1},N4=Object.freeze(Object.defineProperty({__proto__:null,default:cl,song_timeline:u1,video_artist:a1,video_id:v1,video_publish_date_str:c1,video_title:l1},Symbol.toStringTag,{value:"Module"})),b1="【歌枠｜KARAOKE】その場でもらったリクエスト曲を歌う🎤💗初見さんも大歓迎✨【#パレプロ #香鳴ハノン】",g1="Hanon Ch. 香鳴ハノン【パレプロ】",p1="A-rIFyV_8N8",m1="2024-12-12",$1=`0:06:19 はのは〜！

0:09:29 01. フォニイ / ツミキ
0:15:42 02. なんでもないよ / マカロニえんぴつ
0:21:35 03. 群青日和 / 東京事変
0:26:24 04. 愛をこめて花束を / Superfly
0:34:13 05. トリセツ / 西野カナ

0:41:36 06. お勉強しといてよ / ずっと真夜中でいいのに。
0:49:42 07. 世界一可愛い私 / 藤田ことね
0:57:29 08. ただ君に晴れ / ヨルシカ
1:05:30 09. 春泥棒 / ヨルシカ
1:11:51 10. サインはB / B小町

1:22:19 11. ハルジオン / YOASOBI
1:28:13 12. かくれんぼ / AliA
1:33:35 13. かくれんぼ / AliA
1:42:51 14. ハナミズキ / 一青窈
1:49:53 15. POP IN 2 / B小町

1:56:23 16. ギターと孤独と蒼い惑星 / 結束バンド
2:02:05 17. サウダージ / ポルノグラフィティ
2:07:35 18. クリスマスソング / back number
2:19:11 19. 唱 / Ado
2:23:45 20. 奏 / スキマスイッチ

2:27:10 21. 猫 / DISH//
2:28:48 22. メリクリ / BoA
2:31:02 23. 糸 / 中島みゆき
2:33:04 24. Q&A リサイタル! / 戸松遥
2:35:13 25. ドライフラワー / 優里

2:37:03 26. ベテルギウス / 優里
2:39:35 27. 残響散歌 / Aimer

3:07:31 スパチャ読み
3:23:55 はのは〜！
3:24:04 END / Cパート`,ul={video_title:b1,video_artist:g1,video_id:p1,video_publish_date_str:m1,song_timeline:$1},T4=Object.freeze(Object.defineProperty({__proto__:null,default:ul,song_timeline:$1,video_artist:g1,video_id:p1,video_publish_date_str:m1,video_title:b1},Symbol.toStringTag,{value:"Module"})),O1="【歌枠｜KARAOKE】ほぼ(ココ大事)みんなの前ではじめて歌う曲縛り🎤✨歌えるかな…？？【#パレプロ #香鳴ハノン】",h1="Hanon Ch. 香鳴ハノン【パレプロ】",A1="V5bsu8nc9jI",S1="2024-12-20",y1=`0:02:00 はのは〜！

0:05:39 01. Overfly / 春奈るな
0:12:54 02. それは小さな光のような / さユり
0:21:19 03. 残念系隣人部★★☆(星二つ半) / 友達つくり隊
0:30:02 04. courage / 戸松遥
0:35:36 05. 青い栞 / Galileo Galilei

0:39:02 06. Re:Re: / ASIAN KUNG-FU GENERATION
0:44:06 07. 明日も / MUSH&Co.
0:49:45 08. 頑張ったっていいんじゃない / 大原櫻子
0:55:26 09. SSW / コレサワ
1:01:50 10. 七転び八起き / アンジュルム

1:06:59 11. 有頂天LOVE / スマイレージ
1:14:45 12. 本当本気 / BiSH
1:21:53 13. HiDE the BLUE / BiSH
1:28:47 14. primal. / BiS
1:36:53 15. 遠距離ポスター / AKB48

1:44:15 16. 君のことが好きだから / AKB48
1:52:54 17. DOLL / SCANDAL
1:58:28 18. ジターバグ / ELLEGARDEN
2:05:56 19. キミに贈る歌 / 菅原紗由理
2:11:02 20. MAYBE / 西野カナ

2:17:44 21. GO FOR IT!! / 西野カナ
2:26:00 22. このままで / 西野カナ
2:29:13 23. 全力少年 / スキマスイッチ
2:37:02 24. R.I.P. / BUMP OF CHICKEN
2:44:35 25. 涙のふるさと / BUMP OF CHICKEN

2:51:35 26. かさぶたぶたぶ / BUMP OF CHICKEN
2:57:45 27. Jam / YUI
3:02:30 28. Happy Birthday to you you / YUI
3:09:27 29. RUIDO / YUI
3:10:57 30. My Generation / YUI

3:18:10 31. again×again / miwa

3:26:46 スパチャ読み
4:00:40 はのは〜！
4:00:51 END / Cパート`,bl={video_title:O1,video_artist:h1,video_id:A1,video_publish_date_str:S1,song_timeline:y1},j4=Object.freeze(Object.defineProperty({__proto__:null,default:bl,song_timeline:y1,video_artist:h1,video_id:A1,video_publish_date_str:S1,video_title:O1},Symbol.toStringTag,{value:"Module"})),f1="【歌枠｜KARAOKE】久々のアニソン歌枠🎤✨初見さんも大歓迎💕【#パレプロ #香鳴ハノン】",C1="Hanon Ch. 香鳴ハノン【パレプロ】",E1="-q10x-fvLkM",P1="2024-12-22",R1=`Today's Set List\r
0:00:00 OP\r
0:04:09 はのは～\r
\r
0:16:58；0:21:38 CLICK / ClariS\r
0:27:26；0:31:45 ナイショの話 / ClariS\r
0:32:39 マクドの話とか使ってるシャンプーの話とか\r
0:41:19；0:46:04 irony / ClariS\r
0:53:33；0:57:20 ALIVE / ClariS\r
0:58:09；1:02:47 花の塔 / さユり\r
\r
1:03:11；1:07:44 それは小さな光のような / さユり\r
1:08:34；1:12:35 Re:Re: / ASIAN KUNG-FU GENERATION\r
1:13:46；1:17:42 シルエット / KANA-BOON\r
∟1:17:25 コーラひっくり返した！\r
1:17:57 対処に追われるハノンちゃん\r
1:26:13；1:30:17 Utauyo!!MIRACLE / 放課後ティータイム\r
1:30:56；1:34:13 カレーのちライス / 放課後ティータイム\r
1:36:06；1:40:47 君色シグナル / 春奈るな\r
1:41:05；1:45:15 ステラブリーズ / 春奈るな\r
1:46:29；1:50:46 アイヲウタエ / 春奈るな\r
1:56:59；2:01:25 Overfly / 春奈るな\r
\r
2:01:43；2:05:51 courage / 戸松遥\r
2:08:14；2:12:38 吹雪 / 西沢幸奏\r
2:17:01；2:21:12 No brand girls / μ's\r
2:24:29；2:29:02 Cutie Panther / BiBi\r
2:29:46；2:34:00 Snow halation / μ's\r
2:48:00；2:51:34 バラライカ / 月島きらり\r
2:51:47；2:55:26 チャンス！ / 月島きらり\r
2:56:25；3:00:45 心絵 / ロードオブメジャー\r
\r
3:01:19；3:04:30 曇天 / DOES\r
3:05:43；3:10:57 世界が終るまでは... / WANDS\r
3:13:11；3:18:15 アナタノオト / 中島愛\r
3:19:23；3:24:55 放課後オーバーフロウ / 中島愛\r
3:26:15；3:30:02 蒼のエーテル / 中島愛\r
3:31:53；3:37:50 ダイアモンド クレバス / May'n\r
3:40:02；3:45:12 トライアングラー / 坂本真綾\r
3:48:11；3:53:11 ライオン / May'n、中島愛\r
\r
3:55:34 スクショ＆スパチャ読みタイム`,gl={video_title:f1,video_artist:C1,video_id:E1,video_publish_date_str:P1,song_timeline:R1},H4=Object.freeze(Object.defineProperty({__proto__:null,default:gl,song_timeline:R1,video_artist:C1,video_id:E1,video_publish_date_str:P1,video_title:f1},Symbol.toStringTag,{value:"Module"})),M1="【歌枠｜KARAOKE】クリスマス一緒に過ごそ？歌枠🎤💖初見さんも大歓迎✨【#パレプロ #香鳴ハノン】",K1="Hanon Ch. 香鳴ハノン【パレプロ】",N1="_Uod6rpfyPo",T1="2024-12-25",j1=`0:04:22 はのは〜！

0:07:27 01. サンタさん / ももいろクローバーZ
0:17:20 02. ロマンスの神様 / 広瀬香美
0:22:45 03. 粉雪 / レミオロメン
0:29:05 04. White Love / SPEED
0:36:21 05. クリスマスソング / back number

0:43:57 06. メリクリ / BoA
0:49:55 07. 雪の華 / 中島美嘉
1:00:27 08. Snow halation / μ's
1:07:42 09. 津軽海峡・冬景色 / 石川さゆり
1:17:42 10. Everything / MISIA

1:27:01 11. サンタさん / ももいろクローバーZ

1:34:20 スクショタイム
1:42:15 スパチャ読み
1:47:01 はのは〜！`,pl={video_title:M1,video_artist:K1,video_id:N1,video_publish_date_str:T1,song_timeline:j1},I4=Object.freeze(Object.defineProperty({__proto__:null,default:pl,song_timeline:j1,video_artist:K1,video_id:N1,video_publish_date_str:T1,video_title:M1},Symbol.toStringTag,{value:"Module"})),H1="【歌枠｜KARAOKE】学マスオリ曲オンリーセトリ歌枠🎤💗初めて歌う曲もあるよ✨【#パレプロ #香鳴ハノン】",I1="Hanon Ch. 香鳴ハノン【パレプロ】",D1="RKW0lhyaHFc",B1="2024-12-26",L1=`Today's Set List\r
0:00:00 OP\r
0:04:55 はのはー\r
\r
0:07:30；0:10:55 Feel Jewel Dream / 有村麻央\r
0:13:00；0:16:10 仮装狂騒曲 / 初星学園\r
0:18:21；0:22:32 Howling over the World / 初星学園\r
0:26:40；0:29:58 アイヴイ / 月村手毬\r
0:39:25；0:42:45 Boom Boom Pow / 花海咲季\r
0:44:51；0:48:36 がむしゃらに行こう！ / 初星学園\r
0:50:43；0:54:15 日々、発見的ステップ！ / 倉本千奈\r
0:54:33；0:59:26 憧れをいっぱい / 倉本千奈\r
\r
1:01:02；1:05:23 Wake up!! / 葛城リーリヤ\r
1:06:34；1:10:17 白線 / 葛城リーリヤ\r
1:19:55；1:25:06 初 / 初星学園\r
\r
1:26:44；1:30:47 冠菊 / 花海咲季、藤田ことね、葛城リーリヤ\r
1:32:15；1:35:54 コントラスト / 篠澤広\r
1:37:27；1:41:14 ミラクルナナウ(ﾟ∀ﾟ)！ / 初星学園\r
1:42:40；1:46:55 Campus mode!! / 初星学園\r
1:52:24；1:56:43 Wake up!! / 葛城リーリヤ\r
\r
2:01:13；2:04:27 仮装狂騒曲 / 初星学園\r
2:06:22；2:09:49 Boom Boom Pow / 花海咲季\r
2:11:11；2:14:26 日々、発見的ステップ！ / 倉本千奈\r
2:14:37 研究生のがぶちゃんの話\r
2:22:42；2:26:35 冠菊 / 花海咲季、藤田ことね、葛城リーリヤ\r
2:27:42；2:31:27 白線 / 葛城リーリヤ\r
2:31:35 研究生のがぶちゃんの話　年末お休みする話\r
2:44:17；2:48:05 Feel Jewel Dream / 有村麻央\r
2:49:20；2:54:37 初 / 初星学園\r
∟2:53:42 ※ノイズ注意\r
2:56:18；2:59:37 アイヴイ / 月村手毬
\r
3:00:51；3:04:32 コントラスト / 篠澤広\r
3:06:11；3:10:44 Campus mode!! / 初星学園\r
3:15:21；3:19:32 Howling over the World / 初星学園\r
3:20:44；3:24:23 がむしゃらに行こう！ / 初星学園\r
3:25:07；3:28:50 ミラクルナナウ(ﾟ∀ﾟ)！ / 初星学園\r
3:32:05；3:36:50 憧れをいっぱい / 倉本千奈\r
\r
3:41:13 スパチャ読み\r
3:50:18 エンドカード`,ml={video_title:H1,video_artist:I1,video_id:D1,video_publish_date_str:B1,song_timeline:L1},D4=Object.freeze(Object.defineProperty({__proto__:null,default:ml,song_timeline:L1,video_artist:I1,video_id:D1,video_publish_date_str:B1,video_title:H1},Symbol.toStringTag,{value:"Module"})),V1="【歌枠｜KARAOKE】オンゲキオリ曲オンリーで20曲！譜面を思い出しながら歌う🎶【#パレプロ #香鳴ハノン】",U1="Hanon Ch. 香鳴ハノン【パレプロ】",z1="T_-vS1ogeSs",G1="2024-12-28 12:00:02",k1=`0:03:20 はのは〜！

0:11:39 01. シンデレラディスコ / 藍原 椿(CV：橋本 ちなみ)、早乙女 彩華(CV：中島 唯)
0:17:06 02. みんな Happy!! / 藤沢 柚子(CV:久保田 梨沙)
0:23:10 03. P！P！P！P！がおー!! / 結城 莉玖(CV：朝日奈 丸佳)
0:33:16 04. 撩乱乙女†無双劇 / ⊿TRiEDGE [高瀬 梨緒(CV：久保 ユリカ)、結城 莉玖(CV：朝日奈 丸佳)、藍原 椿(CV：橋本 ちなみ)]
0:39:48 05. Happiness on the Table / 柏木 咲姫(CV：石見 舞菜香)

0:47:47 06. White Magic Night! / 桜井 春菜(CV：近藤 玲奈)、柏木 咲姫(CV：石見 舞菜香)
0:54:21 07. Let's Starry Party! / ⊿TRiEDGE [高瀬 梨緒(CV：久保 ユリカ)、結城 莉玖(CV：朝日奈 丸佳)、藍原 椿(CV：橋本 ちなみ)]
1:01:10 08. ポケットからぬりつぶせ！ / マーチングポケッツ [日向 千夏(CV:岡咲 美保)、柏木 美亜(CV:和氣 あず未)、東雲 つむぎ(CV:和泉 風花)]
1:04:38 09. 進め！マイウェイ！ / マーチングポケッツ [日向 千夏(CV:岡咲 美保)、柏木 美亜(CV:和氣 あず未)、東雲 つむぎ(CV:和泉 風花)]
1:11:03 10. まっすぐ→→→ストリーム！ / 日向 千夏(CV:岡咲 美保)

1:17:42 11. 夜明けのストリング / 東雲 つむぎ(CV:和泉 風花)
1:24:29 12. Starring Stars / ASTERISM [星咲 あかり(CV：赤尾 ひかる)、藤沢 柚子(CV：久保田 梨沙)、三角 葵(CV：春野 杏)]
1:30:56 13. My precious holiday / 桜井 春菜(CV：近藤 玲奈)
1:35:09 14. SWEET SHAKE!! / 桜井 春菜(CV：近藤 玲奈)
1:42:22 15. Kiss Me Kiss / bitter flavor [桜井 春菜(CV：近藤 玲奈)、早乙女 彩華(CV：中島 唯)]

1:46:06 16. give it up to you / bitter flavor [桜井 春菜(CV：近藤 玲奈)、早乙女 彩華(CV：中島 唯)]
1:53:44 17. 花時は夢を見る。 / 藍原 椿(CV：橋本 ちなみ)
2:02:05 18. UTAKATA / 九條 楓(CV：佳村 はるか)
2:05:55 19. No Limit RED Force / オンゲキシューターズ
2:14:10 20. 感情アクセラレイション / AQUAシューターズ

2:24:54 21. シンデレラディスコ / 藍原 椿(CV：橋本 ちなみ)、早乙女 彩華(CV：中島 唯)
2:30:02 22. 進め！マイウェイ！ / マーチングポケッツ [日向 千夏(CV:岡咲 美保)、柏木 美亜(CV:和氣 あず未)、東雲 つむぎ(CV:和泉 風花)]
2:36:51 23. 撩乱乙女†無双劇 / ⊿TRiEDGE [高瀬 梨緒(CV：久保 ユリカ)、結城 莉玖(CV：朝日奈 丸佳)、藍原 椿(CV：橋本 ちなみ)]

2:43:33 スパチャ読み
2:54:19 はのは〜！
2:54:32 END / Cパート`,$l={video_title:V1,video_artist:U1,video_id:z1,video_publish_date_str:G1,song_timeline:k1},B4=Object.freeze(Object.defineProperty({__proto__:null,default:$l,song_timeline:k1,video_artist:U1,video_id:z1,video_publish_date_str:G1,video_title:V1},Symbol.toStringTag,{value:"Module"})),Y1="【耐久歌枠】登録者33333人目指して歌い続ける✨制限時間7時間…！【 #香鳴ハノン33333人耐久 】",F1="Hanon Ch. 香鳴ハノン【パレプロ】",W1="FtqISd_alKs",w1="2024-12-28",Q1=`Today's Set List\r
0:00:00 OP\r
0:03:42 はのは～\r
\r
0:10:55；0:14:43 怪獣の花唄 / Vaundy\r
0:16:16；0:21:37 Pretender / Official髭男dism\r
0:21:42；0:25:03 ダンスホール / Mrs. GREEN APPLE\r
0:26:46；0:31:05 Happiness / 嵐\r
0:33:22；0:36:41 ノーダウト / Official髭男dism\r
0:37:14；0:42:41 115万キロのフィルム / Official髭男dism\r
0:44:07；0:48:58 白日 / King Gnu\r
0:56:38；1:00:48 シュガーソングとビターステップ / UNISON SQUARE GARDEN
\r
1:01:08；1:05:45 オリオンをなぞる / UNISON SQUARE GARDEN\r
1:05:50 何か喋ろうかな(雑な雑談の導入)\r
1:20:36；1:23:54 翼をください / 放課後ティータイム\r
1:23:59；1:28:12 GO! GO! MANIAC / 放課後ティータイム\r
1:29:24 髪型変更タイム\r
1:33:15；1:37:10 ふわふわ時間 / 放課後ティータイム\r
1:37:28；1:41:05 ギー太に首ったけ / 平沢唯\r
1:42:14；1:46:32 わたしの恋はホッチキス / 放課後ティータイム\r
1:46:50；1:50:45 ふでペン ～ボールペン～ / 放課後ティータイム\r
1:51:11；1:54:35 カレーのちライス / 放課後ティータイム\r
1:57:18；2:01:39 Don't say "lazy" / 放課後ティータイム\r
\r
2:03:18；2:07:53 天使にふれたよ！ / 放課後ティータイム\r
2:07:58；2:12:34 U&I / 放課後ティータイム\r
2:14:04 スパチャ読み\r
2:18:14；2:22:05 Unmei♪wa♪Endless! / 放課後ティータイム\r
2:25:02；2:28:30 Girls in Wonderland / 放課後ティータイム\r
2:30:30 他のメンバーたちも配信しててパレプロ盛り上がってるよ\r
2:36:00；2:40:07 Cagayake!GIRLS / 放課後ティータイム\r
2:43:09；2:46:52 忘れてやらない / 結束バンド\r
2:47:10 バンド曲歌ってるとバンドやりたくなるよね\r
2:52:15 ちょっとお水と食べ物とってくるね\r
2:56:02 梨ASMRとか杏仁豆腐とか\r
\r
3:01:58；3:05:47 ギターと孤独と蒼い惑星 / 結束バンド\r
3:06:06；3:10:14 月並みに輝け / 結束バンド\r
3:14:16；3:18:34 星座になれたら / 結束バンド\r
3:27:54；3:32:00 No brand girls / μ's\r
3:33:11；3:37:40 Cutie Panther / BiBi\r
3:47:52；3:52:06 Snow halation / μ's\r
3:59:05；4:03:45 トライアングラー / 坂本真綾\r
\r
4:05:34；4:10:10 いけないボーダーライン / ワルキューレ\r
4:11:01；4:14:53 星間飛行 / 中島愛\r
4:15:31；4:19:37 めざせポケモンマスター / 松本梨香\r
4:20:09；4:24:07 Together / あきよしふみえ\r
4:36:25；4:40:33 プラチナ / 坂本真綾\r
4:40:49；4:44:34 Catch You Catch Me / グミ\r
4:47:37；4:50:52 カサブタ / 千綿偉功\r
4:51:15；4:55:31 Butter-Fly / 和田光司\r
4:55:37 杏仁豆腐を食べるハノンちゃん\r
\r
4:58:51；5:02:53 ウィーアー！ / きただにひろし\r
∟4:59:07 ch登録33333人達成！\r
5:18:54；5:23:13 私は最強 / Ado\r
5:23:19；5:27:05 新時代 / Ado\r
\r
5:28:57 スパチャ読み\r
5:32:02 助かる\r
5:45:42 エンドカード`,Ol={video_title:Y1,video_artist:F1,video_id:W1,video_publish_date_str:w1,song_timeline:Q1},L4=Object.freeze(Object.defineProperty({__proto__:null,default:Ol,song_timeline:Q1,video_artist:F1,video_id:W1,video_publish_date_str:w1,video_title:Y1},Symbol.toStringTag,{value:"Module"})),J1="【#オンゲキ歌枠リレー】8番手！神曲セトリ全曲ABFBしてきました【#香鳴ハノン/#パレプロ】",Z1="Hanon Ch. 香鳴ハノン【パレプロ】",X1="v1OdzHqxfnw",q1="2025-01-11",x1=`Today's Set List\r
0:00:00 OP\r
0:01:30 はのはー\r
\r
0:06:58；0:10:27 Perfect Shining!! / 星咲あかり\r
0:10:28；0:13:58 デアエ・エクス・マキナ！ / 千寿いろは、白丸美兎、阿岐留カミラ、猫足蕾、本巣叶羽\r
0:17:28 夜明けのストリング / 東雲つむぎ\r
0:22:14 STORIA / トロワアンジュ\r
0:26:58；0:30:57 STARRED HEART / 星咲あかり、結城莉玖、九條楓、珠洲島有栖、東雲つむぎ\r
\r
31:35 エンドカード`,hl={video_title:J1,video_artist:Z1,video_id:X1,video_publish_date_str:q1,song_timeline:x1},V4=Object.freeze(Object.defineProperty({__proto__:null,default:hl,song_timeline:x1,video_artist:Z1,video_id:X1,video_publish_date_str:q1,video_title:J1},Symbol.toStringTag,{value:"Module"})),n_="【歌枠｜KARAOKE】アニソンを歌う🎤💖初見さんも大歓迎✨【#パレプロ #香鳴ハノン】",e_="Hanon Ch. 香鳴ハノン【パレプロ】",t_="quCJh7QwddA",i_="2025-01-12",o_=`0:05:47 はのは〜！

0:23:16 01. Startear / 春奈るな
0:30:03 02. Overfly / 春奈るな
0:37:24 03. courage / 戸松遥
0:42:58 04. PAPERMOON / Tommy heavenly6
0:54:00 05. CLICK / ClariS

1:37:55 06. アイドル / YOASOBI
1:46:41 07. 残念系隣人部★★☆(星二つ半) / 友達つくり隊
1:55:53 08. 放課後オーバーフロウ / ランカ・リー＝中島愛
2:05:25 09. アナタノオト / ランカ・リー＝中島愛

2:31:00 スパチャ読み
2:48:13 はのは〜！
2:48:53 END / Cパート`,Al={video_title:n_,video_artist:e_,video_id:t_,video_publish_date_str:i_,song_timeline:o_},U4=Object.freeze(Object.defineProperty({__proto__:null,default:Al,song_timeline:o_,video_artist:e_,video_id:t_,video_publish_date_str:i_,video_title:n_},Symbol.toStringTag,{value:"Module"})),__="【歌枠｜KARAOKE】ボカロを歌う🎤💖初めて歌う曲も！初見さんも大歓迎✨【#パレプロ #香鳴ハノン】",s_="Hanon Ch. 香鳴ハノン【パレプロ】",d_="7Zk0XmuwgDQ",r_="2025-01-17",l_=`Today's Set List\r
0:00:00 OP\r
0:01:31 はのは～\r
\r
0:04:34；0:09:08 妄想感傷代償連盟 / DECO*27\r
0:11:24；0:13:47 酔いどれ知らず / Kanaria\r
0:14:58；0:18:07 Beyond the way / Giga\r
0:20:19；0:23:41 ガッチュー！ / Giga\r
0:24:25；0:26:01 電気予報 / 稲葉曇(ワンコーラス)\r
0:28:39；0:33:19 地球最後の告白を / kemu\r
0:34:53；0:37:40 マーシャル・マキシマイザー / 柊マグネタイト\r
0:38:46；0:41:15 強風オールバック / ゆこぴ\r
0:44:47；0:48:16 神っぽいな / ピノキオピー\r
0:49:40；0:50:57 アスノヨゾラ哨戒班 / Orangestar\r
0:52:41；0:56:46 金曜日のおはよう ‐love story‐feat. Garo / HoneyWorks\r
1:01:02；1:04:52 東京サマーセッション / HoneyWorks\r
1:05:31；1:06:53 ボルテッカー / DECO*27(ワンコーラス)\r
1:08:55；1:13:31 地球最後の告白を / kemu\r
1:16:03；1:19:18 Beyond the way / Giga\r
1:19:29；1:20:18 Beyond the way / Giga(ラストだけ)\r
1:22:49；1:25:34 マーシャル・マキシマイザー / 柊マグネタイト\r
\r
1:26:07 朝10時に起きた話\r
1:30:53 スパチャ読み\r
\r
1:34:33；1:36:36 寝起きヤシの木 / ゆこぴ\r
1:40:26；1:43:35 ヴァンパイア / DECO*27\r
1:44:39；1:47:42 パラサイト / DECO*27\r
1:49:16；1:51:32 KING / Kanaria\r
1:52:24；1:55:59 ラヴィット / ピノキオピー\r
1:57:18；1:58:42 ラヴィット / ピノキオピー\r
\r
2:00:20 エンドカード`,Sl={video_title:__,video_artist:s_,video_id:d_,video_publish_date_str:r_,song_timeline:l_},z4=Object.freeze(Object.defineProperty({__proto__:null,default:Sl,song_timeline:l_,video_artist:s_,video_id:d_,video_publish_date_str:r_,video_title:__},Symbol.toStringTag,{value:"Module"})),a_="【#ユニパレ歌枠リレー】3番手！アイドルらしくかわいく✨盛り上げるぞっ💗【#香鳴ハノン/#パレプロ】",v_="Hanon Ch. 香鳴ハノン【パレプロ】",c_="PaUibOzOXFs",u_="2025-01-18 12:00:02",b_=`Today's Set List\r
0:00:00 OP\r
0:01:25 はのはー\r
\r
0:04:00；0:06:42 ラムのラブソング / 松谷祐子\r
0:10:26；0:14:20 ハッピーシンセサイザ / EasyPop\r
0:14:25；0:18:09 ダダダダ天使 / ナナヲアカリ\r
0:19:58；0:24:47 Q&A リサイタル! / 戸松遥\r
0:24:52；0:29:06 Campus mode!! / 初星学園\r
\r
0:30:57 エンドカード`,yl={video_title:a_,video_artist:v_,video_id:c_,video_publish_date_str:u_,song_timeline:b_},G4=Object.freeze(Object.defineProperty({__proto__:null,default:yl,song_timeline:b_,video_artist:v_,video_id:c_,video_publish_date_str:u_,video_title:a_},Symbol.toStringTag,{value:"Module"})),g_="【#ユニパレ歌枠リレー】開会式はMCハノウタノン✨歌も歌います✊🎤🔥【#白玖ウタノ #香鳴ハノン】",p_="Hanon Ch. 香鳴ハノン【パレプロ】",m_="wMrA0Y4iMOA",$_="2025-01-18",O_=`0:04:03；0:07:51  ギターと孤独と蒼い惑星 / 結束バンド
0:21:16；0:25:29 空色デイズ / 中川翔子`,fl={video_title:g_,video_artist:p_,video_id:m_,video_publish_date_str:$_,song_timeline:O_},k4=Object.freeze(Object.defineProperty({__proto__:null,default:fl,song_timeline:O_,video_artist:p_,video_id:m_,video_publish_date_str:$_,video_title:g_},Symbol.toStringTag,{value:"Module"})),h_="【歌枠｜KARAOKE】オールジャンルで自由に歌っていく🎤🎶【#香鳴ハノン/#パレプロ】",A_="Hanon Ch. 香鳴ハノン【パレプロ】",S_="ozddO_2kihc",y_="2025-01-23",f_=`0:02:14 はのは〜！

0:07:29 01. 少女レイ / みきとP
0:12:40 02. 世界は恋に落ちている / CHiCO with HoneyWorks
0:19:12 03. 貴女の恋人になりたいのです / 阿部真央
0:26:23 04. heavenly days / 新垣結衣
0:32:45 05. KISSして / KOH+

0:38:04 06. ハッピーシンセサイザ / EasyPop feat. 巡音ルカ, GUMI
0:47:27 07. いーあるふぁんくらぶ / みきとP
0:59:41 08. 地球最後の告白を / kemu feat. GUMI
1:05:49 09. POP IN 2 / B小町 ルビー（CV：伊駒ゆりえ）、有馬かな（CV：潘めぐみ）、MEMちょ（CV：大久保瑠美）
1:13:07 10. 唱 / Ado - かっこいいVer.

1:17:47 11. 唱 / Ado - かわいいVer.
1:25:18 12. 可愛くてごめん / HoneyWorks - かわいい＆かっこいいVer.
1:26:33 13. 可愛くてごめん / HoneyWorks - かわいい＆かっこいいVer.（2回目）

1:38:05 スパチャ読み
1:49:15 はのは〜！
1:49:30 END / Cパート`,Cl={video_title:h_,video_artist:A_,video_id:S_,video_publish_date_str:y_,song_timeline:f_},Y4=Object.freeze(Object.defineProperty({__proto__:null,default:Cl,song_timeline:f_,video_artist:A_,video_id:S_,video_publish_date_str:y_,video_title:h_},Symbol.toStringTag,{value:"Module"})),C_="【#世界で1番かわいい歌枠リレー】1番手！全力でかわいく💗元気が出る歌をお届けするアイドル✨【#香鳴ハノン/#パレプロ】",E_="Hanon Ch. 香鳴ハノン【パレプロ】",P_="IaEhA9u5NxM",R_="2025-01-25",M_=`0:01:01 はのは〜！

0:03:58 01. 僕らは今のなかで / μ's
0:08:36 02. ラブノベルス / BiBi
0:14:41 03. アナタボシ / MilkyWay
0:18:02 04. 星間飛行 / ランカ・リー＝中島愛
0:22:22 05. 白線 / 葛城リーリヤ

0:29:16 はのは〜！
0:30:02 END`,El={video_title:C_,video_artist:E_,video_id:P_,video_publish_date_str:R_,song_timeline:M_},F4=Object.freeze(Object.defineProperty({__proto__:null,default:El,song_timeline:M_,video_artist:E_,video_id:P_,video_publish_date_str:R_,video_title:C_},Symbol.toStringTag,{value:"Module"})),K_="【企画雑談＆歌】#はのまはろん 初コラボ！お悩み相談や疑似1on1トークも🐳💬💗【#夏渚まはろ #香鳴ハノン】",N_="Hanon Ch. 香鳴ハノン【パレプロ】",T_="D9Y9eg8m2j8",j_="2025-01-27",H_=`1:57:09；2:00:30 ただ君に晴れ / ヨルシカ
2:01:40；2:06:12 風になる / つじあやの`,Pl={video_title:K_,video_artist:N_,video_id:T_,video_publish_date_str:j_,song_timeline:H_},W4=Object.freeze(Object.defineProperty({__proto__:null,default:Pl,song_timeline:H_,video_artist:N_,video_id:T_,video_publish_date_str:j_,video_title:K_},Symbol.toStringTag,{value:"Module"})),I_="【歌枠｜KARAOKE】#ぴよノン 学マスオリ曲オンリーセトリ歌枠🎤💗初めて歌う曲も🎄✨【#江波キョウカ #香鳴ハノン】",D_="Hanon Ch. 香鳴ハノン【パレプロ】",B_="Ncf3PtXRxts",L_="2025-01-29",V_=`今回のタイムスタンプ\r
0:00:00 OP\r
0:03:50 こんばんはー\r
\r
0:06:54；0:10:56 White Night! White Wish! / 藤田ことね、葛城リーリヤ、花海佑芽\r
0:16:43；0:20:48 White Night! White Wish! / 藤田ことね、葛城リーリヤ、花海佑芽\r
0:23:30；0:27:32 冠菊 / 花海咲季、藤田ことね、葛城リーリヤ\r
0:35:01；0:40:14 初 / 初星学園\r
0:44:53；0:49:15 Luna say maybe / 月村手毬\r
0:51:44；0:55:00 The Rolling Riceball / 花海佑芽\r
0:56:56；1:00:44 白線 / 葛城リーリヤ\r
\r
1:09:58；1:14:27 光景 / 篠澤広\r
1:17:15；1:20:29 仮装狂騒曲 / 初星学園\r
1:22:18；1:26:17 世界一可愛い私 / 藤田ことね\r
1:29:59；1:33:54 clumsy trick / 姫崎莉波\r
1:37:35；1:41:24 White Night! White Wish! / 藤田ことね、葛城リーリヤ、花海佑芽\r
1:44:09；1:48:08 冠菊 / 花海咲季、藤田ことね、葛城リーリヤ\r
1:51:01；1:54:11 仮装狂騒曲 / 初星学園\r
1:57:48；2:01:37 White Night! White Wish! / 藤田ことね、葛城リーリヤ、花海佑芽\r
\r
2:02:12 何か言い残したことはある？(告知)\r
2:09:03 スパチャ読み\r
2:15:58 エンドカード\r
\r
学マス歌枠おつぴよノンでしたー\r
次回アイマス歌枠も楽しみにしてますね`,Rl={video_title:I_,video_artist:D_,video_id:B_,video_publish_date_str:L_,song_timeline:V_},w4=Object.freeze(Object.defineProperty({__proto__:null,default:Rl,song_timeline:V_,video_artist:D_,video_id:B_,video_publish_date_str:L_,video_title:I_},Symbol.toStringTag,{value:"Module"})),U_="【歌枠｜KARAOKE】今月のオンゲキ歌枠！初めて歌う曲もあるよ✨初見さんも大歓迎💗【#香鳴ハノン/#パレプロ】",z_="Hanon Ch. 香鳴ハノン【パレプロ】",G_="zeRLk1tpSvg",k_="2025-01-31",Y_=`Today's Set List\r
0:00:00 OP\r
0:02:25 はのはー\r
\r
0:09:27；0:14:21 Zest of Blue / 三角葵\r
0:18:50；0:21:50 タテマエと本心の大乱闘 / 藍原椿\r
0:29:08；0:32:57 撩乱乙女†無双劇 / 高瀬梨緒、結城莉玖、藍原椿\r
0:36:17；0:40:01 Kiss me Kiss / Bitter flavor\r
0:43:23；0:47:18 シンデレラディスコ / 藍原椿、早乙女彩華\r
0:49:32；0:53:27 シンデレラディスコ / 藍原椿、早乙女彩華\r
0:57:15；1:01:04 進め！マイウェイ！ / マーチングポケッツ\r
\r
1:05:51；1:09:20 Perfect Shining!! / 星咲あかり\r
1:13:01；1:17:01 みんなHappy!! / 藤沢柚子\r
1:17:57；1:22:13 まっすぐ→→→ストリーム！ / 日向千夏\r
1:24:15；1:29:05 夜明けのストリング / 東雲つむぎ\r
1:33:21；1:37:40 Happiness on the Table / 柏木咲姫\r
1:40:06；1:44:25 Happiness on the Table / 柏木咲姫\r
\r
1:47:22 ※練習タイム※\r
1:50:15 Transcend Lights(アカペラ練習)\r
2:07:50；2:12:30 Transcend Lights / 星咲あかり、高瀬梨緒、柏木美亜、東雲つむぎ、皇城セツナ\r
2:13:07；2:17:49 Transcend Lights / 星咲あかり、高瀬梨緒、柏木美亜、東雲つむぎ、皇城セツナ\r
\r
2:19:10 Zest of Blue(アカペラ練習)\r
2:26:37 Zest of Blue / 三角葵(アカペラ)\r
2:27:27；2:32:15 Zest of Blue / 三角葵\r
2:36:40 Zest of Blue / 三角葵(Youtube不調により一瞬切断されたためやり直し)\r
2:38:36；2:43:30 Zest of Blue / 三角葵\r
2:51:10；2:54:54 Kiss me Kiss / Bitter flavor\r
2:56:44；3:00:34 進め！マイウェイ！ / マーチングポケッツ\r
\r
3:10:20 スパチャ読み\r
3:17:36 エンドカード\r
∟3:20:45 2月生写真紹介`,Ml={video_title:U_,video_artist:z_,video_id:G_,video_publish_date_str:k_,song_timeline:Y_},Q4=Object.freeze(Object.defineProperty({__proto__:null,default:Ml,song_timeline:Y_,video_artist:z_,video_id:G_,video_publish_date_str:k_,video_title:U_},Symbol.toStringTag,{value:"Module"})),F_="【歌枠｜KARAOKE】平成ヒットソング歌枠🎤🎶あなたの思い出の曲は？初見さんも大歓迎✨【#香鳴ハノン/#パレプロ】",W_="Hanon Ch. 香鳴ハノン【パレプロ】",w_="7SCq8emh0DE",Q_="2025-02-01",J_=`Today's Set List\r
0:00:00 OP\r
0:02:22 はのは～\r
\r
0:04:14；0:08:34 チェリー / スピッツ\r
0:12:06；0:16:33 空も飛べるはず / スピッツ\r
0:18:26；0:23:28 奏 / スキマスイッチ\r
0:23:49；0:28:28 変わらないもの / 奥華子\r
0:28:32；0:33:47 ガーネット / 奥華子\r
0:35:17；0:39:37 First Love / 宇多田ヒカル\r
0:41:43；0:47:18 雪の華 / 中島美嘉\r
0:49:05；0:54:42 White Love / SPEED\r
0:59:48；1:03:46 青いベンチ / サスケ\r
\r
1:04:11；1:08:31 天体観測 / BUMP OF CHICKEN\r
1:10:18；1:14:04 小さな恋のうた / MONGOL800\r
1:16:52；1:20:53 イケナイ太陽 / ORANGE RANGE\r
1:22:15；1:26:30 SHAMROCK / UVERworld\r
1:28:25；1:32:04 泪のムコウ / ステレオポニー\r
1:33:02；1:37:39 don't cry anymore / miwa\r
1:38:58；1:43:47 月光花 / Janne Da Arc\r
1:51:26；1:56:34 Tomorrow never knows / Mr.Children\r
1:57:23；2:02:19 桜坂 / 福山雅治\r
\r
2:04:01；2:08:43 青春アミーゴ / 修二と彰\r
2:12:02；2:16:16 ロビンソン / スピッツ\r
\r
2:16:40 平成カラオケランキング大体歌える！\r
2:25:37 アニソンランキング\r
2:36:39 ボーカロイドランキング\r
2:43:26 演歌、歌謡曲ランキング\r
\r
2:49:52；2:54:39 花束 / Back number\r
2:57:55；3:02:24 出逢った頃のように / Every Little Thing\r
\r
3:11:10 スパチャ読み\r
3:16:42 エンドカード`,Kl={video_title:F_,video_artist:W_,video_id:w_,video_publish_date_str:Q_,song_timeline:J_},J4=Object.freeze(Object.defineProperty({__proto__:null,default:Kl,song_timeline:J_,video_artist:W_,video_id:w_,video_publish_date_str:Q_,video_title:F_},Symbol.toStringTag,{value:"Module"})),Z_="【歌枠｜KARAOKE】あまくてとろけちゃうかもしれない歌枠🍯💗初見さんも大歓迎✨【#香鳴ハノン/#パレプロ】",X_="Hanon Ch. 香鳴ハノン【パレプロ】",q_="nl6XwhtSEPI",x_="2025-02-07",n2=`0:05:12 はのは〜！

0:13:05 01. 可愛くてごめん / HoneyWorks
0:20:52 02. Familia / sumika
0:28:45 03. だいしきゅーだいしゅき / femme fatale
0:34:55 04. 恋愛サーキュレーション / 花澤香菜 
0:41:02 05. 世界一可愛い私 / 藤田ことね

0:51:16 06. 世界は恋に落ちている / CHiCO with HoneyWorks
0:58:11 07. HoneyCome!! / 小倉唯
1:06:55 08. おもいでしりとり / DIALOGUE+

1:14:26 スパチャ読み
1:33:28 はのは〜！
1:33:46 END / Cパート`,Nl={video_title:Z_,video_artist:X_,video_id:q_,video_publish_date_str:x_,song_timeline:n2},Z4=Object.freeze(Object.defineProperty({__proto__:null,default:Nl,song_timeline:n2,video_artist:X_,video_id:q_,video_publish_date_str:x_,video_title:Z_},Symbol.toStringTag,{value:"Module"})),e2="【#胸キュンラブソング歌枠リレー】7番手！ハノンはアイドル縛り✨一緒にバレンタインしよ？🍫💗【#香鳴ハノン #パレプロ】",t2="Hanon Ch. 香鳴ハノン【パレプロ】",i2="iLjYjiKdb4o",o2="2025-02-14",_2=`Today's Set List\r
0:00:00 OP\r
0:01:51；0:05:50 ハピチョコ / FRUITS ZIPPER\r
0:09:29；0:15:05 もぎゅっと“love”で接近中! / μ's\r
0:15:06；0:20:06 お願いヴァレンティヌ / HKT48\r
0:20:43 宣伝、告知\r
0:22:05；0:25:26 沼れ！マイラバー / いぎなり東北産 \r
0:25:27；0:29:08 キス・ミー・パティシエ / CANDY TUNE\r
0:30:56 エンドカード

歌枠リレーラストお疲れ様でした！`,Tl={video_title:e2,video_artist:t2,video_id:i2,video_publish_date_str:o2,song_timeline:_2},X4=Object.freeze(Object.defineProperty({__proto__:null,default:Tl,song_timeline:_2,video_artist:t2,video_id:i2,video_publish_date_str:o2,video_title:e2},Symbol.toStringTag,{value:"Module"})),s2="【歌枠｜KARAOKE】ボカロ＆アニソンを歌う！初めて歌う曲アリ✨初見さんも大歓迎💗【#パレプロ #香鳴ハノン】",d2="Hanon Ch. 香鳴ハノン【パレプロ】",r2="FrVB_N62pMY",l2="2025-02-15",a2=`Today's Set List\r
0:00:00 OP\r
0:03:35 はのはー\r
\r
0:04:58；0:08:58 踊れオーケストラ / YASUHIRO\r
0:11:08；0:15:13 如月アテンション / じん\r
0:16:18；0:20:22 如月アテンション / じん\r
0:21:36；0:25:31 夜もすがら君想ふ / 西沢さんP\r
0:26:36；0:30:09 スイートマジック / ろん×Junky\r
0:31:45；0:35:31 夕景イエスタデイ / じん\r
0:40:11；0:44:29 アイヲウタエ / 春奈るな\r
0:48:27；0:52:53 シャル・ウィ・ダンス？ / ReoNa\r
\r
0:59:54；1:05:42 君の知らない物語 / Supercell\r
1:07:45；1:13:35 君の知らない物語 / Supercell\r
1:14:42；1:16:36 君の知らない物語 / Supercell(キー練習)\r
1:19:19；1:24:02 CLICK / ClariS\r
1:25:09；1:29:07 ナイショの話 / ClariS\r
1:31:59；1:35:36 ラヴィット / ピノキオピー\r
1:50:13；1:52:38 きゅうくらりん / いよわ\r
1:58:30；2:01:02 だんだん早くなる / 40mP\r
\r
2:09:06；2:12:31 ドレミファロンド / 40mP\r
2:25:12；2:29:21 セツナトリップ / Last Note.\r
2:29:58；2:34:07 セツナトリップ / Last Note.\r
2:35:05；2:37:07 セツナトリップ / Last Note.(キー練習)\r
2:43:08；2:46:45 スイートマジック / ろん×Junky\r
2:47:04；2:53:19 夜もすがら君想ふ / 西沢さんP\r
2:54:07；2:58:06 踊れオーケストラ / YASUHIRO\r
\r
2:59:30 スクショタイム　スパチャ読み\r
3:08:01 エンドカード`,jl={video_title:s2,video_artist:d2,video_id:r2,video_publish_date_str:l2,song_timeline:a2},q4=Object.freeze(Object.defineProperty({__proto__:null,default:jl,song_timeline:a2,video_artist:d2,video_id:r2,video_publish_date_str:l2,video_title:s2},Symbol.toStringTag,{value:"Module"})),v2="【歌枠｜KARAOKE】邦ロック縛りで歌う！初めて歌う曲も✨初見さんも大歓迎💗【#パレプロ #香鳴ハノン】",c2="Hanon Ch. 香鳴ハノン【パレプロ】",u2="1cXO383nJ54",b2="2025-02-17",g2=`0:02:22 はのは〜！

0:04:02 01. ハンマーソングと痛みの塔 / BUMP OF CHICKEN
0:10:30 02. R.I.P. / BUMP OF CHICKEN
0:17:45 03. 涙のふるさと / BUMP OF CHICKEN
0:23:49 04. ジターバグ / ELLEGARDEN
0:28:21 05. スターフィッシュ / ELLEGARDEN

0:33:49 06. fiction escape / KEYTALK
0:37:33 07. MONSTER DANCE / KEYTALK
0:43:17 08. オドループ / フレデリック
0:47:54 09. ないものねだり / KANA-BOON
0:52:31 10. シルエット / KANA-BOON

0:58:15 11. ヤングアダルト / マカロニえんぴつ
1:03:06 12. 恋人ごっこ / マカロニえんぴつ
1:07:26 13. 元彼氏として / My Hair is Bad
1:13:03 14. ドラマみたいだ / My Hair is Bad
1:18:25 15. ともに / WANIMA

1:22:30 16. やってみよう / WANIMA
1:25:40 17. Lovers / sumika
1:30:11 18. Familia / sumika
1:37:17 19. Lovin' / Mrs. GREEN APPLE
1:40:27 20. ダンスホール / Mrs. GREEN APPLE

1:45:58 21. さくらのうた / KANA-BOON

1:57:03 スパチャ読み
2:04:42 はのは〜！
2:04:52 END / Cパート`,Hl={video_title:v2,video_artist:c2,video_id:u2,video_publish_date_str:b2,song_timeline:g2},x4=Object.freeze(Object.defineProperty({__proto__:null,default:Hl,song_timeline:g2,video_artist:c2,video_id:u2,video_publish_date_str:b2,video_title:v2},Symbol.toStringTag,{value:"Module"})),p2="【歌枠｜KARAOKE】ゲリラで採点ゲームにチャレンジ！何点取れる…！？✨初見さんも大歓迎💗【#パレプロ #香鳴ハノン】",m2="Hanon Ch. 香鳴ハノン【パレプロ】",$2="QMcUvgdYk4A",O2="2025-02-21",h2=`0:02:22 はのは〜！

0:06:15 01. 残響散歌 / Aimer
0:11:35 02. なんでもないよ / マカロニえんぴつ
0:16:04 03. SHAMROCK / UVERworld
0:21:12 04. Namidairo / YUI
0:25:57 05. Jam / YUI

0:30:33 06. Happy Birthday to you you / YUI
0:35:16 07. How crazy / YUI
0:39:51 08. はんぶんこ / ステレオポニー
0:46:51 09. かくれんぼ / AliA
0:52:42 10. ふわふわ時間 / 桜高軽音部

0:57:31 11. 残酷な天使のテーゼ / 高橋洋子
1:02:14 12. 残酷な天使のテーゼ / 高橋洋子
1:09:13 13. I LOVE YOU / 尾崎豊
1:14:18 14. 愛は勝つ / KAN
1:18:57 15. キセキ / GReeeeN

1:24:55 16. 風になる / つじあやの
1:30:13 17. ありがとう / いきものがかり
1:39:58 18. 魂のルフラン / 高橋洋子
1:46:44 19. 残酷な天使のテーゼ / 高橋洋子

1:53:22 スパチャ読み

1:56:50 20. なんでもないよ / マカロニえんぴつ
1:58:20 21. なんでもないよ / マカロニえんぴつ
2:02:18 22. なんでもないよ / マカロニえんぴつ
2:05:43 23. なんでもないよ / マカロニえんぴつ
2:12:31 24. 君が代 / 日本国国歌
2:14:13 25. 君が代 / 日本国国歌
2:15:50 26. 君が代 / 日本国国歌
2:17:26 27. 君が代 / 日本国国歌
2:19:26 28. 君が代 / 日本国国歌
2:21:02 29. 君が代 / 日本国国歌
2:22:07 30. 君が代 / 日本国国歌
2:24:43 31. 君が代 / 日本国国歌
2:26:38 32. 君が代 / 日本国国歌
2:27:31 33. 君が代 / 日本国国歌

2:30:25 はのは〜！
2:31:03 END / Cパート`,Il={video_title:p2,video_artist:m2,video_id:$2,video_publish_date_str:O2,song_timeline:h2},n3=Object.freeze(Object.defineProperty({__proto__:null,default:Il,song_timeline:h2,video_artist:m2,video_id:$2,video_publish_date_str:O2,video_title:p2},Symbol.toStringTag,{value:"Module"})),A2="【歌枠｜KARAOKE】学マスオリ曲オンリーセトリ歌枠🎤✨#ハノ誕2025 ライブまであと7日💕【#パレプロ #香鳴ハノン】",S2="Hanon Ch. 香鳴ハノン【パレプロ】",y2="Th74QhZ4nrg",f2="2025-02-23",C2=`0:02:33 はのは〜！

0:04:40 01. L.U.V / 姫崎莉波
0:12:34 02. L.U.V / 姫崎莉波
0:20:09 03. clumsy trick / 姫崎莉波
0:27:04 04. 日々、発見的ステップ！ / 倉本千奈
0:35:01 05. Wonder Scale / 倉本千奈

0:42:23 06. Fighting My Way / 花海咲季
0:47:51 07. Tame-Lie-One-Step / 紫雲清夏
0:53:43 08. アイヴイ / 月村手毬
1:00:22 09. がむしゃらに行こう！ / 初星学園
1:06:11 10. 冠菊 / 初星学園

1:11:14 11. Wake up!! / 葛城リーリヤ
1:17:57 12. キミとセミブルー / 初星学園
1:24:26 13. 仮装狂騒曲 / 初星学園
1:27:40 14. White Night! White Wish! / 初星学園
1:33:40 15. ハッピーミルフィーユ / 初星学園

1:39:08 16. ハッピーミルフィーユ / 初星学園
1:45:37 17. L.U.V / 姫崎莉波

1:50:40 香鳴ハノン生誕ライブのお知らせ
2:18:16 はのは〜！
2:19:09 END / Cパート`,Dl={video_title:A2,video_artist:S2,video_id:y2,video_publish_date_str:f2,song_timeline:C2},e3=Object.freeze(Object.defineProperty({__proto__:null,default:Dl,song_timeline:C2,video_artist:S2,video_id:y2,video_publish_date_str:f2,video_title:A2},Symbol.toStringTag,{value:"Module"})),E2="【歌枠｜KARAOKE】リステオリ曲オンリーセトリ歌枠🎤✨#ハノ誕2025 ライブまであと6日💕【#パレプロ #香鳴ハノン】",P2="Hanon Ch. 香鳴ハノン【パレプロ】",R2="A1R60k05zgc",M2="2025-02-24",K2=`0:04:40 はのは〜！

0:14:36 01. OvertuRe: / KiRaRe
0:25:23 02. 恋はフュージョン / Stellamaris
0:34:13 03. STORIA / Trois Anges
0:42:41 04. Like the Sun, Like the Moon / Stellamaris
0:48:26 05. 宣誓センセーション / KiRaRe

0:57:17 はのは〜！`,Bl={video_title:E2,video_artist:P2,video_id:R2,video_publish_date_str:M2,song_timeline:K2},t3=Object.freeze(Object.defineProperty({__proto__:null,default:Bl,song_timeline:K2,video_artist:P2,video_id:R2,video_publish_date_str:M2,video_title:E2},Symbol.toStringTag,{value:"Module"})),N2="【歌枠｜KARAOKE】ユメステオリ曲オンリーセトリ歌枠🎤✨#ハノ誕2025 ライブまであと6日💕【#パレプロ #香鳴ハノン】",T2="Hanon Ch. 香鳴ハノン【パレプロ】",j2="dK_D7VZMpyM",H2="2025-02-24 12:00:01",I2=`0:01:27 はのは〜！

0:06:42 01. シリウスの輝きのように / シリウス
0:15:00 02. 夢のステラリウム / 鳳ここな, 静香, カトリナ・グリーベル, 新妻八恵, 柳場ぱんだ, 流石知冴
0:23:54 03. Rolling Stone / 流石知冴
0:33:08 04. 雪は春に、そして花束を / 与那国緋花里, 王雪
0:43:04 05. 雪は春に、そして花束を / 与那国緋花里, 王雪
0:48:55 06. デアエ・エクス・マキナ！ / 千寿いろは, 白丸美兎, 阿岐留カミラ, 猫足 蕾, 本巣叶羽
0:58:18 07. Rolling Stone / 流石知冴

1:14:19 香鳴ハノンバースデーライブのお知らせ
1:20:49 はのは〜！ 
1:21:01 END / Cパート`,Ll={video_title:N2,video_artist:T2,video_id:j2,video_publish_date_str:H2,song_timeline:I2},i3=Object.freeze(Object.defineProperty({__proto__:null,default:Ll,song_timeline:I2,video_artist:T2,video_id:j2,video_publish_date_str:H2,video_title:N2},Symbol.toStringTag,{value:"Module"})),D2="【歌枠｜KARAOKE】バンドリオリ曲オンリーセトリ歌枠🎤✨#ハノ誕2025 ライブまであと5日💕【#パレプロ #香鳴ハノン】",B2="Hanon Ch. 香鳴ハノン【パレプロ】",L2="zzDDf2chH1w",V2="2025-02-25",U2=`0:04:02 はのは〜！

0:11:31 01. えがお･シング･あ･ソング / ハロー、ハッピーワールド!
0:22:38 02. キズナミュージック♪ / Poppin'Party
0:32:07 03. 迷星叫 / MyGO!!!!!
0:45:36 04. Scarlet Sky / Afterglow
0:51:51 05. ゆめゆめグラデーション / Pastel*Palettes

1:01:01 06. ゆめゆめグラデーション / Pastel*Palettes
1:11:07 07. キズナミュージック♪ / Poppin'Party
1:16:20 08. キズナミュージック♪ / Poppin'Party

1:27:47 スパチャ読み
1:36:38 はのは〜！ 
1:36:51 END / Cパート`,Vl={video_title:D2,video_artist:B2,video_id:L2,video_publish_date_str:V2,song_timeline:U2},o3=Object.freeze(Object.defineProperty({__proto__:null,default:Vl,song_timeline:U2,video_artist:B2,video_id:L2,video_publish_date_str:V2,video_title:D2},Symbol.toStringTag,{value:"Module"})),z2="【歌枠｜KARAOKE】アイプラオリ曲オンリーセトリ歌枠🎤✨#ハノ誕2025 ライブまであと3日💕【#パレプロ #香鳴ハノン】",G2="Hanon Ch. 香鳴ハノン【パレプロ】",k2="ctl-46JhT20",Y2="2025-02-27",F2=`0:01:51 はのは〜！

0:11:39 01. IDOLY PRIDE / 星見プロダクション
0:20:05 02. Darkness sympathizer / LizNoir
0:29:26 03. サヨナラから始まる物語 / 星見プロダクション
0:37:45 04. EVERYDAY! SUNNYDAY! / サニーピース
0:47:30 05. Daytime Moon / 月のテンペスト

<以下5曲連続歌唱>
1:15:54 06. IDOLY PRIDE / 星見プロダクション
1:19:34 07. Darkness sympathizer / LizNoir
1:23:09 08. Daytime Moon / 月のテンペスト
1:26:50 09. EVERYDAY! SUNNYDAY! / サニーピース
1:31:49 10. サヨナラから始まる物語 / 星見プロダクション

1:43:39 11. Darkness sympathizer / LizNoir

1:57:57 スパチャ読み
2:05:30 はのは〜！
2:06:22 END / Cパート
2:06:43 3月生写真サンプル`,Ul={video_title:z2,video_artist:G2,video_id:k2,video_publish_date_str:Y2,song_timeline:F2},_3=Object.freeze(Object.defineProperty({__proto__:null,default:Ul,song_timeline:F2,video_artist:G2,video_id:k2,video_publish_date_str:Y2,video_title:z2},Symbol.toStringTag,{value:"Module"})),W2="【歌枠｜KARAOKE】アイマスオリ曲オンリーセトリ #ぴよノン 歌枠🎤✨【#江波キョウカ #香鳴ハノン】",w2="Hanon Ch. 香鳴ハノン【パレプロ】",Q2="o-MfdRPCKsE",J2="2025-02-28",Z2=`0:03:16 こんばんは〜！

0:10:15 01. shiny smile / THE IDOLM@STER
0:21:27 02. Twilight Sky / 多田李衣菜
0:30:11 03. 花ざかりWeekend✿ / 4 Luxury
0:39:19 04. Catch my dream / 最上静香
0:47:48 05. Catch my dream / 最上静香

0:56:16 06. いつだって僕らは / ノクチル
1:03:33 07. shiny smile / THE IDOLM@STER
1:07:40 08. Twilight Sky / 多田李衣菜

1:21:54 スパチャ読み
1:26:10 おつぴよのん！ 
1:26:23 END`,zl={video_title:W2,video_artist:w2,video_id:Q2,video_publish_date_str:J2,song_timeline:Z2},s3=Object.freeze(Object.defineProperty({__proto__:null,default:zl,song_timeline:Z2,video_artist:w2,video_id:Q2,video_publish_date_str:J2,video_title:W2},Symbol.toStringTag,{value:"Module"})),X2="【歌枠｜KARAOKE】オンゲキオリ曲オンリーセトリ歌枠🎤✨#ハノ誕2025 ライブまであと2日💕【#パレプロ #香鳴ハノン】",q2="Hanon Ch. 香鳴ハノン【パレプロ】",x2="_idGblkF3mU",ns="2025-02-28 12:00:01",es=`0:02:14 はのは〜！

0:07:39 01. UTAKATA / 九條楓
0:16:45 02. GranFatalité / 柏木咲姫
0:24:45 03. No Limit RED Force / オンゲキシューターズ
0:31:13 04. 本能的 Survivor / ⊿TRiEDGE
0:37:20 05. 花時は夢を見る。 / 藍原椿

0:45:35 06. give it up to you / bitter flavor
0:51:24 07. 感情アクセラレイション / AQUAシューターズ
0:57:29 08. 感情アクセラレイション / AQUAシューターズ
1:10:39 09. 花時は夢を見る。 / 藍原椿

1:15:25 ハノ誕2025バースデーライブのお知らせ
1:23:20 スパチャ読み
1:29:03 はのは〜！
1:29:29 END / Cパート`,Gl={video_title:X2,video_artist:q2,video_id:x2,video_publish_date_str:ns,song_timeline:es},d3=Object.freeze(Object.defineProperty({__proto__:null,default:Gl,song_timeline:es,video_artist:q2,video_id:x2,video_publish_date_str:ns,video_title:X2},Symbol.toStringTag,{value:"Module"})),ts="【#Vアイドルが歌う2次元アイドル歌枠リレー】6番手！学マスやシャインポストetc..元気に盛り上げます🎤✨【#香鳴ハノン #パレプロ】",is="Hanon Ch. 香鳴ハノン【パレプロ】",os="hlRGqaeKuGk",_s="2025-03-01",ss=`0:01:16 はのは〜！

0:03:30 01. 初 / 初星学園
0:08:43 02. ワンダー・スターター / TINGS
0:12:28 03. タチアガレ！ / Wake Up, Girls!
0:21:23 04. Yellow Big Bang! / 藤田ことね
0:25:23 05. 宣誓センセーション / KiRaRe

0:30:14 はのは〜！`,kl={video_title:ts,video_artist:is,video_id:os,video_publish_date_str:_s,song_timeline:ss},r3=Object.freeze(Object.defineProperty({__proto__:null,default:kl,song_timeline:ss,video_artist:is,video_id:os,video_publish_date_str:_s,video_title:ts},Symbol.toStringTag,{value:"Module"})),ds="【3D LIVE】香鳴ハノンバースデーライブ💗ソシャゲ&音ゲー楽曲オンリー！【#ハノ誕2025/パレプロ】",rs="Palette Project Channel",ls="QoORyB1SQmA",as="2025-03-02",vs=`0:00:56 開演前アナウンス

0:03:13 01. シリウスの輝きのように / シリウス
0:07:26 02. Daytime Moon / 月のテンペスト
0:11:07 03. Twilight Sky / 多田李衣菜
0:15:30 04. Wake up!! / 葛城リーリヤ

0:19:50 <MC>

0:21:52 05. メタモリボン / MORE MORE JUMP!
0:25:35 06. give it up to you / bitter flavor
0:28:49 07. 恋はフュージョン / Stellamaris
0:32:46 08. 電脳スペクタクル / 猫足蕾&阿岐留カミラ
0:36:15 09. リアライズ / Vivid BAD SQUAD

0:38:58 <MC&撮影タイム>

0:42:11 10. ゆめゆめグラデーション / Pastel*Palettes
0:46:53 11. シャイノグラフィ / シャイニーカラーズ
0:51:46 12. STARRED HEART / -

0:55:48 <アンコール>

0:57:07 13. 白線 / 葛城リーリヤ
1:00:45 14. Campus mode!! / 初星学園

1:05:01 <MC>

1:07:26 香鳴ハノン誕生日グッズのお知らせ
1:18:28 はのは〜！
1:18:49 ENDカード`,Yl={video_title:ds,video_artist:rs,video_id:ls,video_publish_date_str:as,song_timeline:vs},l3=Object.freeze(Object.defineProperty({__proto__:null,default:Yl,song_timeline:vs,video_artist:rs,video_id:ls,video_publish_date_str:as,video_title:ds},Symbol.toStringTag,{value:"Module"})),cs="【#ぴゅあぴゅあ歌枠リレー】VアイドルグループPalette Projectの清楚担当、ぴゅあな歌声響かせます✨【#パレプロ #香鳴ハノン】",us="Hanon Ch. 香鳴ハノン【パレプロ】",bs="EjhnDfq__n0",gs="2025-03-09",ps=`0:00:00 OP
0:01:41  白線 / 葛城リーリヤ
0:08:57  明日への扉 / I WiSH
0:14:20 パレプロの紹介
0:18:14 リテラチュア / 上田麗奈
0:24:22 夜もすがら君想ふ / 西沢さんP
0:30:21 エンドカード

ぴゅあぴゅあ歌枠リレー2番手お疲れ様でした
清楚でピュアでした！`,Fl={video_title:cs,video_artist:us,video_id:bs,video_publish_date_str:gs,song_timeline:ps},a3=Object.freeze(Object.defineProperty({__proto__:null,default:Fl,song_timeline:ps,video_artist:us,video_id:bs,video_publish_date_str:gs,video_title:cs},Symbol.toStringTag,{value:"Module"})),ms="【歌枠｜KARAOKE】#ほのはの 歌コラボ！アイドル系💗でかわいく😊✨【#陽茅ほのか #香鳴ハノン】",$s="Hanon Ch. 香鳴ハノン【パレプロ】",Os="5MI_klkkKIc",hs="2025-03-12",As=`0:02:50 ほのはのは〜！

0:05:44 01. シル・ヴ・プレジデント / P丸様。
0:11:38 02. アナタボシ / MilkyWay
0:23:25 03. プラチナ / 坂本真綾
0:36:42 04. 星間飛行 / ランカ・リー＝中島愛
0:45:32 05. わたしの一番かわいいところ / FRUITS ZIPPER

0:54:10 06. 恋愛サーキュレーション / 花澤香菜

1:04:02 ほのはのは〜！
1:04:28 END`,Wl={video_title:ms,video_artist:$s,video_id:Os,video_publish_date_str:hs,song_timeline:As},v3=Object.freeze(Object.defineProperty({__proto__:null,default:Wl,song_timeline:As,video_artist:$s,video_id:Os,video_publish_date_str:hs,video_title:ms},Symbol.toStringTag,{value:"Module"})),Ss="【#めちゃすぷ 歌枠】えるすりー9直前！3人の歌、聴いてみませんか？💫【左から #常磐カナメ #暁月クララ #香鳴ハノン】",ys="Hanon Ch. 香鳴ハノン【パレプロ】",fs="oV-RusOOs1s",Cs="2025-03-13",Es=`0:02:09 こんばんは〜！

0:07:17 01. 星間飛行 / ランカ・リー＝中島愛 - 常磐カナメ＆暁月クララ＆香鳴ハノン
0:16:13 02. 彗星ハネムーン / ナユタン星人 - 常磐カナメ
0:22:15 03. KAWAII FESTIVAL / みんななかよく - 暁月クララ
0:28:15 04. 限りなく灰色へ / 25時、ナイトコードで。 - 常磐カナメ＆香鳴ハノン
0:37:25 05. snowdrop / 春奈るな - 香鳴ハノン

0:44:57 06. ハート型ウイルス / AKB48 チームA - 暁月クララ＆香鳴ハノン
0:51:11 07. 絶対敵対メチャキライヤー / メドミア
1:00:02 08. アイドライフライト / Sputrip

1:13:18 スパチャ読み
1:17:44 ありがとうございました！
1:18:11 END`,wl={video_title:Ss,video_artist:ys,video_id:fs,video_publish_date_str:Cs,song_timeline:Es},c3=Object.freeze(Object.defineProperty({__proto__:null,default:wl,song_timeline:Es,video_artist:ys,video_id:fs,video_publish_date_str:Cs,video_title:Ss},Symbol.toStringTag,{value:"Module"})),Ps="【初見リクエスト歌枠｜KARAOKE】初見さんがセットリストを決める！？10曲目標～✨【#パレプロ #香鳴ハノン】",Rs="Hanon Ch. 香鳴ハノン【パレプロ】",Ms="QMbirZ_Vfko",Ks="2025-03-18",Ns=`0:02:28 はのは〜！

0:29:09 01. irony / ClariS
0:44:32 02. 星座になれたら / 結束バンド
0:50:51 03. リテラチュア / 上田麗奈
0:58:38 04. Honey Come!! / 小倉唯
1:13:31 05. ライオン / May'n/中島愛

1:22:15 06. 花は桜 君は美し / いきものがかり
1:32:25 07. Fighting My Way / 花海咲季
1:37:17 08. Tame-Lie-One-Step / 紫雲清夏
1:43:36 09. Fighting My Way / 花海咲季
2:06:54 10. Luna say maybe / 月村手毬

2:32:52 11. 電脳スペクタクル / 猫足蕾、阿岐留カミラ

2:52:03 スパチャ読み
3:26:02 はのは〜！`,Ql={video_title:Ps,video_artist:Rs,video_id:Ms,video_publish_date_str:Ks,song_timeline:Ns},u3=Object.freeze(Object.defineProperty({__proto__:null,default:Ql,song_timeline:Ns,video_artist:Rs,video_id:Ms,video_publish_date_str:Ks,video_title:Ps},Symbol.toStringTag,{value:"Module"})),Ts="【歌枠｜KARAOKE】オリ曲縛りで歌う🌈Sputrip・REGALILIA・RouteHeartの曲も…！？✨【#パレプロ #香鳴ハノン】",js="Hanon Ch. 香鳴ハノン【パレプロ】",Hs="VfSoDHniioQ",Is="2025-04-09",Ds=`0:02:54 はのは〜！

0:11:59 01. Sweet♡Heart☆Palette♪ / Palette Project
0:15:44 02. トキメキ禁断症状 / RouteHeart
0:19:22 03. ラブ・ラビリンス / RouteHeart

0:23:10 MC①

0:25:06 04. Citylight Fantasy / Sputrip
0:28:14 05. with your JOURNEY / Sputrip
0:32:10 06. 光の惑星 / Sputrip

0:36:37 MC②

0:40:33 07. Demon Drivers / REGALILIA
0:45:01 08. MORAL / REGALILIA
0:50:38 09. 君と歌いたい歌がある / Palette Project

2周目ノンストップ
1:05:48 10. Sweet♡Heart☆Palette♪ / Palette Project
1:09:34 11. トキメキ禁断症状 / RouteHeart
1:13:12 12. ラブ・ラビリンス / RouteHeart
1:16:58 13. Citylight Fantasy / Sputrip
1:20:06 14. with your JOURNEY / Sputrip
1:24:02 15. 光の惑星 / Sputrip
1:28:30 16. Demon Drivers / REGALILIA
1:32:47 17. MORAL / REGALILIA
1:36:30 18. 君と歌いたい歌がある / Palette Project

1:52:27 スパチャ読み
2:35:04 はのは〜！
2:35:16 END / Cパート`,Jl={video_title:Ts,video_artist:js,video_id:Hs,video_publish_date_str:Is,song_timeline:Ds},b3=Object.freeze(Object.defineProperty({__proto__:null,default:Jl,song_timeline:Ds,video_artist:js,video_id:Hs,video_publish_date_str:Is,video_title:Ts},Symbol.toStringTag,{value:"Module"})),Bs="【歌枠｜KARAOKE】オンゲキ版権曲縛り歌枠✨初めて歌う曲にも挑戦して次回リベンジ！【#パレプロ #香鳴ハノン】",Ls="Hanon Ch. 香鳴ハノン【パレプロ】",Vs="afp7s0V8OoI",Us="2025-04-11",zs=`0:04:18 はのは〜！

0:06:48 01. On your mark / 蓮ノ空女学院スクールアイドルクラブ
0:13:22 02. オーバーライド / 吉田夜世
0:17:41 03. 猫猫的宇宙論 / ナユタン星人
0:22:47 04. プラネタリウム・レヴュー / 千寿 暦 (CV.鳥部万里子)、ラモーナ・ウォルフ (CV.田中美海)、王 雪(CV.花井美春)、リリヤ・クルトベイ (CV.安齋由香里)、与那国緋花里 (CV.下地紫野)
0:27:53 05. パラソルサイダー / MORE MORE JUMP！

0:34:10 06. ロミオとシンデレラ / doriko
0:40:08 07. ドラマツルギー / Eve
0:41:55 08. ドラマツルギー / Eve / 原曲キー
0:46:10 09. きゅうくらりん / いよわ
0:50:15 10. シル・ヴ・プレジデント / P丸様。

0:55:20 11. アイドライフライト / Sputrip

本日の練習タイム
1:11:45 12. On your mark / 蓮ノ空女学院スクールアイドルクラブ
1:17:03 13. On your mark / 蓮ノ空女学院スクールアイドルクラブ
1:17:52 14. On your mark / 蓮ノ空女学院スクールアイドルクラブ
1:18:36 15. On your mark / 蓮ノ空女学院スクールアイドルクラブ
1:33:15 16. 猫猫的宇宙論 / ナユタン星人
1:49:49 17. ロミオとシンデレラ / doriko
2:04:42 18. きゅうくらりん / いよわ

2:12:39 スパチャ読み
2:29:54 はのは〜！
2:30:10 END / Cパート`,Zl={video_title:Bs,video_artist:Ls,video_id:Vs,video_publish_date_str:Us,song_timeline:zs},g3=Object.freeze(Object.defineProperty({__proto__:null,default:Zl,song_timeline:zs,video_artist:Ls,video_id:Vs,video_publish_date_str:Us,video_title:Bs},Symbol.toStringTag,{value:"Module"})),Gs="【歌枠｜KARAOKE】恋しちゃうかもしれない…！？Vアイドルによるかわいい歌枠🎤💞【#パレプロ #香鳴ハノン】",ks="Hanon Ch. 香鳴ハノン【パレプロ】",Ys="V8gg1yrTzsw",Fs="2025-04-16",Ws=`Today's Set List\r
0:00:00 OP\r
0:02:16 はのは～\r
\r
0:05:44；0:10:27 青春のラップタイム / NMB48\r
0:11:07；0:15:21 オーマイガー! / NMB48\r
0:15:48；0:19:56 ナギイチ / NMB48\r
0:21:16；0:25:35 ペラペラペラオ / Not yet\r
0:26:04；0:30:34 キャンディー / AKB48\r
0:31:06；0:35:03 ハート型ウイルス / AKB48\r
0:36:02；0:40:25 Only today / AKB48\r
0:41:52；0:46:01 君のことが好きだから / AKB48\r
0:46:15；0:50:11 アボガドじゃね〜し… / AKB48\r
0:50:41；0:54:33 となりのバナナ / AKB48\r
0:55:51；0:59:36 渚のCHERRY / AKB48\r
0:59:50；1:03:04 遠距離ポスター / AKB48\r
\r
1:03:27；1:07:31 わるきー / 渡辺美優紀(NMB48)\r
1:07:46；1:12:03 それでも好きだよ / 指原莉乃\r
1:14:44；1:18:33 初日 / AKB48\r
1:21:06；1:24:51 君は僕だ / 前田敦子\r
1:27:43；1:32:46 右肩 / 前田敦子\r
1:42:27；1:46:28 桜、みんなで食べた / HKT48\r
1:48:27；1:53:49 ギンガムチェック / AKB48\r
\r
1:57:44；2:01:28 トキメキ禁断症状 / RouteHeart\r
\r
2:17:23 スパチャ読み\r
2:44:29 エンドカード`,Xl={video_title:Gs,video_artist:ks,video_id:Ys,video_publish_date_str:Fs,song_timeline:Ws},p3=Object.freeze(Object.defineProperty({__proto__:null,default:Xl,song_timeline:Ws,video_artist:ks,video_id:Ys,video_publish_date_str:Fs,video_title:Gs},Symbol.toStringTag,{value:"Module"})),ws="【#ぷろねぶ歌枠リレー】トップバッター！応援の気持ち、アイドルらしく元気いっぱいに届けます📢💗【#パレプロ #香鳴ハノン】",Qs="Hanon Ch. 香鳴ハノン【パレプロ】",Js="XMdu1QGMtng",Zs="2025-04-20",Xs=`0:01:20 はのは〜！

0:04:12 01. 明日も / SHISHAMO
0:10:19 02. 大切なもの / ロードオブメジャー
0:14:56 03. Believe / Folder5
0:22:49 04. キミイロクロニクル / Palette Project

0:28:05 次枠、菜鳥ひなたさんの紹介
0:29:21 はのは〜！`,ql={video_title:ws,video_artist:Qs,video_id:Js,video_publish_date_str:Zs,song_timeline:Xs},m3=Object.freeze(Object.defineProperty({__proto__:null,default:ql,song_timeline:Xs,video_artist:Qs,video_id:Js,video_publish_date_str:Zs,video_title:ws},Symbol.toStringTag,{value:"Module"})),qs="【歌枠｜KARAOKE】オールジャンルで癒しの歌を届ける✨初見さんも大歓迎💗【#パレプロ #香鳴ハノン】",xs="香鳴ハノン",nd="rP1VbLJErTM",ed="2025-03-10",td=`0:04:00 はのは〜！

0:07:06 01. 春になったら / miwa
0:14:17 02. めぐろ川 / miwa
0:21:06 03. おかえり / 絢香
0:28:34 04. リテラチュア / 上田麗奈
0:36:23 05. ガーネット / 奥華子

0:42:03 06. ハルカ / YOASOBI
0:47:58 07. 赤いスイートピー / 松田聖子
0:53:39 08. 瑠璃色の地球 / 松田聖子
0:58:33 09. 木綿のハンカチーフ / 太田裕美
1:03:48 10. 桃色吐息 / 髙橋真梨子

1:07:36 11. 異邦人 / 久保田早紀
1:14:24 12. ルージュの伝言 / 松任谷由実
1:19:07 13. 夏の日の1993 / class
1:24:32 14. 僕が僕であるために / 尾崎豊
1:31:18 15. I LOVE YOU / 尾崎豊

1:36:14 16. 青空 / THE BLUE HEARTS
1:45:47 17. 愛が生まれた日 / 藤谷美和子、大内義昭
1:58:19 18. セーラー服と機関銃 / 橋本環奈
2:13:56 19. プレイバック part 2 / 山口百恵
2:17:45 20. Diamonds / PRINCESS PRINCESS

2:24:15 21. プレゼント / JITTERIN'JINN

2:34:37 スパチャ読み
2:54:11 はのは〜！ 
2:54:30 END / Cパート`,xl={video_title:qs,video_artist:xs,video_id:nd,video_publish_date_str:ed,song_timeline:td},$3=Object.freeze(Object.defineProperty({__proto__:null,default:xl,song_timeline:td,video_artist:xs,video_id:nd,video_publish_date_str:ed,video_title:qs},Symbol.toStringTag,{value:"Module"})),id="【#魅力オンパレ歌枠リレー】七色の歌声で聴かせます✨かわいいもキレイもかっこいいもお任せあれ💕【#パレプロ #香鳴ハノン】",od="香鳴ハノン",_d="WALfqMKedrs",sd="2025-03-29",dd=`🎀🎶Today's Set List🎀🎶
0:00:00 OP
0:01:15 はのはー

0:05:10 帰り道 / 加藤英美里
0:10:58 オリオンをなぞる / UNISON SQUARE GARDEN
0:16:49 U&I / 放課後ティータイム
0:21:18 正しくなれない / ずっと真夜中でいいのに。
0:25:23 酔いどれ知らず / Kanaria

0:29:02 告知
0:30:58 エンドカード

魅力オンパレ歌枠リレートリ前おつのんでしたー
どのハノンちゃんもいいぞ！`,na={video_title:id,video_artist:od,video_id:_d,video_publish_date_str:sd,song_timeline:dd},O3=Object.freeze(Object.defineProperty({__proto__:null,default:na,song_timeline:dd,video_artist:od,video_id:_d,video_publish_date_str:sd,video_title:id},Symbol.toStringTag,{value:"Module"})),rd="【歌枠｜KARAOKE】ギャップで風邪引かせるかも…！？見た目から歌声想像できる？【#パレプロ #香鳴ハノン】",ld="香鳴ハノン",ad="XJh-6tPbAEg",vd="2025-03-30",cd=`0:02:58 はのは〜！

0:09:57 01. ふでペン ～ボールペン～ / 放課後ティータイム
0:16:22 02. Don't say "lazy" / 桜高軽音部
0:25:14 03. わたしの一番かわいいところ / FRUITS ZIPPER
0:31:34 04. アンビバレント / 欅坂46
0:39:12 05. 世界一可愛い私 / 藤田ことね

0:45:16 06. Luna say maybe / 月村手毬
0:51:37 07. 粛聖!! ロリ神レクイエム☆ / しぐれうい
1:03:56 08. ダンスホール / Mrs. GREEN APPLE
1:09:19 09. ダダダダ天使 / ナナヲアカリ
1:18:10 10. Q&A リサイタル!  / 戸松遥

1:24:08 スパチャ読み
1:42:25 はのは〜！
1:42:48 END / Cパート`,ea={video_title:rd,video_artist:ld,video_id:ad,video_publish_date_str:vd,song_timeline:cd},h3=Object.freeze(Object.defineProperty({__proto__:null,default:ea,song_timeline:cd,video_artist:ld,video_id:ad,video_publish_date_str:vd,video_title:rd},Symbol.toStringTag,{value:"Module"})),ud="【歌枠｜KARAOKE】制服で🌸学マスオリ曲オンリーセトリ歌枠🎤初歌い曲あり✨【#パレプロ #香鳴ハノン】",bd="香鳴ハノン",gd="KkiFM2UeKcs",pd="2025-04-01",md=`0:02:01 はのは〜！

0:05:25 01. コンテンポラリのダンス / 篠澤広
0:17:24 02. L.U.V / 姫崎莉波
0:26:55 03. 仮装狂騒曲 / 初星学園
0:35:23 04. Fighting My Way / 花海咲季
0:41:15 05. The Rolling Riceball / 花海佑芽

0:47:00 06. がむしゃらに行こう！ / 初星学園
0:53:08 07. Luna say maybe / 月村手毬
1:01:03 08. White Night! White Wish! / 初星学園
1:13:24 09. アイヴイ / 月村手毬
1:28:25 10. ハッピーミルフィーユ / 初星学園

1:43:06 11. Boom Boom Pow / 花海咲季
1:49:58 12. 冠菊 / 初星学園
1:58:26 13. 世界一可愛い私 / 藤田ことね
2:04:24 14. 白線 / 葛城リーリヤ
2:08:30 15. Campus mode!! / 初星学園

2:15:06 スパチャ読み
2:37:16 はのは〜！
2:37:55 END / Cパート`,ta={video_title:ud,video_artist:bd,video_id:gd,video_publish_date_str:pd,song_timeline:md},A3=Object.freeze(Object.defineProperty({__proto__:null,default:ta,song_timeline:md,video_artist:bd,video_id:gd,video_publish_date_str:pd,video_title:ud},Symbol.toStringTag,{value:"Module"})),$d="【#耐久歌枠 (前編)】登録者34000人&同接300人達成まで歌い続ける耐久歌枠🎤🎶【#ハノンノオト #香鳴ハノン】",Od="香鳴ハノン",hd="VcYRulUgoww",Ad="2025-04-02",Sd=`0:01:34 はのは〜！

0:08:13 01. SUN / 星野源
0:16:24 02. ドラえもん / 星野源
0:20:43 03. 世界に一つだけの花 / SMAP
0:36:50 04. 猫 / DISH//
0:57:13 05. ミュージック・アワー / ポルノグラフィティ
1:02:18 06. シーソーゲーム 〜勇敢な恋の歌〜 / Mr.Children
1:08:53 07. Tomorrow never knows / Mr.Children
1:25:24 08. しるし / Mr.Children
1:36:23 09. Stand By You / Official髭男dism
1:41:27 10. I LOVE... / Official髭男dism

1:51:29 11. 宿命 / Official髭男dism
2:00:07 12. イエスタデイ / Official髭男dism
2:07:10 13. Cry Baby / Official髭男dism
2:12:13 14. ミックスナッツ / Official髭男dism
2:18:49 15. インフェルノ / Mrs. GREEN APPLE
2:33:27 16. Mela! / 緑黄色社会
2:39:14 17. Shout Baby / 緑黄色社会
2:51:06 18. 花になって / 緑黄色社会
2:55:12 19. 花の塔 / さユり
3:01:25 20. ステラブリーズ / 春奈るな

3:06:14 21. アイヲウタエ / 春奈るな
3:12:32 22. staple stable / 戦場ヶ原ひたぎ(CV: 斎藤千和)
3:19:49 23. 恋愛サーキュレーション / 千石撫子(CV: 花澤香菜)
3:30:23 24. ナイショの話 / ClariS
3:35:00 25. ヒトリゴト / ClariS
3:39:04 26. adrenaline!!! / TrySail
3:45:48 27. アイドル / YOASOBI
3:50:56 28. アナタノオト / ランカ・リー＝中島愛
3:59:27 29. 蒼のエーテル / ランカ・リー＝中島愛

4:03:52 30. 放課後オーバーフロウ / ランカ・リー＝中島愛
4:10:01 31. 星間飛行 / ランカ・リー＝中島愛
4:14:57 32. トライアングラー / 坂本真綾
4:35:05 33. ライオン / シェリル・ノーム starring May'n,ランカ・リー＝中島愛
4:45:50 34. 忘れてやらない / 結束バンド
4:49:34 35. 青春コンプレックス / 結束バンド
4:53:39 36. ギターと孤独と蒼い惑星 / 結束バンド
4:58:46 37. 月並みに輝け / 結束バンド
5:05:45 38. 星座になれたら / 結束バンド
5:13:27 39. Rising Hope / LiSA

5:19:09 40. Catch the Moment / LiSA
5:25:44 41. crossing field / LiSA
5:34:27 42. 紅蓮華 / LiSA
5:38:53 43. 炎 / LiSA`,ia={video_title:$d,video_artist:Od,video_id:hd,video_publish_date_str:Ad,song_timeline:Sd},S3=Object.freeze(Object.defineProperty({__proto__:null,default:ia,song_timeline:Sd,video_artist:Od,video_id:hd,video_publish_date_str:Ad,video_title:$d},Symbol.toStringTag,{value:"Module"})),yd="【#耐久歌枠(後編)】達成ありがとう💕登録者34000人&同接300人目標の耐久歌枠🎤🎶老人会セトリ✨【#ハノンノオト #香鳴ハノン】",fd="香鳴ハノン",Cd="sYMJ9rAljNg",Ed="2025-04-02 12:00:01",Pd=`0:00:58 はのは〜！

※番号は前半戦からの通し番号
0:18:43 44. おジャ魔女カーニバル!! / MAHO堂
0:22:48 45. ハレ晴レユカイ / 涼宮ハルヒ(平野綾)・長門有希(茅原実里)・朝比奈みくる(後藤邑子)
0:34:02 46. 恋は渾沌の隷也 / 後ろから這いより隊G
0:41:18 47. 撲殺天使ドクロちゃん / ドクロちゃん(千葉紗子)
0:45:52 48. バラライカ / 月島きらり starring 久住小春(モーニング娘。)
0:50:18 49. 檄！帝国華撃団 / 真宮寺さくら(横山智佐)&帝国歌劇団

0:55:06 50. Butter-Fly / 和田光司
0:59:41 51. カサブタ / 千綿偉功
1:05:59 52. ハッピーシンセサイザ / EasyPop
1:10:00 53. いーあるふぁんくらぶ / みきとP

1:16:45 🎉🎉🎉CH登録者34000人突破おめでとう！！🎉🎉🎉

1:17:23 54. Believe / Folder5
1:27:52 55. 赤いスイートピー / 松田聖子

1:32:29 🔖ハノンちゃんの真面目な話

2:07:35 56. S・O・S / ピンク・レディー
2:11:00 57. 瑠璃色の地球 / 松田聖子

2:19:49 はのは〜！
2:20:39 END / Cパート`,oa={video_title:yd,video_artist:fd,video_id:Cd,video_publish_date_str:Ed,song_timeline:Pd},y3=Object.freeze(Object.defineProperty({__proto__:null,default:oa,song_timeline:Pd,video_artist:fd,video_id:Cd,video_publish_date_str:Ed,video_title:yd},Symbol.toStringTag,{value:"Module"})),Rd="【歌枠｜KARAOKE】音ゲー楽曲縛り歌枠✨ラブライブ！&プロセカ&ユメステのオリ曲メイン！版権曲も…？【#パレプロ #香鳴ハノン】",Md="香鳴ハノン",Kd="zUAX4RUs-jI",Nd="2025-04-04",Td=`0:03:28 はのは〜！

0:07:25 01. プラネタリウム・レヴュー / 千寿 暦 (CV.鳥部万里子)、ラモーナ・ウォルフ (CV.田中美海)、王 雪(CV.花井美春)、リリヤ・クルトベイ (CV.安齋由香里)、与那国緋花里 (CV.下地紫野)
0:13:44 02. 電脳スペクタクル / 猫足 蕾 (CV.芹澤 優)、阿岐留カミラ (CV.若井友希)
0:19:54 03. ワールドワイドワンダー / MORE MORE JUMP！
0:32:30 04. パラソルサイダー / MORE MORE JUMP！
0:40:01 05. メタモリボン / MORE MORE JUMP！
0:44:38 06. リアライズ / Vivid BAD SQUAD
0:49:53 07. 僕らは今のなかで / μ's
0:54:58 08. ラブノベルス / BiBi
1:01:22 09. ドキピポ☆エモーション / 天王寺璃奈(田中ちえ美)
1:14:33 10. ドキピポ☆エモーション / 天王寺璃奈(田中ちえ美) 

1:24:54 11. START!! True dreams / Liella!
1:36:50 12. START!! True dreams / Liella!
1:42:20 13. START!! True dreams / Liella!
1:49:54 14. オドループ / フレデリック
1:58:53 15. いーあるふぁんくらぶ / みきとP
2:07:38 16. アイデンティティ / Kanaria
2:12:46 17. アイデンティティ / Kanaria
2:15:59 18. アイデンティティ / Kanaria
2:21:53 19. Beyond the way / Vivid BAD SQUAD
2:28:38 20. モア！ジャンプ！モア！ / MORE MORE JUMP！

2:42:09 21. Snow halation / μ's
3:03:14 22. 怪物 / YOASOBI
3:08:38 23. かくれんぼ / AliA

3:18:18 スパチャ読み
3:41:38 はのは〜！
3:43:13 END / Cパート`,_a={video_title:Rd,video_artist:Md,video_id:Kd,video_publish_date_str:Nd,song_timeline:Td},f3=Object.freeze(Object.defineProperty({__proto__:null,default:_a,song_timeline:Td,video_artist:Md,video_id:Kd,video_publish_date_str:Nd,video_title:Rd},Symbol.toStringTag,{value:"Module"})),jd="【歌枠｜KARAOKE】ロボソン縛り歌枠🤖✨キテレツ大百科・ガンダム・マクロスなど！【#パレプロ #香鳴ハノン】",Hd="香鳴ハノン",Id="8bMDoq_i5ss",Dd="2025-04-05",Bd=`0:01:49 はのは〜！

0:03:19 01. 鉄腕アトム / 上高田少年合唱団
0:07:50 02. お料理行進曲 / YUKA
0:11:29 03. すいみん不足 / CHICKS
0:16:10 04. 夢をかなえてドラえもん / mao
0:20:36 05. YUME日和 / 島谷ひとみ

0:26:18 06. ドラえもんのうた / 大杉久美子
0:30:38 07. 檄！帝国華撃団 / 真宮寺さくら（横山智佐）＆帝国歌劇団
0:34:42 08. trust you / 伊藤由奈
0:44:56 09. 蒼のエーテル / ランカ・リー＝中島愛
0:49:03 10. ノーザンクロス / シェリル・ノーム starring May'n

0:54:21 11. いけないボーダーライン / ワルキューレ
0:59:38 12. 空色デイズ / 中川翔子
1:11:24 13. 創聖のアクエリオン / AKINO

1:17:11 スパチャ読み

1:20:05 14. ダイアモンド クレバス / シェリル・ノーム starring May'n
1:22:23 15. ライオン / シェリル・ノーム starring May'n,ランカ・リー=中島愛

1:27:17 はのは〜！`,sa={video_title:jd,video_artist:Hd,video_id:Id,video_publish_date_str:Dd,song_timeline:Bd},C3=Object.freeze(Object.defineProperty({__proto__:null,default:sa,song_timeline:Bd,video_artist:Hd,video_id:Id,video_publish_date_str:Dd,video_title:jd},Symbol.toStringTag,{value:"Module"})),Ld="【歌枠｜KARAOKE】寝起きでボカロ縛り歌枠✨ラビットホールにチャレンジする～🐇💕【#パレプロ #香鳴ハノン】",Vd="Hanon Ch. 香鳴ハノン【パレプロ】",Ud="v0CviXGBsfk",zd="2025-04-13",Gd=`0:04:07 はのは〜！

0:08:12 01. ラビットホール / DECO*27
0:12:01 02. ラビットホール / DECO*27
0:15:57 03. エンヴィーベイビー / Kanaria
0:18:34 04. オーバーライド / 吉田夜世
0:21:43 05. ロミオとシンデレラ / doriko

0:27:11 06. 強風オールバック / ゆこぴ
0:30:03 07. 寝起きヤシの木 / ゆこぴ
0:32:37 08. 夜もすがら君想ふ / 西沢さんP
0:39:04 09. 地球最後の告白を / kemu
0:44:30 10. 猫猫的宇宙論 / ナユタン星人

0:48:35 11. 惑星ループ / Eve
1:00:02 12. ハッピーシンセサイザ / EasyPop
1:04:33 13. ドレミファロンド / 40mP
1:08:35 14. 踊れオーケストラ / YASUHIRO(康寛)
1:13:29 15. 高音厨音域テスト / 木村わいP

1:23:47 16. 夕景イエスタデイ / じん
1:27:46 17. 妄想感傷代償連盟 / DECO*27
1:39:37 18. 好き！雪！本気マジック / Mitchie M
1:47:12 19. 好き！雪！本気マジック / Mitchie M
1:52:22 20. ラビットホール / DECO*27

1:56:40 スパチャ読み
2:07:45 はのは〜！
2:07:54 END / Cパート`,da={video_title:Ld,video_artist:Vd,video_id:Ud,video_publish_date_str:zd,song_timeline:Gd},E3=Object.freeze(Object.defineProperty({__proto__:null,default:da,song_timeline:Gd,video_artist:Vd,video_id:Ud,video_publish_date_str:zd,video_title:Ld},Symbol.toStringTag,{value:"Module"}));export{d4 as $,Ia as A,Da as B,Ba as C,La as D,Va as E,Ua as F,za as G,Ga as H,ka as I,Ya as J,Fa as K,Wa as L,wa as M,Qa as N,Ja as O,Za as P,Xa as Q,qa as R,xa as S,n4 as T,e4 as U,t4 as V,i4 as W,o4 as X,_4 as Y,s4 as Z,ra as _,la as a,m3 as a$,r4 as a0,l4 as a1,a4 as a2,v4 as a3,c4 as a4,u4 as a5,b4 as a6,g4 as a7,p4 as a8,m4 as a9,Y4 as aA,F4 as aB,W4 as aC,w4 as aD,Q4 as aE,J4 as aF,Z4 as aG,X4 as aH,q4 as aI,x4 as aJ,n3 as aK,e3 as aL,t3 as aM,i3 as aN,o3 as aO,_3 as aP,s3 as aQ,d3 as aR,r3 as aS,l3 as aT,a3 as aU,v3 as aV,c3 as aW,u3 as aX,b3 as aY,g3 as aZ,p3 as a_,$4 as aa,O4 as ab,h4 as ac,A4 as ad,S4 as ae,y4 as af,f4 as ag,C4 as ah,E4 as ai,P4 as aj,R4 as ak,M4 as al,K4 as am,N4 as an,T4 as ao,j4 as ap,H4 as aq,I4 as ar,D4 as as,B4 as at,L4 as au,V4 as av,U4 as aw,z4 as ax,G4 as ay,k4 as az,aa as b,$3 as b0,O3 as b1,h3 as b2,A3 as b3,S3 as b4,y3 as b5,f3 as b6,C3 as b7,E3 as b8,va as c,ca as d,ua as e,ba as f,ga as g,pa as h,ma as i,$a as j,Oa as k,ha as l,Aa as m,Sa as n,ya as o,fa as p,Ca as q,Ea as r,Pa as s,Ra as t,Ma as u,Ka as v,Na as w,Ta as x,ja as y,Ha as z};
